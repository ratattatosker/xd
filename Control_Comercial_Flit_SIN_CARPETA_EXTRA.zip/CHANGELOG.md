# Registro de cambios

## v0.9.2+11

- Se corrigen las variables SQL nulas para Drift 2.35.4 usando `Variable<String>(null)` y `Variable<int>(null)`, respetando el límite genérico no anulable de Drift.
- Se resuelven las colisiones entre modelos de negocio y filas generadas por Drift ocultando en el import de `app_database.dart` los nombres `InventoryMovement`, `PriceChange` y `ProductNameChange`; las construcciones usan los modelos del dominio.
- Se garantiza que el precio de apertura utilizado por el servicio de cálculo sea no anulable, con `ExactDecimal.zero()` como respaldo cuando falte el precio inicial, sin eliminar el aviso de validación correspondiente.
- Se corrige la restricción de `drift_dev`: el repositorio de paquetes publica `drift_dev 2.35.3`, no `2.35.4`. Se mantiene `drift 2.35.4`, que sí existe y es compatible con `drift_dev 2.35.3`.
- Se declara `test` también en las dependencias de desarrollo raíz para que `flutter analyze` pueda resolver `package:test` al recorrer los archivos del motor comercial anidado.
- Se incorpora conciliación financiera del ciclo completo: venta estimada por inventario frente a efectivo recogido, gastos y reinversiones. Gastos y reinversiones se consideran una sola vez al reconstruir el Dinero de Venta.
- Se muestra el faltante (venta estimada mayor que Dinero de Venta), el sobrante (Dinero de Venta mayor que venta estimada) o la igualdad, y un desglose de efectivo, gastos y reinversiones para los seis turnos.
- El informe copiable añade la conciliación financiera y el desglose por turno sin eliminar las secciones anteriores.
- Se validan importes de efectivo y gastos negativos, conceptos vacíos, registros asociados a un turno incorrecto y movimientos vinculados a productos ajenos al catálogo. También se rechaza cerrar con inventario inicial negativo o con precio inicial cero/no configurado.
- El detalle de cada turno conserva y muestra cada gasto por concepto y cada reinversión por producto, además de sus totales; los movimientos individuales no se pierden en el resumen financiero.
- Se amplían las pruebas Dart para conciliación exacta, faltantes, sobrantes, movimientos individuales por turno y validación de registros financieros y de catálogo.
- No se considera posible atribuir el faltante/sobrante a un turno individual porque el inventario físico solo se cuenta al inicio y al final del ciclo. La aplicación muestra movimientos de cada turno y calcula la diferencia únicamente a nivel del ciclo completo.

## v0.9.1+10

- Corrección de borrado de gastos: la consulta de metadatos usa la estructura real de `expenses` y no intenta leer una columna `product_id` inexistente.
- El check-in nocturno del Día 3 utiliza `COALESCE` para tratar correctamente un catálogo vacío.
- Se bloquea el cierre completo cuando no se pudo crear la copia diaria del Día 3. El repositorio exige check-in vigente y comprueba que exista un archivo de copia diaria accesible y no vacío antes de cerrar, aunque se invoque fuera de la pantalla de cierre.
- Las operaciones de inventario, reinversiones y cambios de precio resuelven el nombre del producto según el turno efectivo. Las renombradas retroactivas reconstruyen el historial y las instantáneas por turno sin sobrescribir renombradas posteriores.
- La restauración valida claves foráneas en la base adjunta antes de cualquier sustitución y solo genera la copia preventiva cuando el archivo entrante ya superó las validaciones.
- La secuencia de ciclos y la propagación histórica aceptan mapas de inventario final vacíos para ciclos cerrados.
- Se amplían las comprobaciones independientes Python/SQLite de 29 a 35.
- Sigue pendiente ejecutar `flutter pub get`, `build_runner`, `dart format`, `flutter analyze`, `dart test` y `flutter build apk` en el PC del usuario.

# Registro de cambios

## v0.9.0+9

- La restauración de respaldos verifica `PRAGMA integrity_check` antes de modificar la base local. También comprueba versión de esquema, tablas obligatorias y claves foráneas.
- Se encapsulan las comprobaciones del archivo de respaldo en `BackupValidationService`, con pruebas unitarias para bases corruptas, versiones incompatibles, tablas faltantes y referencias inválidas.
- Cambiar el inventario final invalida, dentro de la misma transacción, el borrador de cierre si existe y el check-in nocturno si había sido realizado. Los ceros finales de los decimales se consideran parte del dato introducido.
- La corrección histórica marca los check-ins como modificados dentro de la transacción de corrección del inventario heredado.
- El historial presenta un texto legible para la invalidación del borrador por cambio del inventario final.
- Se añadieron tres verificaciones independientes de restauración íntegra, invalidación atómica del inventario final y check-ins históricos.

# Registro de cambios

## v0.8.0+8

- Cierre de ciclo + creación del siguiente ciclo dentro de una única transacción SQLite.
- Validación de inventario para retirar productos del catálogo activo: solo se permite saldo conocido exactamente cero.
- La verificación de saldo y la retirada se confirman en una sola transacción SQLite.
- El ciclo puede continuar aunque todos los productos de saldo cero se retiren; no se impone un producto activo obligatorio.
- El saldo calculado para retirada considera el inventario inicial, cortes de precio, entradas, reinversiones y bajas.
- Servicio de dominio `CatalogPolicy` con pruebas para saldo cero y positivo.
- Tres verificaciones independientes adicionales: atomicidad del cierre con rollback simulado, retirada segura y continuidad con un ciclo vacío.

## v0.7.0+7

- Check-in del tercer día y copia diaria comprobados antes del cierre completo.
- No se generan copias automáticas en ciclos exclusivamente de inventario.
- Revisión del PDF de la Biblia y correcciones de maquetación.

## Sobrante y faltante de dinero (cambio de conciliación)

- La conciliación del ciclo muestra una única diferencia neta: positiva es faltante, negativa es sobrante, cero cuadra.
- Las bajas se valoran a precio vigente en cada turno y se muestran como "Dinero perdido por bajas". No afectan a la diferencia, porque ya quedan fuera de la venta estimada.
- Efectivo, gastos, reinversiones y precios se introducen solo como importes enteros. Las cantidades de producto siguen admitiendo decimales.
- La venta estimada de cada tramo de precio se redondea al entero más cercano.
- Nuevos tests en `packages/business_core/test/reconciliation_test.dart`.

## Corrección de escrituras SQL

- Las llamadas `customStatement` pasaban objetos `Variable` como argumentos. Ahora reciben valores normales (`String`, `int`, `null`). Los `customSelect` siguen usando `variables:`.

## Comodidad diaria (bloque 1)

- Al registrar o editar un gasto, el concepto sugiere conceptos usados antes, del más frecuente al menos frecuente.
- Los importes de efectivo, gastos, reinversiones, precios de catálogo y precios de cambio abren el teclado de números enteros.

## Bloque 2: búsqueda de producto, deshacer, tema oscuro y cifras alineadas

- Búsqueda de producto en movimientos, reinversiones y cambios de precio: filtra mientras se escribe. Si el texto no coincide con un producto, el formulario avisa y no guarda con un producto distinto.
- Tras registrar una entrada, baja, gasto, reinversión o cambio de precio, aparece un aviso con "Deshacer" durante 6 segundos.
- Tema oscuro que sigue la configuración del teléfono. Las cifras usan ancho fijo para alinearse en columna.
- Los errores de carga muestran un mensaje que indica qué hacer, en lugar de la excepción técnica.
- Correcciones de análisis: guardas de contexto tras esperas y estilo.

## Bloque 3: selector de tema y turnos agrupados por día

- Ajustes → Apariencia: Automático, Claro u Oscuro. La elección se guarda y se aplica al instante.
- En el ciclo completo, cada día es una tarjeta con su estado de revisión, sus totales y sus dos turnos. El botón de revisión nocturna está dentro del día al que pertenece.

## Corrección de pruebas unitarias

- Los importes se muestran con separador de miles por defecto (6 000, 1 000), igual que en la pantalla y los informes.
- ExactDecimal compara por valor: 1,30 es igual a 1,3.

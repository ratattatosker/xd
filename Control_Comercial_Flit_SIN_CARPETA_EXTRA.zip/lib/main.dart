import 'package:flutter/material.dart';

import 'data/app_database.dart';
import 'data/app_repository.dart';
import 'data/catalog_seeder.dart';
import 'ui/app_theme.dart';
import 'ui/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final database = AppDatabase();
  await CatalogSeeder(database).seedIfEmpty();
  final repository = AppRepository(database);
  appThemeMode.value = themeModeFromName(await repository.getThemeMode());
  runApp(ControlComercialApp(database: database));
}

class ControlComercialApp extends StatelessWidget {
  const ControlComercialApp({super.key, required this.database});

  final AppDatabase database;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: appThemeMode,
      builder: (context, mode, _) => MaterialApp(
        title: 'Control Comercial',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(Brightness.light),
        darkTheme: buildAppTheme(Brightness.dark),
        themeMode: mode,
        home: HomePage(database: database),
      ),
    );
  }
}

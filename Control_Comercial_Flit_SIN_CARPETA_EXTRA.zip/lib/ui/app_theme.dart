import 'package:flutter/material.dart';

/// Modo de tema elegido por el usuario. Se guarda en la base de datos.
final ValueNotifier<ThemeMode> appThemeMode = ValueNotifier<ThemeMode>(ThemeMode.system);

ThemeMode themeModeFromName(String value) => switch (value) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };

String themeModeName(ThemeMode mode) => switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    };

const Color kSeedColor = Color(0xFF245B75);

/// Texto secundario. Pensado para legibilidad sobre fondo claro y oscuro.
const Color kMutedText = Color(0xFF6E7B82);

ThemeData buildAppTheme(Brightness brightness) {
  final isDark = brightness == Brightness.dark;
  final scheme = ColorScheme.fromSeed(seedColor: kSeedColor, brightness: brightness);
  final base = ThemeData(colorScheme: scheme, useMaterial3: true);
  return ThemeData(
    colorScheme: scheme,
    useMaterial3: true,
    scaffoldBackgroundColor: isDark ? const Color(0xFF101415) : const Color(0xFFF5F7F8),
    textTheme: _tabularNumbers(base.textTheme),
    cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: isDark ? scheme.surfaceContainerHigh : Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.outlineVariant),
      ),
    ),
  );
}

/// Cifras de igual anchura: los importes se alinean en columna.
TextTheme _tabularNumbers(TextTheme t) {
  const features = [FontFeature.tabularFigures()];
  TextStyle? f(TextStyle? style) => style?.copyWith(fontFeatures: features);
  return t.copyWith(
    displayLarge: f(t.displayLarge),
    displayMedium: f(t.displayMedium),
    displaySmall: f(t.displaySmall),
    headlineLarge: f(t.headlineLarge),
    headlineMedium: f(t.headlineMedium),
    headlineSmall: f(t.headlineSmall),
    titleLarge: f(t.titleLarge),
    titleMedium: f(t.titleMedium),
    titleSmall: f(t.titleSmall),
    bodyLarge: f(t.bodyLarge),
    bodyMedium: f(t.bodyMedium),
    bodySmall: f(t.bodySmall),
    labelLarge: f(t.labelLarge),
    labelMedium: f(t.labelMedium),
    labelSmall: f(t.labelSmall),
  );
}

/// Mensaje de error que indica qué hacer, sin mostrar la excepción como única información.
String friendlyLoadError(Object? error) =>
    'No se pudo cargar esta pantalla. Vuelve atrás y entra de nuevo.\n'
    'Si vuelve a pasar, anota este detalle: $error';

import 'package:flutter/material.dart';

import 'package:business_core/business_core.dart';
import '../../data/app_repository.dart';
import '../app_theme.dart';
import '../product_picker.dart';

class TurnEditorScreen extends StatefulWidget {
  const TurnEditorScreen({super.key, required this.repository, required this.cycle, required this.turnIndex});
  final AppRepository repository;
  final CycleRecord cycle;
  final int turnIndex;

  @override
  State<TurnEditorScreen> createState() => _TurnEditorScreenState();
}

class _TurnEditorScreenState extends State<TurnEditorScreen> {
  final _cashController = TextEditingController();
  late Future<_TurnViewData> _future = _load();
  bool _savingCash = false;
  bool _cashInitialized = false;

  Future<_TurnViewData> _load() async {
    final cash = await widget.repository.getTurnCash(widget.cycle.id, widget.turnIndex);
    final activities = await widget.repository.getTurnActivities(widget.cycle.id, widget.turnIndex);
    final products = await widget.repository.getProducts();
    final checkInState = await widget.repository.getDailyCheckInState(widget.cycle.id, widget.turnIndex ~/ 2);
    var moneyOfSale = cash;
    for (final activity in activities) {
      if (activity.kind == 'expenses' || activity.kind == 'reinvestments') {
        moneyOfSale = moneyOfSale + (activity.amount ?? ExactDecimal.zero());
      }
    }
    return _TurnViewData(
      cash: cash,
      moneyOfSale: moneyOfSale,
      activities: activities,
      products: products,
      checkInState: checkInState,
    );
  }

  @override
  void dispose() {
    _cashController.dispose();
    super.dispose();
  }

  void _reload() {
    setState(() {
      _cashInitialized = false;
      _future = _load();
    });
  }

  Future<void> _saveCash() async {
    setState(() => _savingCash = true);
    try {
      await widget.repository.setTurnCash(widget.cycle.id, widget.turnIndex, ExactDecimal.parseWhole(_cashController.text));
      _reload();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Efectivo guardado.')));
    } catch (error) {
      _error(error.toString());
    } finally {
      if (mounted) setState(() => _savingCash = false);
    }
  }

  Future<void> _addMovement(List<ProductRecord> products, MovementKind kind) async {
    if (products.isEmpty) return _error('No hay productos activos.');
    final result = await showDialog<_MovementForm>(
      context: context,
      builder: (_) => _MovementDialog(products: products, kind: kind),
    );
    if (result == null) return;
    await _runWithUndo('inventory_movements', () => widget.repository.addMovement(
      cycleId: widget.cycle.id,
      turnIndex: widget.turnIndex,
      productId: result.productId,
      quantity: result.quantity,
      kind: kind,
    ));
  }

  Future<void> _addExpense() async {
    final suggestions = await widget.repository.getExpenseConcepts();
    if (!mounted) return;
    final result = await showDialog<_ExpenseForm>(
      context: context,
      builder: (_) => _ExpenseDialog(suggestions: suggestions),
    );
    if (result == null) return;
    await _runWithUndo('expenses', () => widget.repository.addExpense(
      cycleId: widget.cycle.id,
      turnIndex: widget.turnIndex,
      concept: result.concept,
      amount: result.amount,
    ));
  }

  Future<void> _addReinvestment(List<ProductRecord> products) async {
    if (products.isEmpty) return _error('No hay productos activos.');
    final result = await showDialog<_ReinvestmentForm>(
      context: context,
      builder: (_) => _ReinvestmentDialog(products: products),
    );
    if (result == null) return;
    await _runWithUndo('reinvestments', () => widget.repository.addReinvestment(
      cycleId: widget.cycle.id,
      turnIndex: widget.turnIndex,
      productId: result.productId,
      quantity: result.quantity,
      amount: result.amount,
    ));
  }

  Future<void> _addPriceChange(List<ProductRecord> products) async {
    if (products.isEmpty) return _error('No hay productos activos.');
    final result = await showDialog<_PriceForm>(
      context: context,
      builder: (_) => _PriceChangeDialog(products: products),
    );
    if (result == null) return;
    await _runWithUndo('price_changes', () => widget.repository.addPriceChange(
      cycleId: widget.cycle.id,
      turnIndex: widget.turnIndex,
      productId: result.productId,
      newPrice: result.newPrice,
      balanceAtTurnStart: result.balance,
    ));
  }

  Future<void> _edit(TurnActivity activity, List<ProductRecord> products) async {
    // Para editar registros históricos del ciclo también incluimos productos
    // archivados: archivar no debe inutilizar la corrección de sus movimientos.
    final editProducts = await widget.repository.getProducts(activeOnly: false);
    if (!mounted) return;
    switch (activity.kind) {
      case 'inventory_movements':
        final result = await showDialog<_MovementForm>(
          context: context,
          builder: (_) => _MovementDialog(
            products: editProducts,
            kind: activity.movementKind!,
            initialProductId: activity.productId,
            initialQuantity: activity.quantity,
            allowProductChange: false,
          ),
        );
        if (result != null) {
          await _run(() => widget.repository.updateMovement(
                cycleId: widget.cycle.id,
                id: activity.id,
                turnIndex: widget.turnIndex,
                quantity: result.quantity,
              ));
        }
        break;
      case 'expenses':
        final editSuggestions = await widget.repository.getExpenseConcepts();
        if (!mounted) return;
        final result = await showDialog<_ExpenseForm>(
          context: context,
          builder: (_) => _ExpenseDialog(
            initialConcept: activity.concept,
            initialAmount: activity.amount,
            suggestions: editSuggestions,
          ),
        );
        if (result != null) {
          await _run(() => widget.repository.updateExpense(
                cycleId: widget.cycle.id,
                id: activity.id,
                turnIndex: widget.turnIndex,
                concept: result.concept,
                amount: result.amount,
              ));
        }
        break;
      case 'reinvestments':
        final result = await showDialog<_ReinvestmentForm>(
          context: context,
          builder: (_) => _ReinvestmentDialog(
            products: editProducts,
            initialProductId: activity.productId,
            initialQuantity: activity.quantity,
            initialAmount: activity.amount,
            allowProductChange: false,
          ),
        );
        if (result != null) {
          await _run(() => widget.repository.updateReinvestment(
                cycleId: widget.cycle.id,
                id: activity.id,
                turnIndex: widget.turnIndex,
                quantity: result.quantity,
                amount: result.amount,
              ));
        }
        break;
      case 'price_changes':
        final result = await showDialog<_PriceForm>(
          context: context,
          builder: (_) => _PriceChangeDialog(
            products: editProducts,
            initialProductId: activity.productId,
            initialPrice: activity.newPrice,
            initialBalance: activity.balanceAtTurnStart,
            allowProductChange: false,
          ),
        );
        if (result != null) {
          await _run(() => widget.repository.updatePriceChange(
                cycleId: widget.cycle.id,
                id: activity.id,
                turnIndex: widget.turnIndex,
                newPrice: result.newPrice,
                balanceAtTurnStart: result.balance,
              ));
        }
        break;
      default:
        _error('Este registro no admite edición directa.');
    }
  }

  Future<void> _delete(TurnActivity activity) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar registro'),
        content: Text('¿Eliminar «${activity.title}»?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Eliminar')),
        ],
      ),
    );
    if (confirm != true) return;
    await _run(() => widget.repository.deleteTurnRecord(table: activity.kind, id: activity.id, cycleId: widget.cycle.id));
  }

  /// Tras registrar una alta, ofrece deshacerla durante unos segundos.
  Future<void> _runWithUndo(String table, Future<String> Function() action) async {
    String? recordId;
    await _run(() async {
      recordId = await action();
    });
    final id = recordId;
    if (id == null || !mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Registro guardado.'),
        duration: const Duration(seconds: 6),
        action: SnackBarAction(
          label: 'Deshacer',
          onPressed: () => _run(() => widget.repository.deleteTurnRecord(
                table: table,
                id: id,
                cycleId: widget.cycle.id,
              )),
        ),
      ),
    );
  }

  Future<void> _run(Future<void> Function() action) async {
    try {
      await action();
      _reload();
    } catch (error) {
      if (error is NegativeInventoryException && error.canCorrectPreviousInventoryCycle) {
        await _offerPreviousCycleCorrection(error);
      } else {
        _error(error.toString());
      }
    }
  }

  Future<void> _offerPreviousCycleCorrection(NegativeInventoryException incident) async {
    final predecessorId = incident.predecessorCycleId;
    if (predecessorId == null) {
      _error(incident.toString());
      return;
    }
    try {
      final predecessor = await widget.repository.getCycleById(predecessorId);
      final lines = await widget.repository.getInventoryLines(predecessorId);
      final productLines = lines.where((line) => line.productId == incident.productId).toList();
      if (predecessor == null || productLines.isEmpty || productLines.first.finalQuantity == null) {
        _error('No se pudo localizar el inventario final del ciclo anterior. ${incident.toString()}');
        return;
      }
      final line = productLines.first;
      final controller = TextEditingController(text: line.finalQuantity!.toLocalizedString());
      if (!mounted) return;
      final corrected = await showDialog<ExactDecimal>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Corregir inventario del ciclo anterior'),
          content: SizedBox(
            width: 480,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('La operación no se guardó porque ${incident.productName} quedaría en negativo en ${CalculationService.turnLabel(incident.turnIndex)}.'),
                const SizedBox(height: 12),
                Text('Se detectó un faltante de ${incident.shortfall.toLocalizedString()} unidades respecto al inventario inicial heredado.'),
                const SizedBox(height: 12),
                Text('El ciclo ${predecessor.sequenceNumber} es el ciclo exclusivamente de inventario que aportó ese saldo. Puedes reabrirlo para corregir solo el final de este producto.'),
                const SizedBox(height: 12),
                Text('Inventario final actual: ${line.finalQuantity!.toLocalizedString()}'),
                Text('Mínimo para que la operación pueda registrarse: ${incident.minimumPredecessorFinal.toLocalizedString()}'),
                const SizedBox(height: 10),
                TextField(
                  controller: controller,
                  autofocus: true,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Inventario final corregido'),
                ),
                const SizedBox(height: 8),
                const Text('Se conservarán los demás finales físicos y todos los movimientos. Después de corregir, vuelve a registrar la operación que fue rechazada.', style: TextStyle(color: kMutedText, fontSize: 12, height: 1.4)),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
            FilledButton(
              onPressed: () {
                try {
                  final value = ExactDecimal.parse(controller.text);
                  if (value.isNegative) throw ArgumentError('El inventario corregido no puede ser negativo.');
                  if (value.compareTo(incident.minimumPredecessorFinal) < 0) {
                    throw ArgumentError('Introduce al menos ${incident.minimumPredecessorFinal.toLocalizedString()}.');
                  }
                  Navigator.pop(dialogContext, value);
                } catch (error) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(SnackBar(content: Text(error.toString())));
                }
              },
              child: const Text('Reabrir y corregir'),
            ),
          ],
        ),
      );
      controller.dispose();
      if (corrected == null) {
        _error(incident.toString());
        return;
      }
      await widget.repository.correctPreviousInventoryCycleForNegativeBalance(
        incident: incident,
        correctedFinalQuantity: corrected,
      );
      _reload();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ciclo ${predecessor.sequenceNumber} corregido y auditado. El movimiento rechazado sigue sin guardarse; vuelve a registrarlo.')),
        );
      }
    } catch (error) {
      _error(error.toString());
    }
  }

  void _error(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(CalculationService.turnLabel(widget.turnIndex))),
      body: FutureBuilder<_TurnViewData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(friendlyLoadError(snapshot.error), textAlign: TextAlign.center)));
          final data = snapshot.data!;
          if (!_cashInitialized) {
            _cashController.text = data.cash.toLocalizedString();
            _cashInitialized = true;
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Dinero Efectivo', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _cashController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(prefixText: '\$ ', hintText: '0'),
                    ),
                    const SizedBox(height: 10),
                    Align(
                      alignment: Alignment.centerRight,
                      child: FilledButton.tonal(
                        onPressed: _savingCash ? null : _saveCash,
                        child: Text(_savingCash ? 'Guardando…' : 'Guardar efectivo'),
                      ),
                    ),
                    const Divider(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Dinero de Venta calculado', style: TextStyle(color: kMutedText)),
                              Text(
                                '\$${data.moneyOfSale.toLocalizedString(groupThousands: true)}',
                                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.calculate_outlined, size: 28),
                      ],
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Efectivo + gastos + reinversiones. Las entradas y bajas no intervienen en este cálculo.',
                      style: TextStyle(color: kMutedText, fontSize: 12, height: 1.35),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 16),
              Text('Añadir operación', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                _ActionChip(icon: Icons.add_box_outlined, label: 'Entrada', onTap: () => _addMovement(data.products, MovementKind.entry)),
                _ActionChip(icon: Icons.remove_circle_outline, label: 'Baja', onTap: () => _addMovement(data.products, MovementKind.loss)),
                _ActionChip(icon: Icons.receipt_long, label: 'Gasto', onTap: _addExpense),
                _ActionChip(icon: Icons.shopping_bag_outlined, label: 'Reinversión', onTap: () => _addReinvestment(data.products)),
                _ActionChip(icon: Icons.price_change_outlined, label: 'Cambio de precio', onTap: () => _addPriceChange(data.products)),
              ]),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(child: Text('Registros de este turno', style: Theme.of(context).textTheme.titleMedium)),
                Text('${data.activities.length}', style: const TextStyle(color: kMutedText)),
              ]),
              const SizedBox(height: 8),
              if (data.activities.isEmpty)
                const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Todavía no hay operaciones registradas.')))
              else
                ...data.activities.map((activity) => Card(
                  child: ListTile(
                    title: Text(activity.title),
                    subtitle: Text(activity.subtitle),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(activity.quantityOrAmount, style: const TextStyle(fontWeight: FontWeight.w600)),
                      IconButton(tooltip: 'Editar registro', onPressed: () => _edit(activity, data.products), icon: const Icon(Icons.edit_outlined)),
                      IconButton(tooltip: 'Eliminar registro', onPressed: () => _delete(activity), icon: const Icon(Icons.delete_outline)),
                    ]),
                  ),
                )),
              if (data.checkInState == 'modified-after-check-in') ...[
                const SizedBox(height: 12),
                const Card(child: ListTile(leading: Icon(Icons.warning_amber), title: Text('Este día fue modificado después del check-in'), subtitle: Text('Vuelve al ciclo para repetir la revisión nocturna y actualizar la copia diaria.'))),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _TurnViewData {
  const _TurnViewData({
    required this.cash,
    required this.moneyOfSale,
    required this.activities,
    required this.products,
    required this.checkInState,
  });
  final ExactDecimal cash;
  final ExactDecimal moneyOfSale;
  final List<TurnActivity> activities;
  final List<ProductRecord> products;
  final String? checkInState;
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ActionChip(avatar: Icon(icon, size: 18), label: Text(label), onPressed: onTap);
}

class _MovementForm {
  const _MovementForm(this.productId, this.quantity);
  final String productId;
  final ExactDecimal quantity;
}

class _MovementDialog extends StatefulWidget {
  const _MovementDialog({
    required this.products,
    required this.kind,
    this.initialProductId,
    this.initialQuantity,
    this.allowProductChange = true,
  });
  final List<ProductRecord> products;
  final MovementKind kind;
  final String? initialProductId;
  final ExactDecimal? initialQuantity;
  final bool allowProductChange;
  @override
  State<_MovementDialog> createState() => _MovementDialogState();
}

class _MovementDialogState extends State<_MovementDialog> {
  String? _productId;
  final _quantity = TextEditingController();
  @override
  void initState() {
    super.initState();
    _productId = widget.initialProductId ??
        (widget.products.isEmpty ? null : widget.products.first.id);
    _quantity.text = widget.initialQuantity?.toLocalizedString() ?? '';
  }
  @override
  void dispose() { _quantity.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.initialQuantity == null ? (widget.kind == MovementKind.entry ? 'Registrar entrada' : 'Registrar baja') : (widget.kind == MovementKind.entry ? 'Editar entrada' : 'Editar baja')),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      ProductPicker(
        products: widget.products,
        initialProductId: _productId,
        enabled: widget.allowProductChange,
        onChanged: (id) => setState(() => _productId = id),
      ),
      const SizedBox(height: 10),
      TextField(controller: _quantity, autofocus: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Cantidad')),
    ]),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
      FilledButton(onPressed: () {
        try { Navigator.pop(context, _MovementForm(requireProductId(_productId), ExactDecimal.parse(_quantity.text))); }
        catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
      }, child: const Text('Guardar')),
    ],
  );
}

class _ExpenseForm {
  const _ExpenseForm(this.concept, this.amount);
  final String concept;
  final ExactDecimal amount;
}

class _ExpenseDialog extends StatefulWidget {
  const _ExpenseDialog({this.initialConcept, this.initialAmount, this.suggestions = const []});
  final String? initialConcept;
  final ExactDecimal? initialAmount;
  final List<String> suggestions;
  @override
  State<_ExpenseDialog> createState() => _ExpenseDialogState();
}

class _ExpenseDialogState extends State<_ExpenseDialog> {
  final _amount = TextEditingController();
  TextEditingController? _conceptController;

  @override
  void initState() {
    super.initState();
    _amount.text = widget.initialAmount?.toLocalizedString() ?? '';
  }

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  String get _concept => (_conceptController?.text ?? widget.initialConcept ?? '').trim();

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.initialConcept == null ? 'Registrar gasto' : 'Editar gasto'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      Autocomplete<String>(
        initialValue: TextEditingValue(text: widget.initialConcept ?? ''),
        optionsBuilder: (value) {
          final query = value.text.trim().toLowerCase();
          if (query.isEmpty) return widget.suggestions;
          return widget.suggestions.where((s) {
            final lower = s.toLowerCase();
            return lower.contains(query) && lower != query;
          });
        },
        onSelected: (value) {
          _conceptController?.text = value;
        },
        fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
          _conceptController = controller;
          return TextField(
            controller: controller,
            focusNode: focusNode,
            autofocus: true,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: 'Concepto'),
          );
        },
      ),
      const SizedBox(height: 10),
      TextField(
        controller: _amount,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Importe', prefixText: '\$ '),
      ),
    ]),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
      FilledButton(onPressed: () {
        try { Navigator.pop(context, _ExpenseForm(_concept, ExactDecimal.parseWhole(_amount.text))); }
        catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
      }, child: const Text('Guardar')),
    ],
  );
}

class _ReinvestmentForm {
  const _ReinvestmentForm(this.productId, this.quantity, this.amount);
  final String productId;
  final ExactDecimal quantity;
  final ExactDecimal amount;
}

class _ReinvestmentDialog extends StatefulWidget {
  const _ReinvestmentDialog({
    required this.products,
    this.initialProductId,
    this.initialQuantity,
    this.initialAmount,
    this.allowProductChange = true,
  });
  final List<ProductRecord> products;
  final String? initialProductId;
  final ExactDecimal? initialQuantity;
  final ExactDecimal? initialAmount;
  final bool allowProductChange;
  @override
  State<_ReinvestmentDialog> createState() => _ReinvestmentDialogState();
}

class _ReinvestmentDialogState extends State<_ReinvestmentDialog> {
  String? _productId;
  final _quantity = TextEditingController();
  final _amount = TextEditingController();
  @override
  void initState() {
    super.initState();
    _productId = widget.initialProductId ??
        (widget.products.isEmpty ? null : widget.products.first.id);
    _quantity.text = widget.initialQuantity?.toLocalizedString() ?? '';
    _amount.text = widget.initialAmount?.toLocalizedString() ?? '';
  }
  @override
  void dispose() { _quantity.dispose(); _amount.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.initialQuantity == null ? 'Registrar reinversión' : 'Editar reinversión'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      ProductPicker(products: widget.products, initialProductId: _productId, enabled: widget.allowProductChange, onChanged: (id) => setState(() => _productId = id)),
      const SizedBox(height: 10),
      TextField(controller: _quantity, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Cantidad comprada')),
      const SizedBox(height: 10),
      TextField(controller: _amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Importe total invertido', prefixText: '\$ ')),
    ]),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
      FilledButton(onPressed: () {
        try { Navigator.pop(context, _ReinvestmentForm(requireProductId(_productId), ExactDecimal.parse(_quantity.text), ExactDecimal.parseWhole(_amount.text))); }
        catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
      }, child: const Text('Guardar')),
    ],
  );
}

class _PriceForm {
  const _PriceForm(this.productId, this.newPrice, this.balance);
  final String productId;
  final ExactDecimal newPrice;
  final ExactDecimal balance;
}

class _PriceChangeDialog extends StatefulWidget {
  const _PriceChangeDialog({
    required this.products,
    this.initialProductId,
    this.initialPrice,
    this.initialBalance,
    this.allowProductChange = true,
  });
  final List<ProductRecord> products;
  final String? initialProductId;
  final ExactDecimal? initialPrice;
  final ExactDecimal? initialBalance;
  final bool allowProductChange;
  @override
  State<_PriceChangeDialog> createState() => _PriceChangeDialogState();
}

class _PriceChangeDialogState extends State<_PriceChangeDialog> {
  String? _productId;
  final _newPrice = TextEditingController();
  final _balance = TextEditingController();
  @override
  void initState() {
    super.initState();
    _productId = widget.initialProductId ??
        (widget.products.isEmpty ? null : widget.products.first.id);
    _newPrice.text = widget.initialPrice?.toLocalizedString() ?? '';
    _balance.text = widget.initialBalance?.toLocalizedString() ?? '';
  }
  @override
  void dispose() { _newPrice.dispose(); _balance.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.initialPrice == null ? 'Cambio de precio' : 'Editar cambio de precio'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      ProductPicker(products: widget.products, initialProductId: _productId, enabled: widget.allowProductChange, onChanged: (id) => setState(() => _productId = id)),
      const SizedBox(height: 10),
      TextField(controller: _newPrice, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Precio nuevo', prefixText: '\$ ')),
      const SizedBox(height: 10),
      TextField(controller: _balance, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Unidades disponibles al inicio de este turno')),
      const SizedBox(height: 8),
      const Text('El cambio rige desde el inicio de este turno. No puede repetirse para el mismo producto durante el mismo día.', style: TextStyle(color: kMutedText, fontSize: 12)),
    ]),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
      FilledButton(onPressed: () {
        try { Navigator.pop(context, _PriceForm(requireProductId(_productId), ExactDecimal.parseWhole(_newPrice.text), ExactDecimal.parse(_balance.text))); }
        catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
      }, child: const Text('Guardar cambio')),
    ],
  );
}

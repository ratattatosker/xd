import 'package:flutter/material.dart';
import '../app_theme.dart';

import 'package:business_core/business_core.dart';
import '../../data/app_repository.dart';

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key, required this.repository});
  final AppRepository repository;

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  late Future<List<ProductRecord>> _products = widget.repository.getProducts(activeOnly: false);
  bool _showArchived = false;

  void _reload() => setState(() => _products = widget.repository.getProducts(activeOnly: false));

  Future<void> _addProduct() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => _ProductDialog(repository: widget.repository),
    );
    if (result == true) _reload();
  }

  Future<void> _editProduct(ProductRecord product) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => _ProductDialog(repository: widget.repository, product: product),
    );
    if (result == true) _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Catálogo de productos')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addProduct,
        icon: const Icon(Icons.add),
        label: const Text('Producto'),
      ),
      body: FutureBuilder<List<ProductRecord>>(
        future: _products,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(friendlyLoadError(snapshot.error), textAlign: TextAlign.center)));
          final all = snapshot.data ?? const <ProductRecord>[];
          final visible = all.where((p) => _showArchived || p.active).toList();
          return Column(children: [
            SwitchListTile(
              title: const Text('Mostrar productos retirados'),
              value: _showArchived,
              onChanged: (value) => setState(() => _showArchived = value),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('${all.where((p) => p.active).length} productos activos · ${all.length} en total',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(color: kMutedText)),
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                itemCount: visible.length,
                separatorBuilder: (_, _) => const SizedBox(height: 6),
                itemBuilder: (context, index) {
                  final product = visible[index];
                  return Card(
                    child: ListTile(
                      title: Text(product.name, style: TextStyle(color: product.active ? null : Colors.black45)),
                      subtitle: Text('Precio: \$${product.price.toLocalizedString(groupThousands: true)}${product.active ? '' : ' · Retirado'}'),
                      trailing: IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _editProduct(product)),
                      onTap: () => _editProduct(product),
                    ),
                  );
                },
              ),
            ),
          ]);
        },
      ),
    );
  }
}

class _ProductDialog extends StatefulWidget {
  const _ProductDialog({required this.repository, this.product});
  final AppRepository repository;
  final ProductRecord? product;

  @override
  State<_ProductDialog> createState() => _ProductDialogState();
}

class _ProductDialogState extends State<_ProductDialog> {
  late final TextEditingController _name = TextEditingController(text: widget.product?.name ?? '');
  late final TextEditingController _price = TextEditingController(text: widget.product?.price.toLocalizedString() ?? '0');
  int _effectiveTurn = 0;
  bool _active = true;
  bool _saving = false;
  bool _cycleLoading = true;
  String? _cycleLoadError;
  CycleRecord? _cycle;

  @override
  void initState() {
    super.initState();
    _active = widget.product?.active ?? true;
    _loadCurrentCycle();
  }

  Future<void> _loadCurrentCycle() async {
    try {
      final value = await widget.repository.getCurrentCycle();
      if (!mounted) return;
      setState(() {
        _cycle = value;
        _cycleLoading = false;
        _cycleLoadError = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _cycleLoading = false;
        _cycleLoadError = error.toString();
      });
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _price.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_cycleLoading) return;
    if (_cycleLoadError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No se pudo comprobar el ciclo activo: $_cycleLoadError')),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      final currentCycle = await widget.repository.getCurrentCycle();
      if (widget.product == null) {
        await widget.repository.addProduct(name: _name.text, price: ExactDecimal.parseWhole(_price.text));
      } else {
        final product = widget.product!;
        if (_name.text.trim() != product.name) {
          await widget.repository.renameProduct(
            productId: product.id,
            newName: _name.text,
            effectiveTurnIndex: currentCycle?.kind == CycleKind.full ? _effectiveTurn : null,
          );
        }
        if (_price.text.trim().isNotEmpty && ExactDecimal.parseWhole(_price.text).compareTo(product.price) != 0) {
          await widget.repository.updateProductPriceOutsideCycle(product.id, ExactDecimal.parseWhole(_price.text));
        }
        if (_active != product.active) await widget.repository.setProductActive(product.id, _active);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.product != null;
    final priceCanChange = !editing || (!_cycleLoading && _cycleLoadError == null &&
        (_cycle == null || _cycle!.kind == CycleKind.inventoryOnly));
    return AlertDialog(
      title: Text(editing ? 'Editar producto' : 'Nuevo producto'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (_cycleLoading) const LinearProgressIndicator(),
            if (_cycleLoadError != null)
              Text('No se pudo leer el ciclo activo: $_cycleLoadError', style: TextStyle(color: Theme.of(context).colorScheme.error)),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Nombre del producto')),
            const SizedBox(height: 12),
            TextField(
              controller: _price,
              enabled: priceCanChange,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Precio de venta actual',
                prefixText: '\$ ',
                helperText: priceCanChange ? 'Acepta coma o punto decimal.' : 'Durante un ciclo completo, usa el formulario Cambio de Precio.',
              ),
            ),
            if (editing && _cycle?.kind == CycleKind.full) ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                initialValue: _effectiveTurn,
                decoration: const InputDecoration(labelText: 'Aplicar nombre desde'),
                items: List.generate(6, (i) => DropdownMenuItem(value: i, child: Text(_turnLabel(i)))),
                onChanged: (value) => setState(() => _effectiveTurn = value ?? 0),
              ),
            ],
            if (editing)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Producto activo'),
                subtitle: const Text('Al retirarlo, el historial se conserva.'),
                value: _active,
                onChanged: (value) => setState(() => _active = value),
              ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _saving ? null : () => Navigator.pop(context, false), child: const Text('Cancelar')),
        FilledButton(
          onPressed: _saving || _cycleLoading || _cycleLoadError != null ? null : _save,
          child: Text(_saving ? 'Guardando…' : 'Guardar'),
        ),
      ],
    );
  }

  String _turnLabel(int index) => const [
    'Día 1 Matutino', 'Día 1 Nocturno', 'Día 2 Matutino',
    'Día 2 Nocturno', 'Día 3 Matutino', 'Día 3 Nocturno',
  ][index];
}

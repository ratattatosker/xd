import 'package:flutter/material.dart';
import '../app_theme.dart';
import 'package:flutter/services.dart';

import 'package:business_core/business_core.dart';
import '../../data/app_repository.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key, required this.repository});
  final AppRepository repository;

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  late Future<List<CycleRecord>> _cycles = widget.repository.getCycleHistory();
  void _reload() => setState(() => _cycles = widget.repository.getCycleHistory());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Historial de ciclos')),
      body: FutureBuilder<List<CycleRecord>>(
        future: _cycles,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(friendlyLoadError(snapshot.error), textAlign: TextAlign.center)));
          final cycles = snapshot.data ?? const <CycleRecord>[];
          if (cycles.isEmpty) return const Center(child: Text('Todavía no hay ciclos guardados.'));
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: cycles.length,
              separatorBuilder: (_, _) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final cycle = cycles[index];
                return Card(
                  child: ListTile(
                    leading: Icon(cycle.kind == CycleKind.full ? Icons.receipt_long : Icons.inventory_2_outlined),
                    title: Text('Ciclo ${cycle.sequenceNumber} · ${cycle.kindLabel}'),
                    subtitle: Text('${_date(cycle.startDate)} - ${_date(cycle.endDate)} · ${cycle.statusLabel}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _showCycle(cycle),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Future<void> _showCycle(CycleRecord cycle) async {
    final report = cycle.kind == CycleKind.full ? await widget.repository.getLatestReport(cycle.id) : null;
    final calculation = cycle.kind == CycleKind.full ? await widget.repository.calculateCycle(cycle.id) : null;
    final revisions = await widget.repository.getCycleRevisions(cycle.id);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Ciclo ${cycle.sequenceNumber}'),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text('${cycle.kindLabel}\n${_date(cycle.startDate)} - ${_date(cycle.endDate)}\n${cycle.statusLabel}'),
              if (calculation != null) ...[
                const Divider(height: 24),
                if (calculation.issues.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      'Hay inconsistencias en los datos de este ciclo:\n${calculation.issues.join('\n')}',
                      style: TextStyle(color: Theme.of(context).colorScheme.error, fontSize: 12),
                    ),
                  ),
                Text('Venta estimada por inventario: \$${calculation.totalEstimatedSales.toLocalizedString(groupThousands: true)}'),
                Text('Dinero de Venta: \$${calculation.totalMoneyOfSale.toLocalizedString(groupThousands: true)}'),
                Text('Dinero Recogido: \$${calculation.totalCashCollected.toLocalizedString(groupThousands: true)}'),
                Text('Gastos: \$${calculation.totalExpenses.toLocalizedString(groupThousands: true)}'),
                Text('Reinversiones: \$${calculation.totalReinvestments.toLocalizedString(groupThousands: true)}'),
                const SizedBox(height: 6),
                Text(
                  calculation.financialReconciliation.isBalanced
                      ? 'Sin diferencia financiera'
                      : calculation.financialReconciliation.shortfall.isZero
                          ? 'Sobrante respecto a la venta estimada: \$${calculation.financialReconciliation.surplus.toLocalizedString(groupThousands: true)}'
                          : 'Faltante respecto a la venta estimada: \$${calculation.financialReconciliation.shortfall.toLocalizedString(groupThousands: true)}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                Text('Dinero perdido por bajas: \$${calculation.financialReconciliation.lossesValue.toLocalizedString(groupThousands: true)}'),
                if (calculation.financialReconciliation.expectedCashAfterMovements.isNegative)
                  const Text(
                    'Advertencia: gastos y reinversiones superan la venta estimada; revisa esos movimientos y cualquier saldo externo.',
                    style: TextStyle(color: Colors.deepOrange, fontSize: 12),
                  ),
                const SizedBox(height: 8),
                Text('${calculation.salarySummary.morningWorkerName}: \$${calculation.salarySummary.morningSalary.toLocalizedString(groupThousands: true)}'),
                Text('${calculation.salarySummary.nightWorkerName}: \$${calculation.salarySummary.nightSalary.toLocalizedString(groupThousands: true)}'),
              ],
              if (report != null) ...[
                const Divider(height: 24),
                Row(
                  children: [
                    const Expanded(child: Text('Informe de cierre', style: TextStyle(fontWeight: FontWeight.bold))),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final messenger = ScaffoldMessenger.of(context);
                        await Clipboard.setData(ClipboardData(text: report));
                        messenger.showSnackBar(
                          const SnackBar(content: Text('Informe histórico copiado.')),
                        );
                      },
                      icon: const Icon(Icons.copy_outlined, size: 18),
                      label: const Text('Copiar'),
                    ),
                  ],
                ),
                SelectableText(report),
              ],
              if (revisions.isNotEmpty) ...[
                const Divider(height: 24),
                const Text('Registro de revisiones', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                ...revisions.map((revision) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_revisionLabel(revision.action), style: const TextStyle(fontWeight: FontWeight.w600)),
                    Text('${_dateTime(revision.changedAt)} · revisión ${revision.revisionNumber}', style: const TextStyle(color: kMutedText, fontSize: 12)),
                    if (revision.payload['productName'] != null)
                      Text('Producto: ${revision.payload['productName']}'),
                    if (revision.payload['oldFinal'] != null && revision.payload['newFinal'] != null)
                      Text('Final anterior: ${revision.payload['oldFinal']} · Final corregido: ${revision.payload['newFinal']}'),
                  ]),
                )),
              ],
            ]),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar'))],
      ),
    );
  }

  String _revisionLabel(String action) => switch (action) {
    'historical_cycle_reopened_for_negative_inventory' => 'Reapertura por inventario negativo',
    'historical_cycle_closed_after_inventory_correction' => 'Cierre tras corregir inventario',
    'opening_inventory_refreshed_from_predecessor_correction' => 'Inventario inicial actualizado desde el ciclo anterior',
    'close_draft_invalidated_by_edit' => 'Borrador de cierre invalidado por una edición',
    'close_draft_invalidated_by_final_inventory_edit' => 'Borrador invalidado por modificación del inventario final',
    'close_draft_invalidated_by_historical_inventory_correction' => 'Borrador de cierre invalidado por corrección histórica',
    'inventory_cycle_close_draft_invalidated_by_catalog_edit' => 'Borrador de inventario invalidado por cambio de catálogo',
    'cycle_closed' => 'Ciclo cerrado',
    _ => action,
  };

  String _date(DateTime date) => '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${(date.year % 100).toString().padLeft(2, '0')}';
  String _dateTime(DateTime date) => '${_date(date)} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
}

import 'package:flutter/material.dart';
import '../app_theme.dart';

import 'package:business_core/business_core.dart';
import '../../data/app_repository.dart';
import '../../services/backup_service.dart';
import 'final_inventory_screen.dart';
import 'turn_editor_screen.dart';

class CycleWorkspaceScreen extends StatefulWidget {
  const CycleWorkspaceScreen({super.key, required this.repository, required this.cycle});
  final AppRepository repository;
  final CycleRecord cycle;

  @override
  State<CycleWorkspaceScreen> createState() => _CycleWorkspaceScreenState();
}

class _CycleWorkspaceScreenState extends State<CycleWorkspaceScreen> {
  late Future<_WorkspaceData> _future = _load();
  bool _busy = false;

  Future<_WorkspaceData> _load() async {
    final data = await widget.repository.loadCycleData(widget.cycle.id);
    final lines = await widget.repository.getInventoryLines(widget.cycle.id);
    final dayStates = <int, String?>{};
    if (widget.cycle.kind == CycleKind.full) {
      for (var day = 0; day < 3; day++) {
        dayStates[day] = await widget.repository.getDailyCheckInState(widget.cycle.id, day);
      }
    }
    return _WorkspaceData(data: data, lines: lines, dayStates: dayStates);
  }

  void _reload() => setState(() => _future = _load());

  Future<void> _editTurn(int index) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => TurnEditorScreen(repository: widget.repository, cycle: widget.cycle, turnIndex: index),
    ));
    _reload();
  }

  Future<void> _checkIn(int dayIndex) async {
    setState(() => _busy = true);
    try {
      final businessDate = widget.cycle.startDate.add(Duration(days: dayIndex));
      // Primero la copia: si falla, la revisión no queda registrada.
      final artifact = await BackupService(widget.repository.database).createDailyBackup(
        cycleId: widget.cycle.id,
        businessDate: businessDate,
      );
      await widget.repository.checkInDay(widget.cycle.id, dayIndex);
      _reload();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Revisión guardada. Copia diaria creada: ${artifact.file.path}')));
      }
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openFinalInventory() async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => FinalInventoryScreen(repository: widget.repository, cycle: widget.cycle),
    ));
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    final full = widget.cycle.kind == CycleKind.full;
    return Scaffold(
      appBar: AppBar(title: Text('Ciclo ${widget.cycle.sequenceNumber}')),
      body: FutureBuilder<_WorkspaceData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(friendlyLoadError(snapshot.error), textAlign: TextAlign.center)));
          final data = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(full ? 'Ciclo completo' : 'Ciclo exclusivamente de inventario', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 6),
                    Text('${_date(widget.cycle.startDate)} - ${_date(widget.cycle.endDate)} · ${widget.cycle.statusLabel}'),
                    const SizedBox(height: 10),
                    Text(full
                        ? 'Puedes abrir y modificar cualquiera de los seis turnos a cualquier hora.'
                        : 'Durante estos tres días no se registran turnos ni movimientos. Al terminar, introduce únicamente los inventarios finales.'),
                  ]),
                ),
              ),
              const SizedBox(height: 16),
              if (full) ...[
                for (var day = 0; day < 3; day++) ...[
                  _DayCard(
                    dayNumber: day + 1,
                    date: _date(widget.cycle.startDate.add(Duration(days: day))),
                    morning: data.data.turns.firstWhere((turn) => turn.index == day * 2),
                    night: data.data.turns.firstWhere((turn) => turn.index == day * 2 + 1),
                    checkState: data.dayStates[day],
                    busy: _busy,
                    onEditTurn: _editTurn,
                    onCheckIn: () => _checkIn(day),
                  ),
                  const SizedBox(height: 12),
                ],
                const Text(
                  'El check-in nocturno crea una copia diaria de seguridad. No bloquea la edición de los turnos.',
                  style: TextStyle(color: kMutedText, height: 1.4),
                ),
              ] else ...[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Row(children: [Icon(Icons.info_outline), SizedBox(width: 8), Text('Solo inventario', style: TextStyle(fontWeight: FontWeight.bold))]),
                      const SizedBox(height: 8),
                      Text('${data.lines.length} productos incluidos en el conteo.'),
                      const SizedBox(height: 6),
                      const Text('Este tipo de ciclo no genera copias automáticas ni salarios.', style: TextStyle(color: kMutedText)),
                    ]),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _busy ? null : _openFinalInventory,
                icon: const Icon(Icons.inventory_2_outlined),
                label: Text(full ? 'Registrar inventario final y revisar cierre' : 'Registrar inventario final del ciclo'),
              ),
              const SizedBox(height: 10),
              const Text('Los turnos no cambian automáticamente con la hora. El cierre y el comienzo del siguiente ciclo requieren confirmación.',
                  style: TextStyle(color: kMutedText, height: 1.4, fontSize: 12)),
            ],
          );
        },
      ),
    );
  }

  String _date(DateTime date) => '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${(date.year % 100).toString().padLeft(2, '0')}';
}

class _DailyMetric extends StatelessWidget {
  const _DailyMetric({required this.label, required this.value});
  final String label;
  final ExactDecimal value;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: kMutedText, fontSize: 12)),
          const SizedBox(height: 2),
          Text('\$${value.toLocalizedString(groupThousands: true)}',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
        ],
      );
}

class _DayCard extends StatelessWidget {
  const _DayCard({
    required this.dayNumber,
    required this.date,
    required this.morning,
    required this.night,
    required this.checkState,
    required this.busy,
    required this.onEditTurn,
    required this.onCheckIn,
  });

  final int dayNumber;
  final String date;
  final TurnData morning;
  final TurnData night;
  final String? checkState;
  final bool busy;
  final void Function(int index) onEditTurn;
  final VoidCallback onCheckIn;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final modified = checkState == 'modified-after-check-in';
    final checkedIn = checkState != null && !modified;
    final cash = morning.cashCollected + night.cashCollected;
    final sale = morning.moneyOfSale + night.moneyOfSale;
    final status = modified
        ? 'Cambió después de revisar'
        : checkedIn
            ? 'Revisado'
            : 'Pendiente de revisar';
    final statusColor = modified
        ? theme.colorScheme.error
        : checkedIn
            ? Colors.green.shade700
            : kMutedText;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Día $dayNumber · $date',
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
                Chip(
                  label: Text(status),
                  visualDensity: VisualDensity.compact,
                  side: BorderSide.none,
                  backgroundColor: statusColor.withValues(alpha: 0.12),
                  labelStyle: TextStyle(color: statusColor, fontWeight: FontWeight.w600),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _DailyMetric(label: 'Dinero Recogido', value: cash)),
                const SizedBox(width: 12),
                Expanded(child: _DailyMetric(label: 'Dinero de Venta', value: sale)),
              ],
            ),
            const Divider(height: 24),
            _TurnTile(label: 'Matutino', turn: morning, onTap: () => onEditTurn(morning.index)),
            _TurnTile(label: 'Nocturno', turn: night, onTap: () => onEditTurn(night.index)),
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.centerRight,
              child: OutlinedButton.icon(
                onPressed: busy ? null : onCheckIn,
                icon: Icon(checkedIn ? Icons.refresh : Icons.fact_check_outlined),
                label: Text(checkedIn ? 'Actualizar revisión y copia' : 'Confirmar revisión nocturna'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TurnTile extends StatelessWidget {
  const _TurnTile({required this.label, required this.turn, required this.onTap});

  final String label;
  final TurnData turn;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: EdgeInsets.zero,
        dense: true,
        title: Text(label),
        subtitle: Text(
          'Efectivo \$${turn.cashCollected.toLocalizedString(groupThousands: true)} · '
          'Venta \$${turn.moneyOfSale.toLocalizedString(groupThousands: true)}',
        ),
        trailing: const Icon(Icons.edit_outlined),
        onTap: onTap,
      );
}

class _WorkspaceData {
  const _WorkspaceData({required this.data, required this.lines, required this.dayStates});
  final CycleData data;
  final List<InventoryLine> lines;
  final Map<int, String?> dayStates;
}

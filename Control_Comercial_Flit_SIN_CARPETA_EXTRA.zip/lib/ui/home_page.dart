import 'package:flutter/material.dart';
import 'app_theme.dart';

import '../data/app_database.dart';
import '../data/app_repository.dart';
import 'screens/catalog_screen.dart';
import 'screens/backup_manager_screen.dart';
import 'screens/cycle_workspace_screen.dart';
import 'screens/first_cycle_screen.dart';
import 'screens/history_screen.dart';
import 'screens/settings_screen.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.database});

  final AppDatabase database;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final AppRepository repository = AppRepository(widget.database);
  Future<_DashboardData>? _future;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    setState(() {
      _future = _load();
    });
  }

  Future<_DashboardData> _load() async {
    final cycle = await repository.getCurrentCycle();
    final products = await repository.getProducts();
    final history = await repository.getCycleHistory();
    return _DashboardData(cycle: cycle, productCount: products.length, cycleCount: history.length);
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Control Comercial'),
        actions: [
          IconButton(
            tooltip: 'Configuración',
            onPressed: () => _open(SettingsScreen(repository: repository)),
            icon: const Icon(Icons.settings_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'catalog':
                  _open(CatalogScreen(repository: repository));
                case 'history':
                  _open(HistoryScreen(repository: repository));
                case 'backups':
                  _open(BackupManagerScreen(database: widget.database));
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'catalog', child: Text('Catálogo de productos')),
              PopupMenuItem(value: 'history', child: Text('Historial de ciclos')),
              PopupMenuItem(value: 'backups', child: Text('Copias de seguridad')),
            ],
          ),
        ],
      ),
      body: FutureBuilder<_DashboardData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return _ErrorPanel(message: 'No se pudo cargar la aplicación: ${snapshot.error}', onRetry: _reload);
          }
          final data = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _StatusCard(
                cycle: data.cycle,
                productCount: data.productCount,
                cycleCount: data.cycleCount,
                onOpen: data.cycle == null
                    ? () => _open(FirstCycleScreen(repository: repository))
                    : () => _open(CycleWorkspaceScreen(repository: repository, cycle: data.cycle!)),
              ),
              const SizedBox(height: 16),
              Text('Accesos', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 10),
              _QuickAction(
                icon: Icons.inventory_2_outlined,
                title: 'Productos',
                subtitle: 'Nombres, precios y catálogo activo',
                onTap: () => _open(CatalogScreen(repository: repository)),
              ),
              const SizedBox(height: 8),
              _QuickAction(
                icon: Icons.history,
                title: 'Historial',
                subtitle: 'Consultar ciclos cerrados y sus resultados',
                onTap: () => _open(HistoryScreen(repository: repository)),
              ),
              const SizedBox(height: 8),
              _QuickAction(
                icon: Icons.backup_outlined,
                title: 'Copias de seguridad',
                subtitle: 'Crear, exportar y restaurar respaldos',
                onTap: () => _open(BackupManagerScreen(database: widget.database)),
              ),
              const SizedBox(height: 8),
              _QuickAction(
                icon: Icons.tune,
                title: 'Configuración',
                subtitle: 'Nombres del informe y trabajadores',
                onTap: () => _open(SettingsScreen(repository: repository)),
              ),
              const SizedBox(height: 20),
              const Text(
                'Los ciclos completos alternan con ciclos en los que solo se registra el inventario final. '
                'La aplicación no avanza ni bloquea turnos por la hora del reloj.',
                style: TextStyle(color: kMutedText, height: 1.45),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _DashboardData {
  const _DashboardData({required this.cycle, required this.productCount, required this.cycleCount});
  final CycleRecord? cycle;
  final int productCount;
  final int cycleCount;
}

class _StatusCard extends StatelessWidget {
  const _StatusCard({required this.cycle, required this.productCount, required this.cycleCount, required this.onOpen});
  final CycleRecord? cycle;
  final int productCount;
  final int cycleCount;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final hasCycle = cycle != null;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.storefront_outlined, size: 28),
            const SizedBox(width: 10),
            Expanded(child: Text('Estado del negocio', style: Theme.of(context).textTheme.titleLarge)),
          ]),
          const SizedBox(height: 18),
          Text(hasCycle ? 'Ciclo ${cycle!.sequenceNumber} · ${cycle!.kindLabel}' : 'Todavía no hay un ciclo iniciado',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          if (hasCycle) ...[
            const SizedBox(height: 6),
            Text('${_date(cycle!.startDate)} - ${_date(cycle!.endDate)} · ${cycle!.statusLabel}',
                style: const TextStyle(color: kMutedText)),
          ],
          const SizedBox(height: 16),
          Row(children: [
            _Metric(label: 'Productos activos', value: '$productCount'),
            const SizedBox(width: 24),
            _Metric(label: 'Ciclos guardados', value: '$cycleCount'),
          ]),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: onOpen,
              icon: Icon(hasCycle ? Icons.arrow_forward : Icons.play_arrow),
              label: Text(hasCycle ? 'Abrir ciclo actual' : 'Configurar primer ciclo'),
            ),
          ),
        ]),
      ),
    );
  }

  static String _date(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${(date.year % 100).toString().padLeft(2, '0')}';
}

class _Metric extends StatelessWidget {
  const _Metric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
    Text(label, style: const TextStyle(color: kMutedText, fontSize: 12)),
  ]);
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}

class _ErrorPanel extends StatelessWidget {
  const _ErrorPanel({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline, size: 42),
        const SizedBox(height: 12),
        Text(message, textAlign: TextAlign.center),
        const SizedBox(height: 12),
        FilledButton(onPressed: onRetry, child: const Text('Reintentar')),
      ]),
    ),
  );
}

import 'package:flutter/material.dart';

import '../data/app_repository.dart';

String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

/// Devuelve el id del producto o lanza un error claro si no se eligió ninguno.
String requireProductId(String? productId) {
  if (productId == null) {
    throw ArgumentError('Elige un producto de la lista. Escribe su nombre para buscarlo.');
  }
  return productId;
}

/// Campo de búsqueda de producto. Filtra mientras se escribe y solo informa un
/// id cuando el texto coincide con un producto. Si no coincide, informa null
/// para que el formulario no guarde en silencio un producto distinto.
class ProductPicker extends StatelessWidget {
  const ProductPicker({
    super.key,
    required this.products,
    required this.initialProductId,
    required this.enabled,
    required this.onChanged,
  });

  final List<ProductRecord> products;
  final String? initialProductId;
  final bool enabled;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) {
    ProductRecord? initial;
    for (final product in products) {
      if (product.id == initialProductId) initial = product;
    }
    return Autocomplete<ProductRecord>(
      initialValue: TextEditingValue(text: initial?.name ?? ''),
      displayStringForOption: (product) => product.name,
      optionsBuilder: (value) {
        final query = _normalize(value.text);
        if (query.isEmpty) return products;
        return products.where((product) => _normalize(product.name).contains(query));
      },
      onSelected: (product) => onChanged(product.id),
      fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
        return TextField(
          controller: controller,
          focusNode: focusNode,
          enabled: enabled,
          onChanged: (text) {
            final query = _normalize(text);
            final matches = products
                .where((product) => _normalize(product.name) == query)
                .toList(growable: false);
            onChanged(matches.length == 1 ? matches.single.id : null);
          },
          decoration: const InputDecoration(
            labelText: 'Producto',
            hintText: 'Escribe para buscar',
            suffixIcon: Icon(Icons.search),
          ),
        );
      },
    );
  }
}

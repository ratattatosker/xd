import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path_provider/path_provider.dart';

part 'app_database.g.dart';

class Products extends Table {
  TextColumn get id => text()();
  TextColumn get currentName => text()();
  TextColumn get currentPriceCoefficient => text().withDefault(const Constant('0'))();
  IntColumn get currentPriceScale => integer().withDefault(const Constant(0))();
  IntColumn get sortOrder => integer()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Cycles extends Table {
  TextColumn get id => text()();
  IntColumn get sequenceNumber => integer().unique()();
  TextColumn get cycleKind => text()(); // full | inventoryOnly
  TextColumn get status => text()(); // open | pendingClose | closed
  DateTimeColumn get startDate => dateTime()();
  DateTimeColumn get endDate => dateTime()();
  TextColumn get previousCycleId => text().nullable().references(Cycles, #id)();
  IntColumn get revisionNumber => integer().withDefault(const Constant(0))();
  TextColumn get reportNamesJson => text().withDefault(const Constant('[]'))();
  TextColumn get morningWorkerName => text().withDefault(const Constant('Matutino'))();
  TextColumn get nightWorkerName => text().withDefault(const Constant('Nocturno'))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get closedAt => dateTime().nullable()();

  @override
  Set<Column> get primaryKey => {id};
}

class CycleProducts extends Table {
  TextColumn get cycleId => text().references(Cycles, #id)();
  TextColumn get productId => text().references(Products, #id)();
  TextColumn get productNameSnapshot => text()();
  IntColumn get sortOrderSnapshot => integer()();
  TextColumn get initialQuantityCoefficient => text()();
  IntColumn get initialQuantityScale => integer()();
  TextColumn get finalQuantityCoefficient => text().nullable()();
  IntColumn get finalQuantityScale => integer().nullable()();
  TextColumn get initialPriceCoefficient => text()();
  IntColumn get initialPriceScale => integer()();

  @override
  Set<Column> get primaryKey => {cycleId, productId};
}

class Turns extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get turnIndex => integer()();
  TextColumn get cashCoefficient => text().withDefault(const Constant('0'))();
  IntColumn get cashScale => integer().withDefault(const Constant(0))();
  DateTimeColumn get dailyCheckInAt => dateTime().nullable()();
  TextColumn get dailyCheckInNote => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  List<Set<Column>> get uniqueKeys => [{cycleId, turnIndex}];
}

class InventoryMovements extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get turnIndex => integer()();
  TextColumn get productId => text().references(Products, #id)();
  TextColumn get productNameSnapshot => text()();
  TextColumn get movementKind => text()(); // entry | loss
  TextColumn get quantityCoefficient => text()();
  IntColumn get quantityScale => integer()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Expenses extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get turnIndex => integer()();
  TextColumn get concept => text()();
  TextColumn get amountCoefficient => text()();
  IntColumn get amountScale => integer()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Reinvestments extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get turnIndex => integer()();
  TextColumn get productId => text().references(Products, #id)();
  TextColumn get productNameSnapshot => text()();
  TextColumn get quantityCoefficient => text()();
  IntColumn get quantityScale => integer()();
  TextColumn get amountCoefficient => text()();
  IntColumn get amountScale => integer()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class ProductNameChanges extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get turnIndex => integer()();
  TextColumn get productId => text().references(Products, #id)();
  TextColumn get oldName => text()();
  TextColumn get newName => text()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

@TableIndex(
  name: 'price_change_product_day_unique',
  columns: {#cycleId, #productId, #dayIndex},
  unique: true,
)

class PriceChanges extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get turnIndex => integer()();
  IntColumn get dayIndex => integer()();
  TextColumn get productId => text().references(Products, #id)();
  TextColumn get productNameSnapshot => text()();
  TextColumn get oldPriceCoefficient => text()();
  IntColumn get oldPriceScale => integer()();
  TextColumn get newPriceCoefficient => text()();
  IntColumn get newPriceScale => integer()();
  TextColumn get balanceCoefficient => text()();
  IntColumn get balanceScale => integer()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class CycleRevisions extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get revisionNumber => integer()();
  TextColumn get action => text()();
  DateTimeColumn get changedAt => dateTime()();
  TextColumn get payloadJson => text()();

  @override
  Set<Column> get primaryKey => {id};
  @override
  List<Set<Column>> get uniqueKeys => [{cycleId, revisionNumber}];
}

class CycleReports extends Table {
  TextColumn get id => text()();
  TextColumn get cycleId => text().references(Cycles, #id)();
  IntColumn get revisionNumber => integer()();
  TextColumn get reportText => text()();
  BoolColumn get isFinal => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Backups extends Table {
  TextColumn get id => text()();
  TextColumn get backupKind => text()(); // daily | cycleClose | manual | preRestore
  TextColumn get cycleId => text().nullable()();
  DateTimeColumn get businessDate => dateTime().nullable()();
  TextColumn get filePath => text()();
  DateTimeColumn get createdAt => dateTime()();
  BoolColumn get isExported => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
}

class AppSettings extends Table {
  TextColumn get settingKey => text()();
  TextColumn get settingValue => text()();

  @override
  Set<Column> get primaryKey => {settingKey};
}

@DriftDatabase(tables: [
  Products,
  Cycles,
  CycleProducts,
  Turns,
  InventoryMovements,
  Expenses,
  Reinvestments,
  ProductNameChanges,
  PriceChanges,
  CycleRevisions,
  CycleReports,
  Backups,
  AppSettings,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  static Future<File> resolveDatabaseFile() async {
    final directory = await getApplicationSupportDirectory();
    return File('${directory.path}${Platform.pathSeparator}control_comercial.sqlite');
  }

  static LazyDatabase _openConnection() => LazyDatabase(() async {
        final file = await resolveDatabaseFile();
        return NativeDatabase.createInBackground(file);
      });

  @override
  int get schemaVersion => 2;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await m.createAll();
        },
        onUpgrade: (m, from, to) async {
          if (from < 2) {
            await m.addColumn(cycles, cycles.reportNamesJson);
            await m.addColumn(cycles, cycles.morningWorkerName);
            await m.addColumn(cycles, cycles.nightWorkerName);
          }
        },
        beforeOpen: (details) async {
          await customStatement('PRAGMA foreign_keys = ON');
        },
      );
}

PRAGMA foreign_keys = ON;

-- Espejo SQLite de las tablas declaradas en lib/data/app_database.dart.
-- Mantiene sus claves foráneas, claves únicas y el índice único de cambios de precio.
-- No añade CHECK ni claves foráneas compuestas que no existan en Drift.

CREATE TABLE IF NOT EXISTS products (
  id TEXT NOT NULL PRIMARY KEY,
  current_name TEXT NOT NULL,
  current_price_coefficient TEXT NOT NULL DEFAULT '0',
  current_price_scale INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS cycles (
  id TEXT NOT NULL PRIMARY KEY,
  sequence_number INTEGER NOT NULL UNIQUE,
  cycle_kind TEXT NOT NULL,
  status TEXT NOT NULL,
  start_date INTEGER NOT NULL,
  end_date INTEGER NOT NULL,
  previous_cycle_id TEXT REFERENCES cycles(id),
  revision_number INTEGER NOT NULL DEFAULT 0,
  report_names_json TEXT NOT NULL DEFAULT '[]',
  morning_worker_name TEXT NOT NULL DEFAULT 'Matutino',
  night_worker_name TEXT NOT NULL DEFAULT 'Nocturno',
  created_at INTEGER NOT NULL,
  closed_at INTEGER
);

CREATE TABLE IF NOT EXISTS cycle_products (
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  product_id TEXT NOT NULL REFERENCES products(id),
  product_name_snapshot TEXT NOT NULL,
  sort_order_snapshot INTEGER NOT NULL,
  initial_quantity_coefficient TEXT NOT NULL,
  initial_quantity_scale INTEGER NOT NULL,
  final_quantity_coefficient TEXT,
  final_quantity_scale INTEGER,
  initial_price_coefficient TEXT NOT NULL,
  initial_price_scale INTEGER NOT NULL,
  PRIMARY KEY (cycle_id, product_id)
);

CREATE TABLE IF NOT EXISTS turns (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL,
  cash_coefficient TEXT NOT NULL DEFAULT '0',
  cash_scale INTEGER NOT NULL DEFAULT 0,
  daily_check_in_at INTEGER,
  daily_check_in_note TEXT,
  UNIQUE (cycle_id, turn_index)
);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL,
  product_id TEXT NOT NULL REFERENCES products(id),
  product_name_snapshot TEXT NOT NULL,
  movement_kind TEXT NOT NULL,
  quantity_coefficient TEXT NOT NULL,
  quantity_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS expenses (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL,
  concept TEXT NOT NULL,
  amount_coefficient TEXT NOT NULL,
  amount_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reinvestments (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL,
  product_id TEXT NOT NULL REFERENCES products(id),
  product_name_snapshot TEXT NOT NULL,
  quantity_coefficient TEXT NOT NULL,
  quantity_scale INTEGER NOT NULL,
  amount_coefficient TEXT NOT NULL,
  amount_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS product_name_changes (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL,
  product_id TEXT NOT NULL REFERENCES products(id),
  old_name TEXT NOT NULL,
  new_name TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS price_changes (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL,
  day_index INTEGER NOT NULL,
  product_id TEXT NOT NULL REFERENCES products(id),
  product_name_snapshot TEXT NOT NULL,
  old_price_coefficient TEXT NOT NULL,
  old_price_scale INTEGER NOT NULL,
  new_price_coefficient TEXT NOT NULL,
  new_price_scale INTEGER NOT NULL,
  balance_coefficient TEXT NOT NULL,
  balance_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS price_change_product_day_unique
  ON price_changes (cycle_id, product_id, day_index);

CREATE TABLE IF NOT EXISTS cycle_revisions (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  revision_number INTEGER NOT NULL,
  action TEXT NOT NULL,
  changed_at INTEGER NOT NULL,
  payload_json TEXT NOT NULL,
  UNIQUE (cycle_id, revision_number)
);

CREATE TABLE IF NOT EXISTS cycle_reports (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  revision_number INTEGER NOT NULL,
  report_text TEXT NOT NULL,
  is_final INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS backups (
  id TEXT NOT NULL PRIMARY KEY,
  backup_kind TEXT NOT NULL,
  cycle_id TEXT,
  business_date INTEGER,
  file_path TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  is_exported INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key TEXT NOT NULL PRIMARY KEY,
  setting_value TEXT NOT NULL
);

import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:drift/drift.dart' show Value;

import 'app_database.dart';

class CatalogSeeder {
  CatalogSeeder(this.database);

  final AppDatabase database;

  Future<int> seedIfEmpty() async {
    final existing = await database.select(database.products).get();
    if (existing.isNotEmpty) return existing.length;

    final raw = await rootBundle.loadString('assets/catalog_seed.json');
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    final products = decoded['products'] as List<dynamic>;
    final now = DateTime.now();

    await database.batch((batch) {
      batch.insertAll(
        database.products,
        products.map((item) {
          final row = item as Map<String, dynamic>;
          return ProductsCompanion.insert(
            id: row['id'] as String,
            currentName: row['name'] as String,
            currentPriceCoefficient: const Value('0'),
            currentPriceScale: const Value(0),
            sortOrder: row['sortOrder'] as int,
            isActive: const Value(true),
            createdAt: now,
            updatedAt: now,
          );
        }).toList(),
      );
    });
    return products.length;
  }
}

import 'dart:io';

import 'package:business_core/business_core.dart';
import 'package:drift/drift.dart';

import '../data/app_database.dart';

class BackupArtifact {
  const BackupArtifact({required this.id, required this.file, required this.kind, required this.createdAt});

  final String id;
  final File file;
  final String kind;
  final DateTime createdAt;
}

class BackupService {
  BackupService(this.database);

  final AppDatabase database;
  final BackupValidationService _validation = BackupValidationService();

  Future<BackupArtifact> createDailyBackup({required String cycleId, required DateTime businessDate}) =>
      _create(kind: 'daily', cycleId: cycleId, businessDate: businessDate);

  Future<BackupArtifact> createCycleCloseBackup({required String cycleId}) =>
      _create(kind: 'cycleClose', cycleId: cycleId);

  Future<BackupArtifact> createManualBackup() => _create(kind: 'manual');

  Future<BackupArtifact> createPreRestoreBackup() => _create(kind: 'preRestore');

  Future<BackupArtifact> _create({
    required String kind,
    String? cycleId,
    DateTime? businessDate,
  }) async {
    if (kind == 'daily' || kind == 'cycleClose') {
      if (cycleId == null) throw ArgumentError('La copia automática debe indicar el ciclo.');
      final cycles = await database.customSelect(
        'SELECT cycle_kind FROM cycles WHERE id=?',
        variables: [Variable.withString(cycleId)],
      ).get();
      if (cycles.isEmpty) throw StateError('No se encontró el ciclo de la copia.');
      if (cycles.first.data['cycle_kind'] != 'full') {
        throw StateError('Los ciclos exclusivamente de inventario no generan copias automáticas.');
      }
    }

    final databaseFile = await AppDatabase.resolveDatabaseFile();
    final backupDirectory = Directory('${databaseFile.parent.path}${Platform.pathSeparator}backups');
    await backupDirectory.create(recursive: true);
    final now = DateTime.now();
    final datePart = businessDate == null
        ? ''
        : '_${businessDate.year.toString().padLeft(4, '0')}${businessDate.month.toString().padLeft(2, '0')}${businessDate.day.toString().padLeft(2, '0')}';
    final stamp = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_'
        '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}${now.second.toString().padLeft(2, '0')}';
    final file = File('${backupDirectory.path}${Platform.pathSeparator}control_$kind$datePart-$stamp.sqlite');
    final id = 'backup-${now.microsecondsSinceEpoch}';
    final businessDateValue = businessDate == null
        ? null
        : DateTime(businessDate.year, businessDate.month, businessDate.day).millisecondsSinceEpoch;

    await database.customStatement('PRAGMA wal_checkpoint(FULL)');
    await database.customStatement(
      'INSERT INTO backups(id,backup_kind,cycle_id,business_date,file_path,created_at,is_exported) VALUES(?,?,?,?,?,?,0)',
      [
        id,
        kind,
        if (cycleId == null) null else cycleId,
        if (businessDateValue == null) null else businessDateValue,
        file.path,
        now.millisecondsSinceEpoch,
      ],
    );

    try {
      final escaped = file.path.replaceAll("'", "''");
      await database.customStatement("VACUUM INTO '$escaped'");
      if (!await file.exists() || await file.length() == 0) {
        throw StateError('SQLite no produjo un archivo de respaldo válido.');
      }
    } catch (_) {
      await database.customStatement('DELETE FROM backups WHERE id=?', [id]);
      if (await file.exists()) await file.delete();
      rethrow;
    }

    if (kind == 'daily') {
      await _removePreviousDailyForDate(cycleId!, businessDate!, exceptId: id);
      await _retainLatestSevenDailyBackups();
    }
    return BackupArtifact(id: id, file: file, kind: kind, createdAt: now);
  }

  Future<void> _removePreviousDailyForDate(String cycleId, DateTime businessDate, {required String exceptId}) async {
    final date = DateTime(businessDate.year, businessDate.month, businessDate.day).millisecondsSinceEpoch;
    final rows = await database.customSelect(
      "SELECT id,file_path FROM backups WHERE backup_kind='daily' AND cycle_id=? AND business_date=? AND id<>?",
      variables: [Variable.withString(cycleId), Variable.withInt(date), Variable.withString(exceptId)],
    ).get();
    for (final row in rows) {
      final previousFile = File(row.data['file_path'] as String);
      if (await previousFile.exists()) await previousFile.delete();
      await database.customStatement('DELETE FROM backups WHERE id=?', [row.data['id'] as String]);
    }
  }

  Future<void> _retainLatestSevenDailyBackups() async {
    final rows = await database.customSelect(
      "SELECT id,file_path FROM backups WHERE backup_kind='daily' AND is_exported=0 ORDER BY created_at DESC",
    ).get();
    if (rows.length <= 7) return;
    for (final row in rows.skip(7)) {
      final file = File(row.data['file_path'] as String);
      if (await file.exists()) await file.delete();
      await database.customStatement('DELETE FROM backups WHERE id=?', [row.data['id'] as String]);
    }
  }

  /// Comprueba que exista una copia diaria física para la fecha del negocio.
  /// No basta con encontrar la fila: después de un fallo de almacenamiento
  /// puede haber quedado un registro sin un archivo utilizable.
  Future<bool> hasUsableDailyBackup({
    required String cycleId,
    required DateTime businessDate,
  }) async {
    final date = DateTime(businessDate.year, businessDate.month, businessDate.day)
        .millisecondsSinceEpoch;
    final rows = await database.customSelect(
      "SELECT file_path FROM backups WHERE backup_kind='daily' AND cycle_id=? AND business_date=? ORDER BY created_at DESC",
      variables: [Variable.withString(cycleId), Variable.withInt(date)],
    ).get();
    for (final row in rows) {
      final file = File(row.data['file_path'] as String);
      if (await file.exists() && await file.length() > 0) return true;
    }
    return false;
  }

  Future<void> markExported(String backupId) async {
    await database.customStatement(
      'UPDATE backups SET is_exported=1 WHERE id=?',
      [backupId],
    );
  }

  /// Restaura una base SQLite de esta aplicación sin reemplazar el archivo
  /// que mantiene abierta la conexión Drift. Adjunta el archivo seleccionado,
  /// copia todas las tablas dentro de una transacción y valida las claves
  /// foráneas antes de confirmar. Crea primero un respaldo de seguridad.
  Future<BackupArtifact> restoreFromFile(File source) async {
    if (!await source.exists() || await source.length() < 100) {
      throw StateError('El archivo seleccionado no parece ser una copia válida.');
    }
    final handle = await source.open();
    final signature = await handle.read(16);
    await handle.close();
    const sqliteHeader = 'SQLite format 3\u0000';
    if (signature.length != 16 || String.fromCharCodes(signature) != sqliteHeader) {
      throw StateError('El archivo no tiene el encabezado de una base de datos SQLite.');
    }

    final temporary = File('${(await AppDatabase.resolveDatabaseFile()).parent.path}${Platform.pathSeparator}restore_source_${DateTime.now().microsecondsSinceEpoch}.sqlite');
    await source.copy(temporary.path);
    var attached = false;
    try {
      await database.customStatement('PRAGMA foreign_keys = OFF');
      await database.customStatement(
        'ATTACH DATABASE ? AS restore_source',
        [temporary.path],
      );
      attached = true;

      // Primero se inspecciona la base adjunta. La integridad estructural se
      // verifica antes de borrar o copiar una sola fila de la base activa.
      final integrityRows = await database.customSelect('PRAGMA restore_source.integrity_check').get();
      _validation.validateIntegrityMessages(
        integrityRows.map((row) => row.data.values.first.toString()),
      );

      final versionRows = await database.customSelect('PRAGMA restore_source.user_version').get();
      final incomingVersion = versionRows.isEmpty ? -1 : (versionRows.first.data.values.first as num).toInt();
      _validation.validateSchemaVersion(incoming: incomingVersion, expected: database.schemaVersion);

      final tables = await database.customSelect(
        "SELECT name FROM restore_source.sqlite_master WHERE type='table'",
      ).get();
      final available = tables.map((row) => row.data['name'] as String).toSet();
      _validation.validateTables(available);

      // La integridad referencial se comprueba en el archivo entrante, no solo
      // en la base activa después de copiar. Así una copia inválida se rechaza
      // antes de que se modifique cualquier dato local.
      final incomingForeignKeys = await database.customSelect(
        'PRAGMA restore_source.foreign_key_check',
      ).get();
      _validation.validateForeignKeyViolations(incomingForeignKeys.length);

      // Solo se genera la copia preventiva cuando el archivo ya superó todas
      // las validaciones estructurales y referenciales.
      final preRestore = await createPreRestoreBackup();

      const deleteOrder = <String>[
        'cycle_reports', 'cycle_revisions', 'price_changes', 'product_name_changes',
        'reinvestments', 'expenses', 'inventory_movements', 'turns',
        'cycle_products', 'cycles', 'products', 'backups', 'app_settings',
      ];
      const insertOrder = <String>[
        'products', 'cycles', 'cycle_products', 'turns', 'inventory_movements',
        'expenses', 'reinvestments', 'product_name_changes', 'price_changes',
        'cycle_revisions', 'cycle_reports', 'backups', 'app_settings',
      ];

      await database.transaction(() async {
        for (final table in deleteOrder) {
          await database.customStatement('DELETE FROM main.$table');
        }
        for (final table in insertOrder) {
          await database.customStatement('INSERT INTO main.$table SELECT * FROM restore_source.$table');
        }
        // Los respaldos anteriores contienen rutas internas del teléfono de
        // origen, que no tienen por qué existir en el dispositivo restaurado.
        await database.customStatement('DELETE FROM main.backups');
        // Se conserva en el nuevo historial la copia previa al reemplazo,
        // aunque los demás respaldos del teléfono anterior no sean portátiles.
        await database.customStatement(
          'INSERT INTO main.backups(id,backup_kind,cycle_id,business_date,file_path,created_at,is_exported) VALUES(?,?,?,?,?,?,0)',
          [
            preRestore.id,
            'preRestore',
            null,
            null,
            preRestore.file.path,
            preRestore.createdAt.millisecondsSinceEpoch,
          ],
        );
        final violations = await database.customSelect('PRAGMA main.foreign_key_check').get();
        _validation.validateForeignKeyViolations(violations.length);
      });
      return preRestore;
    } finally {
      if (attached) {
        try {
          await database.customStatement('DETACH DATABASE restore_source');
        } catch (_) {}
      }
      await database.customStatement('PRAGMA foreign_keys = ON');
      if (await temporary.exists()) await temporary.delete();
    }
  }

  Future<List<BackupArtifact>> listBackups() async {
    final rows = await database.customSelect('SELECT * FROM backups ORDER BY created_at DESC').get();
    return rows.map((row) {
      final data = row.data;
      return BackupArtifact(
        id: data['id'] as String,
        file: File(data['file_path'] as String),
        kind: data['backup_kind'] as String,
        createdAt: DateTime.fromMillisecondsSinceEpoch((data['created_at'] as num).toInt()),
      );
    }).toList(growable: false);
  }
}

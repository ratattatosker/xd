import 'package:test/test.dart';

import 'package:business_core/domain/exact_decimal.dart';
import 'package:business_core/domain/models.dart';
import 'package:business_core/services/calculation_service.dart';

ExactDecimal d(String value) => ExactDecimal.parse(value);

/// Producto único "Pastel" a precio 100 salvo que se indique un cambio.
CycleData pastelCycle({
  required String finalQty,
  required String initialQty,
  required List<InventoryMovement> movements,
  List<PriceChange> priceChanges = const [],
  String cashPerTurn = '0',
}) {
  final turns = List<TurnData>.generate(
    6,
    (index) => TurnData(
      index: index,
      cashCollected: d(cashPerTurn),
      movements: movements.where((m) => m.turnIndex == index).toList(),
    ),
  );
  return CycleData(
    id: 'c1',
    kind: CycleKind.full,
    status: CycleStatus.open,
    startDate: DateTime(2026, 1, 1),
    productsInOrder: const ['p1'],
    productNames: const {'p1': 'Pastel'},
    initialInventory: {'p1': d(initialQty)},
    initialPrices: {'p1': d('100')},
    finalInventory: {'p1': d(finalQty)},
    turns: turns,
    priceChanges: priceChanges,
  );
}

void main() {
  group('ExactDecimal enteros', () {
    test('parseWhole acepta enteros con espacios y signo', () {
      expect(ExactDecimal.parseWhole('1 000').toLocalizedString(), '1 000');
      expect(ExactDecimal.parseWhole(' -5 ').toLocalizedString(), '-5');
    });

    test('parseWhole rechaza céntimos, decimales y vacío', () {
      expect(() => ExactDecimal.parseWhole('1,5'), throwsFormatException);
      expect(() => ExactDecimal.parseWhole('1.5'), throwsFormatException);
      expect(() => ExactDecimal.parseWhole('1.000'), throwsFormatException);
      expect(() => ExactDecimal.parseWhole(''), throwsFormatException);
    });

    test('roundToWhole redondea y en empate se aleja de cero', () {
      expect(d('2,4').roundToWhole().toLocalizedString(), '2');
      expect(d('2,5').roundToWhole().toLocalizedString(), '3');
      expect(d('-2,5').roundToWhole().toLocalizedString(), '-3');
      expect(d('7').roundToWhole().toLocalizedString(), '7');
    });
  });

  group('Sobrante, faltante y bajas', () {
    test('una baja registrada no crea faltante y se informa su valor', () {
      // Inicio 10, baja 2, final 6: se venden 2 a 100 = 200.
      final cycle = pastelCycle(
        initialQty: '10',
        finalQty: '6',
        movements: [
          InventoryMovement(
            productId: 'p1',
            productNameSnapshot: 'Pastel',
            quantity: d('2'),
            kind: MovementKind.loss,
            turnIndex: 0,
          ),
        ],
        cashPerTurn: '0',
      );
      final cycleWithCash = pastelCycle(
        initialQty: '10',
        finalQty: '6',
        movements: cycle.turns[0].movements,
        cashPerTurn: '0',
      );
      // Efectivo que cuadra: 200 de venta, 200 en caja.
      final turns = [...cycleWithCash.turns];
      turns[0] = TurnData(
        index: 0,
        cashCollected: d('200'),
        movements: turns[0].movements,
      );
      final balanced = CycleData(
        id: 'c1',
        kind: CycleKind.full,
        status: CycleStatus.open,
        startDate: DateTime(2026, 1, 1),
        productsInOrder: const ['p1'],
        productNames: const {'p1': 'Pastel'},
        initialInventory: {'p1': d('10')},
        initialPrices: {'p1': d('100')},
        finalInventory: {'p1': d('6')},
        turns: turns,
      );

      final rec = CalculationService().calculate(balanced).financialReconciliation;
      expect(rec.estimatedSales.toLocalizedString(), '200');
      expect(rec.lossesValue.toLocalizedString(), '200');
      expect(rec.difference.isZero, isTrue);
      expect(rec.status, ReconciliationStatus.balanced);
    });

    test('la diferencia neta es faltante cuando falta efectivo', () {
      final cycle = pastelCycle(
        initialQty: '10',
        finalQty: '6',
        movements: const [],
        cashPerTurn: '0',
      );
      final turns = [...cycle.turns];
      turns[0] = TurnData(index: 0, cashCollected: d('150'));
      final short = CycleData(
        id: 'c1',
        kind: CycleKind.full,
        status: CycleStatus.open,
        startDate: DateTime(2026, 1, 1),
        productsInOrder: const ['p1'],
        productNames: const {'p1': 'Pastel'},
        initialInventory: {'p1': d('10')},
        initialPrices: {'p1': d('100')},
        finalInventory: {'p1': d('6')},
        turns: turns,
      );
      final rec = CalculationService().calculate(short).financialReconciliation;
      expect(rec.estimatedSales.toLocalizedString(), '400');
      expect(rec.difference.toLocalizedString(), '250');
      expect(rec.status, ReconciliationStatus.shortage);
      expect(rec.shortfall.toLocalizedString(), '250');
      expect(rec.surplus.isZero, isTrue);
    });

    test('las bajas se valoran al precio vigente en su turno', () {
      // Precio 100 hasta el turno 2; desde el turno 2 pasa a 150.
      // Baja de 1 en turno 0 (100) y baja de 1 en turno 3 (150) = 250.
      // Ventas: inicio 10, bajas 2, final 3 => 5 unidades.
      // Tramo 1: saldo al inicio del turno 2 = 7 => 2 vendidas a 100 = 200.
      // Tramo 2: 3 vendidas a 150 = 450. Venta total = 650.
      final cycle = pastelCycle(
        initialQty: '10',
        finalQty: '3',
        movements: [
          InventoryMovement(
            productId: 'p1',
            productNameSnapshot: 'Pastel',
            quantity: d('1'),
            kind: MovementKind.loss,
            turnIndex: 0,
          ),
          InventoryMovement(
            productId: 'p1',
            productNameSnapshot: 'Pastel',
            quantity: d('1'),
            kind: MovementKind.loss,
            turnIndex: 3,
          ),
        ],
        priceChanges: [
          PriceChange(
            productId: 'p1',
            productNameSnapshot: 'Pastel',
            turnIndex: 2,
            oldPrice: d('100'),
            newPrice: d('150'),
            balanceAtTurnStart: d('7'),
          ),
        ],
      );
      final calc = CalculationService().calculate(cycle);
      final product = calc.productSales['p1']!;
      expect(product.lossesValue.toLocalizedString(), '250');
      expect(calc.financialReconciliation.estimatedSales.toLocalizedString(), '650');
      expect(calc.financialReconciliation.lossesValue.toLocalizedString(), '250');
    });
  });
}

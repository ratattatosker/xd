/// Validaciones puras para impedir que un respaldo incompleto o corrupto
/// sustituya los datos locales de la aplicación.
class BackupValidationService {
  static const requiredTables = <String>{
    'products',
    'cycles',
    'cycle_products',
    'turns',
    'inventory_movements',
    'expenses',
    'reinvestments',
    'product_name_changes',
    'price_changes',
    'cycle_revisions',
    'cycle_reports',
    'backups',
    'app_settings',
  };

  void validateSchemaVersion({required int incoming, required int expected}) {
    if (incoming != expected) {
      throw StateError(
        'La copia pertenece a otra versión de la base de datos '
        '(esquema $incoming; aplicación $expected).',
      );
    }
  }

  void validateTables(Set<String> available) {
    final missing = requiredTables.difference(available).toList()..sort();
    if (missing.isNotEmpty) {
      throw StateError('La copia está incompleta. Faltan tablas: ${missing.join(', ')}.');
    }
  }

  /// PRAGMA integrity_check devuelve una sola fila "ok" cuando la base
  /// completa está estructuralmente sana. Cualquier otro resultado rechaza
  /// la restauración, sin tocar la base activa.
  void validateIntegrityMessages(Iterable<String> messages) {
    final results = messages.map((value) => value.trim()).where((value) => value.isNotEmpty).toList();
    if (results.length == 1 && results.single.toLowerCase() == 'ok') return;
    final detail = results.isEmpty ? 'SQLite no devolvió un resultado.' : results.take(5).join(' | ');
    throw StateError('La copia SQLite no superó la comprobación de integridad: $detail');
  }

  void validateForeignKeyViolations(int violationCount) {
    if (violationCount > 0) {
      throw StateError('La copia contiene $violationCount referencia(s) interna(s) inválida(s). No se restauró ningún dato.');
    }
  }
}

import '../domain/models.dart';

class BackupPolicy {
  /// Solo los ciclos completos generan copia diaria al hacer check-in nocturno.
  bool shouldCreateDailyBackup(CycleKind kind) => kind == CycleKind.full;

  /// Solo el cierre de un ciclo completo genera la copia automática adicional.
  /// Los ciclos de inventario no generan copias automáticas.
  bool shouldCreateCloseBackup(CycleKind kind) => kind == CycleKind.full;

  /// Siempre se puede pedir una copia manual, incluso en un ciclo de inventario.
  bool shouldAllowManualBackup() => true;

  /// Devuelve los identificadores que pueden eliminarse para conservar las
  /// siete copias diarias más recientes. No elimina copias de cierre, manuales,
  /// previas a restauración ni exportaciones manuales.
  List<String> dailyBackupIdsToDelete(List<BackupRecord> records) {
    final daily = records.where((record) =>
        record.kind == BackupKind.daily && !record.isExported).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return daily.skip(7).map((record) => record.id).toList(growable: false);
  }
}

enum BackupKind { daily, cycleClose, manual, preRestore }

class BackupRecord {
  const BackupRecord({
    required this.id,
    required this.kind,
    required this.createdAt,
    this.isExported = false,
  });

  final String id;
  final BackupKind kind;
  final DateTime createdAt;
  final bool isExported;
}

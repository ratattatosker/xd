import '../domain/exact_decimal.dart';
import '../domain/models.dart';
import 'calculation_service.dart';

class CycleLifecycleService {
  CycleLifecycleService(this.calculator);

  final CalculationService calculator;

  CycleData prepareForReview(
    CycleData cycle,
    Map<String, ExactDecimal> finalInventory,
  ) {
    if (cycle.status != CycleStatus.open) {
      throw StateError('Solo se puede preparar para revisión un ciclo abierto.');
    }
    _validateFinalInventory(cycle, finalInventory);
    return cycle.copyWith(
      status: CycleStatus.pendingClose,
      finalInventory: Map<String, ExactDecimal>.unmodifiable(finalInventory),
    );
  }

  CycleData confirmClose(CycleData cycle) {
    if (cycle.status != CycleStatus.pendingClose) {
      throw StateError('Primero debes revisar el ciclo antes de cerrarlo.');
    }
    _validateFinalInventory(cycle, cycle.finalInventory);
    if (cycle.kind == CycleKind.full) {
      final result = calculator.calculate(cycle);
      if (result.issues.isNotEmpty) {
        throw StateError('No se puede cerrar: ${result.issues.join(' | ')}');
      }
    } else if (cycle.turns.isNotEmpty || cycle.priceChanges.isNotEmpty) {
      throw StateError('Un ciclo exclusivamente de inventario no contiene turnos ni cambios de precio.');
    }
    return cycle.copyWith(status: CycleStatus.closed);
  }

  void _validateFinalInventory(
    CycleData cycle,
    Map<String, ExactDecimal> finalInventory,
  ) {
    final missing = cycle.productsInOrder.where((id) => !finalInventory.containsKey(id));
    if (missing.isNotEmpty) {
      throw StateError('Falta el conteo final de ${missing.length} producto(s).');
    }
    final negative = finalInventory.entries.where((entry) => entry.value.isNegative);
    if (negative.isNotEmpty) {
      throw StateError('No se puede cerrar con inventario negativo.');
    }
  }
}

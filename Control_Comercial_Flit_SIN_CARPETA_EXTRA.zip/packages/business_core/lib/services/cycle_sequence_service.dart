import '../domain/models.dart';

class CycleSequenceService {
  /// El primer ciclo es siempre completo. El siguiente comienza tres días
  /// después y alterna el tipo de ciclo.
  CycleKind firstCycleKind() => CycleKind.full;

  CycleKind nextKind(CycleKind previous) => previous == CycleKind.full
      ? CycleKind.inventoryOnly
      : CycleKind.full;

  DateTime nextStartDate(DateTime previousStart) =>
      DateTime(previousStart.year, previousStart.month, previousStart.day + 3);

  Map<String, dynamic> nextCycleSeed(CycleData previous) {
    if (previous.status != CycleStatus.closed) {
      throw StateError('Solo se puede iniciar el ciclo siguiente tras confirmar el cierre.');
    }
    return {
      'kind': nextKind(previous.kind),
      'startDate': nextStartDate(previous.startDate),
      'initialInventory': Map<String, dynamic>.unmodifiable(previous.finalInventory),
      'productsInOrder': List<String>.unmodifiable(previous.productsInOrder),
      'productNames': Map<String, String>.unmodifiable(previous.productNames),
    };
  }

  /// Los ciclos exclusivamente de inventario no crean copias automáticas.
  bool shouldCreateDailyBackup(CycleKind kind) => kind == CycleKind.full;

  bool shouldCreateCloseBackup(CycleKind kind) => kind == CycleKind.full;
}

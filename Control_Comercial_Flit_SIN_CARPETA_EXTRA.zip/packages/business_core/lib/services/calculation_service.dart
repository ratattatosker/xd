import '../domain/exact_decimal.dart';
import '../domain/models.dart';

class CalculationService {
  CycleCalculation calculate(CycleData cycle) {
    if (cycle.kind != CycleKind.full) {
      throw StateError('Los ciclos de inventario no tienen cálculos comerciales.');
    }
    if (cycle.turns.length != 6) {
      throw StateError('Un ciclo completo debe contener exactamente seis turnos.');
    }
    final turns = [...cycle.turns]..sort((a, b) => a.index.compareTo(b.index));
    for (var i = 0; i < 6; i++) {
      if (turns[i].index != i) {
        throw StateError('Falta el turno ${turnLabel(i)}.');
      }
    }

    final issues = <String>[];
    _validatePriceChanges(cycle, issues);
    _validateFinancialRecords(cycle, turns, issues);
    _validateMovementBalances(cycle, issues);

    final turnMoney = <int, ExactDecimal>{};
    final turnFinancials = <TurnFinancialSummary>[];
    for (final turn in turns) {
      turnMoney[turn.index] = turn.moneyOfSale;
      turnFinancials.add(TurnFinancialSummary(
        turnIndex: turn.index,
        cashCollected: turn.cashCollected,
        expenses: turn.expenseTotal,
        reinvestments: turn.reinvestmentTotal,
        expenseEntries: List.unmodifiable(turn.expenses),
        reinvestmentEntries: List.unmodifiable(turn.reinvestments),
        moneyOfSale: turn.moneyOfSale,
      ));
    }

    final dailyTotals = <DailyTotals>[];
    for (var day = 0; day < 3; day++) {
      final morning = turns[day * 2];
      final night = turns[day * 2 + 1];
      dailyTotals.add(DailyTotals(
        day: day + 1,
        cashCollected: morning.cashCollected + night.cashCollected,
        expenses: morning.expenseTotal + night.expenseTotal,
        reinvestments: morning.reinvestmentTotal + night.reinvestmentTotal,
        moneyOfSale: morning.moneyOfSale + night.moneyOfSale,
      ));
    }

    final totalCash = turns.fold(
      ExactDecimal.zero(),
      (sum, turn) => sum + turn.cashCollected,
    );
    final totalExpenses = turns.fold(
      ExactDecimal.zero(),
      (sum, turn) => sum + turn.expenseTotal,
    );
    final totalReinvestments = turns.fold(
      ExactDecimal.zero(),
      (sum, turn) => sum + turn.reinvestmentTotal,
    );
    final totalSale = turns.fold(
      ExactDecimal.zero(),
      (sum, turn) => sum + turn.moneyOfSale,
    );

    final productResults = <String, ProductSalesResult>{};
    for (final productId in cycle.productsInOrder) {
      final result = _calculateProduct(cycle, productId);
      productResults[productId] = result;
      issues.addAll(result.issues);
    }

    final totalEstimatedSales = productResults.values.fold(
      ExactDecimal.zero(),
      (sum, product) => sum + product.estimatedRevenue,
    );

    final totalLossesValue = productResults.values.fold(
      ExactDecimal.zero(),
      (sum, product) => sum + product.lossesValue,
    );

    final financialReconciliation = FinancialReconciliation(
      estimatedSales: totalEstimatedSales,
      cashCollected: totalCash,
      expenses: totalExpenses,
      reinvestments: totalReinvestments,
      recordedMoneyOfSale: totalSale,
      lossesValue: totalLossesValue,
    );

    final morningBase = turns
        .where((t) => t.index.isEven)
        .fold(ExactDecimal.zero(), (s, t) => s + t.moneyOfSale);
    final nightBase = turns
        .where((t) => t.index.isOdd)
        .fold(ExactDecimal.zero(), (s, t) => s + t.moneyOfSale);

    return CycleCalculation(
      turnMoneyOfSale: turnMoney,
      turnFinancials: List.unmodifiable(turnFinancials),
      dailyTotals: dailyTotals,
      totalCashCollected: totalCash,
      totalExpenses: totalExpenses,
      totalReinvestments: totalReinvestments,
      totalMoneyOfSale: totalSale,
      totalEstimatedSales: totalEstimatedSales,
      differenceEstimatedVsRecorded: financialReconciliation.difference,
      financialReconciliation: financialReconciliation,
      productSales: productResults,
      expensesByConcept: aggregateExpenses(turns),
      salarySummary: SalarySummary(
        morningWorkerName: cycle.morningWorkerName,
        morningBase: morningBase,
        morningSalary: morningBase.percent(5),
        nightWorkerName: cycle.nightWorkerName,
        nightBase: nightBase,
        nightSalary: nightBase.percent(5),
      ),
      issues: issues,
    );
  }

  ProductSalesResult _calculateProduct(CycleData cycle, String productId) {
    final name = cycle.productNames[productId] ?? productId;
    final initial = cycle.initialInventory[productId] ?? ExactDecimal.zero();
    final finalQty = cycle.finalInventory[productId];
    final issues = <String>[];
    if (!cycle.initialInventory.containsKey(productId)) {
      issues.add('Falta el inventario inicial de $name.');
    }
    if (finalQty == null) {
      return ProductSalesResult(
        productId: productId,
        productName: name,
        totalUnitsSold: ExactDecimal.zero(),
        estimatedRevenue: ExactDecimal.zero(),
        periods: const [],
        lossesValue: ExactDecimal.zero(),
        isConsistent: false,
        issues: List.unmodifiable([...issues, 'Falta el inventario final de $name.']),
      );
    }
    if (finalQty.isNegative) issues.add('El inventario final de $name es negativo.');

    final normalEntries = <int, ExactDecimal>{};
    final losses = <int, ExactDecimal>{};
    for (final turn in cycle.turns) {
      for (final movement in turn.movements.where((m) => m.productId == productId)) {
        final target = movement.kind == MovementKind.entry ? normalEntries : losses;
        target[turn.index] = (target[turn.index] ?? ExactDecimal.zero()) + movement.quantity;
      }
      for (final reinvestment
          in turn.reinvestments.where((r) => r.productId == productId)) {
        normalEntries[turn.index] =
            (normalEntries[turn.index] ?? ExactDecimal.zero()) + reinvestment.quantity;
      }
    }

    ExactDecimal sumThrough(int start, int end, Map<int, ExactDecimal> values) {
      var sum = ExactDecimal.zero();
      for (var i = start; i < end; i++) {
        sum = sum + (values[i] ?? ExactDecimal.zero());
      }
      return sum;
    }

    final totalEntries = sumThrough(0, 6, normalEntries);
    final totalLosses = sumThrough(0, 6, losses);
    final totalUnitsSold = initial + totalEntries - totalLosses - finalQty;
    if (totalUnitsSold.isNegative) {
      issues.add('El balance total de $name da ventas negativas; revisa entradas, bajas e inventarios.');
    }

    final events = cycle.priceChanges
        .where((change) => change.productId == productId)
        .toList()
      ..sort((a, b) => a.turnIndex.compareTo(b.turnIndex));

    var openingBalance = initial;
    final initialPrice = cycle.initialPrices[productId];
    if (initialPrice == null) {
      issues.add('Falta el precio inicial de $name.');
    }
    var openingPrice = initialPrice ?? ExactDecimal.zero();

    // Valor de las bajas: cada turno se valora con el precio vigente en ese
    // turno. Un cambio de precio aplica desde su propio turno.
    var lossesAtPrice = ExactDecimal.zero();
    for (var turnIndex = 0; turnIndex < 6; turnIndex++) {
      var priceInTurn = initialPrice ?? ExactDecimal.zero();
      for (final event in events) {
        if (event.turnIndex <= turnIndex) priceInTurn = event.newPrice;
      }
      final turnLosses = losses[turnIndex] ?? ExactDecimal.zero();
      lossesAtPrice = lossesAtPrice + turnLosses * priceInTurn;
    }
    final lossesValue = lossesAtPrice.roundToWhole();
    var periodStart = 0;
    var estimatedRevenue = ExactDecimal.zero();
    final periods = <PricePeriodResult>[];

    for (final event in events) {
      if (event.turnIndex < periodStart || event.turnIndex > 5) {
        issues.add('El cambio de precio de $name tiene un turno no válido.');
        continue;
      }
      final expectedAtStart = openingBalance +
          sumThrough(periodStart, event.turnIndex, normalEntries) -
          sumThrough(periodStart, event.turnIndex, losses);
      // La diferencia positiva es precisamente la venta inferida del período
      // anterior. Solo es inconsistente si el saldo declarado supera las
      // existencias posibles según los registros (faltan entradas o hay un error).
      final sold = expectedAtStart - event.balanceAtTurnStart;
      if (sold.isNegative) {
        issues.add(
          'El saldo de $name al cambiar el precio supera las existencias posibles. '
          'Revisa el inventario inicial, las entradas y las bajas.',
        );
      }
      final revenue = (sold * openingPrice).roundToWhole();
      periods.add(PricePeriodResult(
        fromTurnIndex: periodStart,
        toTurnIndexExclusive: event.turnIndex,
        price: openingPrice,
        unitsSold: sold,
        estimatedRevenue: revenue,
      ));
      estimatedRevenue = estimatedRevenue + revenue;
      openingBalance = event.balanceAtTurnStart;
      openingPrice = event.newPrice;
      periodStart = event.turnIndex;
    }

    final lastClose = openingBalance +
        sumThrough(periodStart, 6, normalEntries) -
        sumThrough(periodStart, 6, losses);
    final lastSold = lastClose - finalQty;
    if (lastSold.isNegative) {
      issues.add('El último período de precio de $name produce ventas negativas.');
    }
    final lastRevenue = (lastSold * openingPrice).roundToWhole();
    periods.add(PricePeriodResult(
      fromTurnIndex: periodStart,
      toTurnIndexExclusive: 6,
      price: openingPrice,
      unitsSold: lastSold,
      estimatedRevenue: lastRevenue,
    ));
    estimatedRevenue = estimatedRevenue + lastRevenue;

    final periodUnits = periods.fold(
      ExactDecimal.zero(),
      (sum, period) => sum + period.unitsSold,
    );
    if (periodUnits.compareTo(totalUnitsSold) != 0) {
      issues.add('Las unidades por período de precio de $name no concilian con el total del ciclo.');
    }

    return ProductSalesResult(
      productId: productId,
      productName: name,
      totalUnitsSold: totalUnitsSold,
      estimatedRevenue: estimatedRevenue,
      periods: List.unmodifiable(periods),
      isConsistent: issues.isEmpty,
      lossesValue: lossesValue,
      issues: List.unmodifiable(issues),
    );
  }

  void _validatePriceChanges(CycleData cycle, List<String> issues) {
    final changes = [...cycle.priceChanges]
      ..sort((a, b) => a.turnIndex.compareTo(b.turnIndex));
    final seen = <String>{};
    final expectedPrices = Map<String, ExactDecimal>.from(cycle.initialPrices);
    for (final change in changes) {
      if (!cycle.productsInOrder.contains(change.productId)) {
        issues.add('El cambio de precio de ${change.productNameSnapshot} no pertenece al catálogo del ciclo.');
      }
      if (change.turnIndex < 0 || change.turnIndex > 5) {
        issues.add('Hay un cambio de precio asociado a un turno no válido.');
        continue;
      }
      final day = change.turnIndex ~/ 2;
      final key = '${change.productId}:$day';
      if (!seen.add(key)) {
        issues.add('Un producto no puede cambiar de precio dos veces en el mismo día.');
      }
      if (change.balanceAtTurnStart.isNegative) {
        issues.add('El saldo del cambio de precio no puede ser negativo.');
      }
      final expectedOldPrice = expectedPrices[change.productId];
      if (expectedOldPrice != null && expectedOldPrice.compareTo(change.oldPrice) != 0) {
        issues.add('El precio anterior de ${change.productNameSnapshot} no coincide con el historial.');
      }
      if (change.newPrice.isNegative) {
        issues.add('El nuevo precio de ${change.productNameSnapshot} no puede ser negativo.');
      } else if (change.newPrice.isZero) {
        issues.add('El nuevo precio de ${change.productNameSnapshot} es \$0; configúralo antes de cerrar el ciclo.');
      }
      expectedPrices[change.productId] = change.newPrice;
    }
  }

  void _validateFinancialRecords(
    CycleData cycle,
    List<TurnData> turns,
    List<String> issues,
  ) {
    final productIds = cycle.productsInOrder.toSet();
    if (productIds.length != cycle.productsInOrder.length) {
      issues.add('El catálogo del ciclo contiene productos duplicados.');
    }
    for (final productId in productIds) {
      final name = cycle.productNames[productId] ?? productId;
      final initial = cycle.initialInventory[productId];
      if (initial != null && initial.isNegative) {
        issues.add('El inventario inicial de $name no puede ser negativo.');
      }
      final price = cycle.initialPrices[productId];
      if (price != null) {
        if (price.isNegative) {
          issues.add('El precio inicial de $name no puede ser negativo.');
        } else if (price.isZero) {
          // El catálogo inicial se importa con precios cero porque la hoja
          // fuente no contiene precios. No se puede conciliar la venta si el
          // usuario todavía no ha configurado un precio real.
          issues.add('El precio inicial de $name es \$0. Configúralo antes de cerrar el ciclo.');
        }
      }
    }

    for (final turn in turns) {
      if (turn.cashCollected.isNegative) {
        issues.add('El Dinero Efectivo no puede ser negativo en ${turnLabel(turn.index)}.');
      }
      for (final expense in turn.expenses) {
        if (expense.turnIndex != turn.index) {
          issues.add('Un gasto está asociado a un turno distinto de ${turnLabel(turn.index)}.');
        }
        if (expense.concept.trim().isEmpty) {
          issues.add('Hay un gasto sin concepto en ${turnLabel(turn.index)}.');
        }
        if (expense.amount.isNegative) {
          issues.add('El importe de un gasto no puede ser negativo en ${turnLabel(turn.index)}.');
        }
      }
      for (final reinvestment in turn.reinvestments) {
        if (!productIds.contains(reinvestment.productId)) {
          issues.add('La reinversión de ${reinvestment.productNameSnapshot} no pertenece al catálogo del ciclo.');
        }
        if (reinvestment.turnIndex != turn.index) {
          issues.add('Una reinversión está asociada a un turno distinto de ${turnLabel(turn.index)}.');
        }
      }
      for (final movement in turn.movements) {
        if (!productIds.contains(movement.productId)) {
          issues.add('El movimiento de ${movement.productNameSnapshot} no pertenece al catálogo del ciclo.');
        }
        if (movement.turnIndex != turn.index) {
          issues.add('Un movimiento de ${movement.productNameSnapshot} está asociado a un turno distinto de ${turnLabel(turn.index)}.');
        }
      }
    }
  }

  void _validateMovementBalances(CycleData cycle, List<String> issues) {
    for (final productId in cycle.productsInOrder) {
      var knownBalance = cycle.initialInventory[productId] ?? ExactDecimal.zero();
      final changes = cycle.priceChanges.where((c) => c.productId == productId);
      final changesByTurn = {for (final change in changes) change.turnIndex: change};
      for (final turn in [...cycle.turns]..sort((a, b) => a.index.compareTo(b.index))) {
        final checkpoint = changesByTurn[turn.index];
        if (checkpoint != null) knownBalance = checkpoint.balanceAtTurnStart;
        var turnEntries = ExactDecimal.zero();
        var turnLosses = ExactDecimal.zero();
        for (final movement in turn.movements.where((m) => m.productId == productId)) {
          if (movement.quantity.isNegative) {
            issues.add('La cantidad de un movimiento de ${movement.productNameSnapshot} no puede ser negativa.');
            continue;
          }
          if (movement.kind == MovementKind.entry) {
            turnEntries = turnEntries + movement.quantity;
          } else {
            turnLosses = turnLosses + movement.quantity;
          }
        }
        for (final reinvestment
            in turn.reinvestments.where((r) => r.productId == productId)) {
          if (reinvestment.quantity.isNegative || reinvestment.amount.isNegative) {
            issues.add('Una reinversión de ${reinvestment.productNameSnapshot} no puede tener cantidades negativas.');
            continue;
          }
          turnEntries = turnEntries + reinvestment.quantity;
        }
        // Las operaciones del turno no tienen hora ni orden entre sí: se suman
        // como conjunto antes de comprobar el saldo.
        knownBalance = knownBalance + turnEntries - turnLosses;
        if (knownBalance.isNegative) {
          issues.add('Una baja deja el saldo calculado de ${cycle.productNames[productId] ?? productId} por debajo de cero en ${turnLabel(turn.index)}.');
          break;
        }
      }
    }
  }

  List<AggregatedExpense> aggregateExpenses(List<TurnData> turns) {
    final grouped = <String, AggregatedExpense>{};
    final ordered = [...turns]..sort((a, b) => a.index.compareTo(b.index));
    for (final turn in ordered) {
      for (final expense in turn.expenses) {
        final key = expense.concept.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
        if (key.isEmpty) continue;
        final previous = grouped[key];
        grouped[key] = AggregatedExpense(
          firstWrittenConcept: previous?.firstWrittenConcept ?? expense.concept.trim(),
          amount: (previous?.amount ?? ExactDecimal.zero()) + expense.amount,
        );
      }
    }
    return List.unmodifiable(grouped.values);
  }

  static String turnLabel(int index) {
    const labels = [
      'Día 1 Matutino',
      'Día 1 Nocturno',
      'Día 2 Matutino',
      'Día 2 Nocturno',
      'Día 3 Matutino',
      'Día 3 Nocturno',
    ];
    if (index < 0 || index >= labels.length) return 'Turno desconocido';
    return labels[index];
  }
}

import '../domain/exact_decimal.dart';

/// Reglas de integridad para retirar productos del catálogo activo.
class CatalogPolicy {
  /// Un producto solo puede retirarse cuando su saldo conocido es cero.
  /// La retirada nunca elimina sus movimientos ni su historial.
  void ensureCanArchive({
    required String productName,
    required ExactDecimal knownQuantity,
  }) {
    if (!knownQuantity.isZero) {
      throw StateError(
        'No se puede retirar $productName porque todavía tiene '
        '${knownQuantity.toLocalizedString()} unidades. '
        'Primero registra el inventario correcto hasta que llegue a cero.',
      );
    }
  }
}

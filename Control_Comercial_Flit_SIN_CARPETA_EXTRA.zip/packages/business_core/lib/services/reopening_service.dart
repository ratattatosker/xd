import '../domain/exact_decimal.dart';
import '../domain/models.dart';

class ReopeningService {
  /// Solo permite iniciar una reapertura histórica cuando existe al menos un
  /// producto negativo detectado en la cadena que se está corrigiendo.
  void ensureNegativeInventoryReason(Map<String, ExactDecimal> detectedBalances) {
    final hasNegativeProduct = detectedBalances.values.any((value) => value.isNegative);
    if (!hasNegativeProduct) {
      throw StateError(
        'La reapertura histórica solo está permitida cuando se detecta inventario negativo.',
      );
    }
  }

  /// Tras corregir un ciclo anterior, propaga sus finales como inicios de los
  /// ciclos posteriores. Conserva los finales físicos posteriores: no los
  /// reemplaza ni los inventa. Cada ciclo modificado debe quedar auditado por
  /// el repositorio antes de persistir la nueva cadena.
  List<CycleData> propagateCorrectedInventory({
    required List<CycleData> chronologicalCycles,
    required int correctedCycleIndex,
  }) {
    if (correctedCycleIndex < 0 || correctedCycleIndex >= chronologicalCycles.length) {
      throw RangeError.index(correctedCycleIndex, chronologicalCycles, 'correctedCycleIndex');
    }
    final result = [...chronologicalCycles];
    for (var i = correctedCycleIndex + 1; i < result.length; i++) {
      final previous = result[i - 1];
      if (previous.status != CycleStatus.closed) {
        throw StateError('La cadena posterior contiene un ciclo que no está cerrado.');
      }
      result[i] = result[i].copyWith(
        initialInventory: Map<String, ExactDecimal>.unmodifiable(previous.finalInventory),
      );
    }
    return List.unmodifiable(result);
  }
}

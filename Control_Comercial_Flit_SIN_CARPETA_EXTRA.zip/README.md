# Control Comercial — Android v0.9.2

Undécima entrega del desarrollo de la aplicación descrita en la **Biblia Maestra v3.0**. Incluye la base Flutter/SQLite, pantallas de operación, copias, corrección histórica del inventario negativo, cierre con revisión diaria garantizada del tercer día, cierre atómico con creación del ciclo siguiente y retirada segura de productos, además de un preparador nativo de PowerShell para Windows. Es una versión de desarrollo: el APK debe compilarse y probarse en un PC con Flutter, Java/JDK y Android SDK.

## Novedades de v0.9.2

- Corregida la dependencia de compilación: `drift_dev` se fija en la línea disponible `^2.35.3`; `drift ^2.35.4` se conserva porque esa versión sí está publicada.
- Añadido `test` como dependencia de desarrollo raíz para que el análisis estático pueda recorrer las pruebas del motor comercial.
- La revisión del cierre calcula la conciliación del ciclo completo usando la venta estimada a partir del inventario inicial, entradas, bajas, inventario final y precios históricos.
- Para obtener el efectivo esperado, descuenta los gastos y las reinversiones de la venta estimada y lo compara con el efectivo realmente recogido. El mismo resultado equivale a comparar la venta estimada con `Dinero de Venta = efectivo + gastos + reinversiones`; ningún movimiento se suma o resta dos veces.
- La revisión muestra faltante, sobrante o conciliación exacta, más el desglose de efectivo, gastos, reinversiones y Dinero de Venta en cada uno de los seis turnos.
- El informe copiable incorpora la conciliación y el desglose financiero por turno.
- El resultado de faltante/sobrante solo se atribuye al ciclo completo: el inventario no se cuenta por turno, por lo que no hay base suficiente para asignar exactamente una diferencia a uno de ellos.
- Se añadieron pruebas Dart para saldos conciliados, faltantes, sobrantes y consistencia de los registros financieros.

## Auditoría adicional de Codemagic (20-11-2026)

- Se corrigieron tres formularios que leían `widget.initialProductId` desde inicializadores de campo; ahora lo hacen en `initState` y admiten un catálogo vacío.
- Se corrigió la invalidación de revisiones: una edición de un turno invalida la revisión de ese día y las posteriores, dentro de la misma transacción del cambio.
- Añadir, retirar o reactivar productos durante un ciclo completo invalida las revisiones que ya no reflejan el catálogo actual.
- Se impiden nombres de productos duplicados tras normalizar mayúsculas y espacios; el selector no asigna IDs ante coincidencias ambiguas.
- El editor de catálogo no guarda hasta conocer el ciclo activo y vuelve a comprobarlo justo antes de modificar.
- El esquema SQL auxiliar de pruebas se alineó con las claves y restricciones declaradas en Drift.
- Codemagic usa Flutter estable 3.50.0. El script ejecuta validadores Python antes de preparar Android, genera Drift con `--delete-conflicting-outputs`, formatea, analiza el proyecto y ejecuta análisis/pruebas de `business_core` antes del APK.
- Los scripts respetan `pubspec.lock` con `--enforce-lockfile` cuando está disponible. En la primera compilación se genera el archivo y Codemagic lo publica como artefacto para incorporarlo después al repositorio.

## Novedades de v0.9.1

- Corregida la eliminación de gastos: la consulta ya no intenta leer `product_id`, columna que no existe en `expenses`.
- El cierre del ciclo completo queda bloqueado si falla la copia diaria del Día 3. La capa de repositorio exige también check-in nocturno vigente y un registro de copia diaria para esa fecha.
- El check-in del Día 3 acepta un catálogo vacío, que es un estado permitido después de retirar todos los productos con saldo cero.
- Las modificaciones de un turno invalidan la revisión de ese día y de todos los días posteriores; el cambio y la invalidación se guardan juntos en una transacción.
- Añadir o reactivar productos en un ciclo completo obliga a repetir las revisiones que ya se habían marcado.
- Se impiden nombres de productos duplicados (ignorando mayúsculas y espacios) y el selector no asigna un producto arbitrario ante coincidencias ambiguas.
- Los movimientos, reinversiones y cambios de precio guardan el nombre vigente en el turno al que pertenecen, incluso cuando se registran tarde. El historial de renombres se reconstruye por turno para no pisar renombres posteriores.
- La restauración comprueba las claves foráneas directamente en la base adjunta antes de crear la copia preventiva o modificar la base activa. La copia preventiva se crea solo después de validar el respaldo entrante.
- La secuencia y la propagación histórica aceptan un inventario final vacío como estado válido de un ciclo cerrado.
- La auditoría posterior añadió validaciones de las inicializaciones de producto, nombres duplicados, carreras del editor de catálogo, invalidación de revisiones futuras y archivado/reactivación del catálogo.

## Novedades de v0.9.0

- La restauración de respaldos comprueba `PRAGMA integrity_check` antes de tocar la base activa, además de validar la versión, las tablas requeridas y las claves foráneas. Una copia SQLite corrupta se rechaza sin sustituir los datos actuales.
- Cambiar el inventario final invalida el borrador de cierre solo cuando cambió realmente alguna cantidad o su escala decimal. La escritura, la invalidación del borrador y la marca del check-in nocturno modificado ocurren dentro de una única transacción.
- La reapertura histórica también marca los check-ins del ciclo actual como modificados dentro de la misma transacción que cambia el inventario heredado.
- El historial muestra un rótulo claro cuando un borrador se invalida por modificación del inventario final.

## Novedades de v0.8.0

- El cierre del ciclo y la creación del siguiente se ejecutan dentro de una única transacción SQLite. Si falla la creación del nuevo ciclo, el ciclo anterior no queda cerrado a medias.
- Un producto solo puede retirarse de la lista activa si su saldo conocido es exactamente cero. La proyección respeta los cortes de precio y suma entradas, reinversiones y bajas.
- La comprobación de saldo y la retirada del producto se ejecutan juntas en una transacción, evitando una carrera entre lectura y escritura.
- Si todos los productos de saldo cero se retiran, la aplicación puede continuar con ciclos sin catálogo activo; no impone artificialmente que quede un producto. Los productos nuevos pueden añadirse después.
- Se añadieron pruebas del motor para permitir retirar stock cero y rechazar stock positivo, una simulación SQLite de reversión del cierre y una comprobación de continuidad con un ciclo de inventario vacío.

## Qué incluye esta entrega

### Núcleo comercial

- Motor Dart independiente en `packages/business_core`, separado de la interfaz para reutilizar las reglas en una futura versión Windows.
- Decimales exactos con `BigInt` y escala preservada: `1,30` continúa siendo `1,30`; no se utilizan `double` para cantidades o importes.
- Ciclo completo de seis turnos y ciclo alterno de solo inventario.
- Dinero de Venta por turno = efectivo + gastos + reinversiones.
- Inventario inicial + entradas normales + cantidades reinvertidas - bajas - inventario final.
- Cambios de precio desde el comienzo del turno indicado; como máximo un cambio por producto y día.
- Ventas estimadas por períodos de precio y alertas de incongruencia.
- Gastos del informe agrupados sin distinguir mayúsculas/minúsculas; se conserva el primer rótulo escrito.
- Cálculo informativo del 5 % para el conjunto de los tres turnos matutinos y, por separado, los tres nocturnos.
- Alternancia completo → inventario → completo. El ciclo exclusivamente de inventario no genera salarios ni copias automáticas.

### Aplicación y persistencia

- Catálogo inicial de 65 productos importados del libro XLSM, respetando el orden.
- Alta, retirada/reactivación y cambio histórico de nombres de productos.
- Configuración de nombres del informe y de los dos trabajadores.
- Registro de efectivo, entradas, bajas, gastos, reinversiones y cambios de precio en cada turno.
- Edición y eliminación de operaciones conservando su ciclo y turno originales.
- Dinero de Venta visible en cada turno y totales diarios de Dinero Recogido y Dinero de Venta en el espacio del ciclo.
- Botón para copiar el informe final y los informes del historial al portapapeles.
- Los campos del inventario final empiezan vacíos cuando aún no se ha contado el producto; no se precarga silenciosamente el inventario inicial.
- Inventario final, borrador de cierre, confirmación y creación del siguiente ciclo alterno.
- Historial de ciclos, informes y resultados salariales.
- Check-in nocturno y copias diarias solo en ciclos completos; copia adicional al cerrar ciclos completos.
- Gestor de copias manuales, exportación con selector del sistema y restauración SQLite. Antes de restaurar se valida el archivo entrante (integridad estructural, versión, tablas obligatorias y claves foráneas); solo después se crea una copia preventiva del estado actual y se sustituye la base dentro de una transacción.
- Comprobación de inventario negativo dentro de las transacciones, antes de aceptar el cambio.
- Al cerrar un ciclo completo, el Día 3 Nocturno debe quedar revisado y su copia diaria debe crearse después de guardar el inventario final y antes de confirmar el cierre. Si falla esa copia, el cierre se bloquea. Luego se intenta generar la copia adicional de cierre.
- Si el inventario final del ciclo completo se corrige después del check-in, la revisión nocturna se marca como modificada; el cierre repetirá el check-in y actualizará la copia diaria.
- Antes de considerar satisfecha la revisión del tercer día, se comprueba que el archivo de copia diaria exista y no esté vacío; no basta con que exista un registro en SQLite.

### Corrección histórica por inventario negativo (incorporada en v0.5.0 y ampliada)

- Si una operación fuera a dejar un producto negativo antes del primer cambio de precio del ciclo, la aplicación rechaza la operación y ofrece corregir el inventario final del ciclo exclusivamente de inventario que aportó el saldo inicial actual.
- La corrección exige introducir un nuevo final suficiente para cubrir el déficit detectado.
- Se actualizan únicamente el final del ciclo anterior y el inventario inicial heredado por el ciclo completo actual. No se cambian los movimientos ni los finales físicos posteriores.
- La reapertura y el nuevo cierre quedan registrados en `cycle_revisions`; el historial muestra estos eventos.
- Si el déficit aparece después de un cambio de precio, no se ofrece reabrir el ciclo anterior: debe revisarse el saldo declarado en ese cambio de precio.
- La operación que se rechazó no se registra automáticamente: después de corregir el inventario, el usuario debe volver a introducirla.
- Si el ciclo actual estaba pendiente de cierre, la corrección invalida el borrador para obligar a recalcularlo. Los check-ins diarios del ciclo completo se marcan como modificados porque cambió su inventario inicial.
- Si se edita cualquier operación de un ciclo que estaba pendiente de cierre, el estado vuelve a «Abierto», se conserva el borrador previo como historial y se registra la invalidación. El usuario debe preparar de nuevo el cierre.

### Catálogo importado

`assets/catalog_seed.json` se extrajo de la hoja `10-11-26` del libro XLSM más reciente disponible en la biblioteca. Contiene 65 nombres y su orden original. La tabla no contiene precios de venta; por eso los precios se inicializan en cero y deben introducirse desde Catálogo. No se precargan cantidades.

## Tecnología

- Flutter/Dart.
- Drift sobre SQLite local.
- Motor de negocio independiente en `packages/business_core`.
- `path_provider` para la base local y `file_picker` para exportar/restaurar.
- La versión de Flutter debe incluir Dart `>=3.10.0`, conforme al `pubspec.yaml`.

## Verificación realizada en este entorno

- `python tool/verify_reference_rules.py`: comprobaciones independientes de reglas comerciales, estructura SQLite y protecciones de inventario; el total debe tomarse de la ejecución final de esta entrega. Incluyen catálogo, períodos de precio, salarios, conciliación de efectivo con salidas de caja, detalle de movimientos por turno, dependencias publicadas, agrupación de gastos, alternancia, políticas de copias, restauración SQLite, integridad referencial, corrección histórica auditada, check-in/copia del tercer día, atomicidad del cierre y retirada segura del catálogo.
- La corrección histórica se comprueba con una base SQLite de prueba: cambia solo el final del ciclo de inventario anterior y el inicial heredado por el ciclo completo actual; conserva los demás finales físicos.
- `python tool/check_dart_delimiters.py`: comprobación léxica de delimitadores Dart. No sustituye a `flutter analyze` ni a compilar.

**No se ejecutaron `flutter analyze`, `dart test`, `build_runner` ni `flutter build apk` aquí** porque este entorno no tiene Flutter/Dart ni Android SDK instalados. Por tanto, no afirmo que el código haya pasado el compilador Dart o que exista ya un APK. El primer equipo con Flutter debe ejecutar el script y corregir cualquier error de análisis/compilación que aparezca.

## Generar el APK desde Windows (sin instalar Android Studio)

El teléfono no necesita Android Studio ni herramientas de desarrollo. El APK se compila en el PC. **Visual Studio de escritorio no sustituye al Android SDK**; puede usarse como editor, pero para compilar Android hacen falta Flutter, Java/JDK y Android SDK.

### 1. Instalar Flutter SDK (si aún no lo tienes)

1. Instala [Git for Windows](https://git-scm.com/download/win).
2. Abre la [guía oficial de instalación manual de Flutter](https://docs.flutter.dev/install/manual) y descarga el paquete **Stable para Windows**.
3. Crea `%USERPROFILE%\develop` y extrae dentro el ZIP. La carpeta resultante debe ser `%USERPROFILE%\develop\flutter` y contener `bin\flutter.bat` y `bin\dart.bat`.
4. Abre las variables de entorno de Windows (`Windows + R` → `sysdm.cpl` → Opciones avanzadas → Variables de entorno). En el `Path` de tu usuario, agrega `%USERPROFILE%\develop\flutter\bin`.
5. Cierra y vuelve a abrir PowerShell. Dart viene incluido en Flutter; no lo descargues por separado.

Consulta también la [guía oficial para agregar Flutter al PATH](https://docs.flutter.dev/install/add-to-path).

### 2. Comprobar Flutter

Abre PowerShell y ejecuta:

```powershell
flutter --version
dart --version
flutter doctor -v
```

El `pubspec.yaml` exige Dart 3.10 o posterior. Si tu Flutter incluye una versión anterior, actualízalo antes de continuar.

### 3. Instalar Android SDK Command-line Tools

No es obligatorio instalar Android Studio. Descarga **Command line tools only** desde la página oficial de Android Developers:

https://developer.android.com/studio#command-line-tools-only

Crea, por ejemplo, esta estructura:

```text
C:\Android\
  cmdline-tools\
    latest\
      bin\sdkmanager.bat
      lib\
      NOTICE.txt
```

El contenido del ZIP debe quedar directamente dentro de `latest`, no dentro de otra carpeta `cmdline-tools` anidada.

En PowerShell, define la ruta para esa sesión:

```powershell
$env:ANDROID_SDK_ROOT = 'C:\Android'
$env:ANDROID_HOME = $env:ANDROID_SDK_ROOT
$env:Path += ";$env:ANDROID_SDK_ROOT\platform-tools"
```

Instala la plataforma y las herramientas base:

```powershell
& "$env:ANDROID_SDK_ROOT\cmdline-tools\latest\bin\sdkmanager.bat" --sdk_root="$env:ANDROID_SDK_ROOT" 'platform-tools' 'platforms;android-36' 'build-tools;36.0.0'
```

Flutter también necesita un JDK compatible con la versión de Gradle que genere. Si `flutter doctor -v` no encuentra Java o muestra una incompatibilidad, instala un JDK 17 o el que indique la versión de Flutter/Gradle y configura `JAVA_HOME`.

Después ejecuta:

```powershell
flutter config --android-sdk "$env:ANDROID_SDK_ROOT"
flutter doctor --android-licenses
flutter doctor -v
```

Continúa cuando Android toolchain no muestre errores que impidan compilar.

### 4. Preparar y compilar el proyecto

1. Descomprime `Control_Comercial_Android_v0.9.1.zip`.
2. Abre PowerShell dentro de la carpeta `Control_Comercial_Android_v0.9.1`.
3. Permite scripts solo en esa sesión y ejecuta el preparador:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\tool\bootstrap_android.ps1 -BuildApk
```

El script genera la carpeta nativa `android`, instala dependencias, genera los adaptadores de Drift, formatea el código, ejecuta validaciones Python, el análisis de Flutter (con avisos fatales por defecto), `dart analyze`, las pruebas Dart del motor y, si todo pasa, compila el APK release. El primer uso necesita Internet para descargar dependencias y componentes; la aplicación final funciona offline.

Si ya existe una carpeta `android` correctamente generada y no quieres regenerarla, usa:

```powershell
.\tool\bootstrap_android.ps1 -BuildApk -SkipAndroidPlatformGeneration
```

### 5. Localizar el APK

Si el proceso termina correctamente, el archivo estará aquí:

```text
build\app\outputs\flutter-apk\app-release.apk
```

Cópialo al teléfono por USB o por el medio que prefieras y ábrelo para instalarlo. Android puede pedir autorización para instalar aplicaciones desde esa fuente.

También puedes instalarlo directamente por USB si activas las opciones de desarrollador y la depuración USB, conectas el móvil y ejecutas:

```powershell
adb install -r .\build\app\outputs\flutter-apk\app-release.apk
```

### 6. Si algo falla

No continúes ignorando errores de `flutter analyze`, `dart test` o `flutter build apk`. Copia el texto completo desde la primera línea de error hasta el final y guárdalo; así se puede corregir el problema exacto. No instales un APK que no haya terminado de compilar correctamente.

## Dependencias bloqueadas

El paquete no incluye todavía `pubspec.lock`. La primera compilación resuelve las versiones compatibles y publica los archivos `pubspec.lock` de la app y `business_core` como artefactos de Codemagic. Descárgalos y añádelos al repositorio. En compilaciones posteriores, los scripts usarán `--enforce-lockfile` para evitar que una resolución distinta cambie las dependencias silenciosamente.

## Qué falta antes de considerar la app operativa

- Ejecutar el preparador con la instalación real de Flutter/Android SDK del PC y corregir cualquier error de Dart/Gradle.
- Probar la corrección histórica por inventario negativo en un dispositivo Android y confirmar que el movimiento rechazado debe volver a registrarse manualmente.
- Confirmar en el teléfono que, al cerrar el ciclo completo, se generan dos archivos distintos: copia diaria del tercer día y copia adicional del cierre; verificar también que los ciclos exclusivamente de inventario no generan copias automáticas.
- Pruebas integrales de ciclos completos y ciclos exclusivamente de inventario con datos representativos y después con un ciclo real supervisado.
- Probar exportación/restauración y retención de copias en el teléfono.
- Revisar posibles errores de migración y fallos por falta de almacenamiento.
- Pulir el diseño visual y accesibilidad después de validar los flujos.
- Diseñar la transferencia de datos a Windows antes de iniciar esa fase posterior.

#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
BUILD_APK=0
for arg in "$@"; do
  case "$arg" in
    --build-apk) BUILD_APK=1 ;;
    *) echo "Opción desconocida: $arg" >&2; exit 2 ;;
  esac
done
trap 'rm -rf "$TEMP_DIR"' EXIT

if ! command -v flutter >/dev/null 2>&1; then
  echo "No se encontró Flutter. Instala una versión estable de Flutter que incluya Dart 3.10 o posterior y vuelve a ejecutar este script." >&2
  exit 1
fi
if ! command -v dart >/dev/null 2>&1; then
  echo "No se encontró Dart. Debe instalarse junto con Flutter." >&2
  exit 1
fi
for required_command in python3 java; do
  if ! command -v "$required_command" >/dev/null 2>&1; then
    echo "No se encontró $required_command, necesario para preparar y compilar Android." >&2
    exit 1
  fi
done

FLUTTER_VERSION="$(flutter --version | head -n 1)"
echo "Usando: $FLUTTER_VERSION"
java -version

echo "Ejecutando validaciones independientes antes de Pub/Gradle..."
python3 tool/check_dart_delimiters.py
python3 tool/verify_reference_rules.py
echo "Generando la plataforma Android..."
flutter create --platforms=android --org=com.controlcomercial --project-name=control_comercial "$TEMP_DIR/host"
rm -rf "$APP_DIR/android"
cp -R "$TEMP_DIR/host/android" "$APP_DIR/android"
cp "$TEMP_DIR/host/.metadata" "$APP_DIR/.metadata"

# Firma de release: usa el keystore de Codemagic (CM_KEYSTORE_*) cuando existe.
# Sin esas variables (p. ej. en local) se mantiene la firma de depuración.
python3 - "$APP_DIR/android/app" <<'PYSIGN'
import pathlib, sys
app = pathlib.Path(sys.argv[1])
kts = app / 'build.gradle.kts'
groovy = app / 'build.gradle'
if kts.exists():
    text = kts.read_text(encoding='utf-8')
    block = """signingConfigs {
        create("release") {
            val keystorePath = System.getenv("CM_KEYSTORE_PATH")
            if (keystorePath != null) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("CM_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("CM_KEY_ALIAS")
                keyPassword = System.getenv("CM_KEY_PASSWORD")
            }
        }
    }

    """
    old = 'signingConfig = signingConfigs.getByName("debug")'
    new = 'signingConfig = if (System.getenv("CM_KEYSTORE_PATH") != null) signingConfigs.getByName("release") else signingConfigs.getByName("debug")'
elif groovy.exists():
    text = groovy.read_text(encoding='utf-8')
    block = """signingConfigs {
        release {
            def keystorePath = System.getenv("CM_KEYSTORE_PATH")
            if (keystorePath != null) {
                storeFile file(keystorePath)
                storePassword System.getenv("CM_KEYSTORE_PASSWORD")
                keyAlias System.getenv("CM_KEY_ALIAS")
                keyPassword System.getenv("CM_KEY_PASSWORD")
            }
        }
    }

    """
    old = 'signingConfig signingConfigs.debug'
    new = 'signingConfig System.getenv("CM_KEYSTORE_PATH") != null ? signingConfigs.release : signingConfigs.debug'
else:
    sys.exit('No se encontró build.gradle(.kts) de la app Android.')
if text.count(old) != 1 or text.count('buildTypes {') != 1:
    sys.exit('La plantilla Gradle generada no tiene el formato esperado; revisar la firma.')
text = text.replace('buildTypes {', block + 'buildTypes {', 1).replace(old, new)
(kts if kts.exists() else groovy).write_text(text, encoding='utf-8')
print('Firma de release configurada.')
PYSIGN

# Codemagic y otros entornos CI necesitan las rutas explícitas antes de `flutter pub get`.
# Se respeta FLUTTER_ROOT cuando está definido y, en Codemagic, su ruta habitual.
if [[ -n "${FLUTTER_ROOT:-}" ]]; then
  FLUTTER_SDK_DIR="$FLUTTER_ROOT"
elif [[ -d "$HOME/programs/flutter" ]]; then
  FLUTTER_SDK_DIR="$HOME/programs/flutter"
else
  FLUTTER_BIN="$(command -v flutter)"
  FLUTTER_SDK_DIR="$(python3 -c 'import os, sys; print(os.path.dirname(os.path.dirname(os.path.realpath(sys.argv[1]))))' "$FLUTTER_BIN")"
fi
ANDROID_SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$ANDROID_SDK_DIR" ]]; then
  for candidate in "$HOME/Library/Android/sdk" "$HOME/Android/Sdk"; do
    if [[ -d "$candidate" ]]; then
      ANDROID_SDK_DIR="$candidate"
      break
    fi
  done
fi
if [[ -z "$ANDROID_SDK_DIR" || ! -d "$ANDROID_SDK_DIR" ]]; then
  echo "No se pudo localizar una carpeta válida de Android SDK (ANDROID_SDK_ROOT/ANDROID_HOME)." >&2
  exit 1
fi
echo "Android SDK: $ANDROID_SDK_DIR"
{
  printf 'flutter.sdk=%s\n' "$FLUTTER_SDK_DIR"
  if [[ -n "$ANDROID_SDK_DIR" ]]; then
    printf 'sdk.dir=%s\n' "$ANDROID_SDK_DIR"
  fi
} > "$APP_DIR/android/local.properties"

cd "$APP_DIR"
echo "Instalando dependencias Flutter..."
if [[ -f pubspec.lock ]]; then
  flutter pub get --enforce-lockfile
else
  echo "AVISO: no existe pubspec.lock; esta primera resolución no queda bloqueada."
  flutter pub get
fi
echo "Generando adaptadores de Drift..."
dart run build_runner build --delete-conflicting-outputs
echo "Formateando fuentes Dart..."
dart format lib packages/business_core/lib packages/business_core/test

echo "Ejecutando análisis estático..."
flutter analyze

echo "Analizando y probando el motor comercial..."
(
  cd packages/business_core
  if [[ -f pubspec.lock ]]; then
    dart pub get --enforce-lockfile
  else
    dart pub get
  fi
  dart analyze --fatal-infos
  dart test
)

if [[ "$BUILD_APK" -eq 1 ]]; then
  echo "Compilando APK de producción..."
  flutter build apk --release
  echo "APK generado en: $APP_DIR/build/app/outputs/flutter-apk/app-release.apk"
else
  echo "Plataforma Android generada y comprobaciones terminadas."
  echo "Para generar el APK: flutter build apk --release"
fi

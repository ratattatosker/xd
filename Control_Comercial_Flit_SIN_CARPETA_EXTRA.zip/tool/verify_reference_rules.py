"""Verificación independiente de reglas aritméticas usando Decimal exacto.

No reemplaza los tests Dart; es una segunda comprobación ejecutable con Python
estándar mientras el entorno de trabajo no tenga Flutter/Dart instalado.
"""
from decimal import Decimal
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class BusinessRulesTest(unittest.TestCase):
    def test_excel_catalogue_seed(self):
        data = json.loads((ROOT / 'assets/catalog_seed.json').read_text(encoding='utf-8'))
        products = data['products']
        self.assertEqual(len(products), 65)
        self.assertEqual(products[0]['name'], 'Bizcocho')
        self.assertEqual(products[-1]['name'], 'Gran Caribe')
        self.assertEqual(len({p['id'] for p in products}), 65)
        self.assertEqual(len({p['name'].casefold() for p in products}), 65)

    def test_price_period_balance_and_sales_estimate(self):
        # Inicio: 10. Antes del cambio quedan 8: se infieren 2 ventas a 100.
        old_price = Decimal('100')
        balance_at_change = Decimal('8')
        sold_old = Decimal('10') - balance_at_change
        # En el turno del cambio entran 5 + 2 por reinversión y hay una baja.
        final_stock = Decimal('10')
        sold_new = balance_at_change + Decimal('5') + Decimal('2') - Decimal('1') - final_stock
        estimated = sold_old * old_price + sold_new * Decimal('200')
        total_sold = Decimal('10') + Decimal('5') + Decimal('2') - Decimal('1') - final_stock
        self.assertEqual(sold_old, Decimal('2'))
        self.assertEqual(sold_new, Decimal('4'))
        self.assertEqual(total_sold, Decimal('6'))
        self.assertEqual(sold_old + sold_new, total_sold)
        self.assertEqual(estimated, Decimal('1000'))

    def test_turn_money_and_shift_salaries(self):
        # Money of Sale = cash + expenses + reinvestments.
        turn_sales = [Decimal('4500'), Decimal('3100'), Decimal('400'), Decimal('0'), Decimal('500'), Decimal('600')]
        morning_base = turn_sales[0] + turn_sales[2] + turn_sales[4]
        night_base = turn_sales[1] + turn_sales[3] + turn_sales[5]
        self.assertEqual(morning_base * Decimal('0.05'), Decimal('270.00'))
        self.assertEqual(night_base * Decimal('0.05'), Decimal('185.00'))

    def test_inventory_reconciliation_counts_every_financial_outflow_once(self):
        estimated_sales = Decimal('1000')
        expenses = Decimal('100')
        reinvestments = Decimal('50')
        # The same formula can be read either as expected cash vs cash collected,
        # or as inventory sales vs Money of Sale (cash + outflows).
        expected_cash = estimated_sales - expenses - reinvestments
        cash_collected = Decimal('840')
        money_of_sale = cash_collected + expenses + reinvestments
        difference = expected_cash - cash_collected
        self.assertEqual(expected_cash, Decimal('850'))
        self.assertEqual(money_of_sale, Decimal('990'))
        self.assertEqual(difference, estimated_sales - money_of_sale)
        self.assertEqual(difference, Decimal('10'))
        self.assertEqual(max(difference, Decimal('0')), Decimal('10'))  # faltante
        self.assertEqual(max(-difference, Decimal('0')), Decimal('0'))  # no sobrante

    def test_close_review_exposes_cycle_reconciliation_and_turn_movements(self):
        calculation = (ROOT / 'packages/business_core/lib/services/calculation_service.dart').read_text(encoding='utf-8')
        models = (ROOT / 'packages/business_core/lib/domain/models.dart').read_text(encoding='utf-8')
        close_screen = (ROOT / 'lib/ui/screens/final_inventory_screen.dart').read_text(encoding='utf-8')
        report = (ROOT / 'packages/business_core/lib/services/report_service.dart').read_text(encoding='utf-8')
        self.assertIn('financialReconciliation', calculation)
        self.assertIn('expenseEntries', models)
        self.assertIn('reinvestmentEntries', models)
        history = (ROOT / 'lib/ui/screens/history_screen.dart').read_text(encoding='utf-8')
        self.assertIn('_FinancialReconciliationView', close_screen)
        self.assertIn('El faltante o sobrante se determina para el ciclo completo', close_screen)
        self.assertIn('Venta estimada por inventario', history)
        self.assertIn('Faltante respecto a la venta estimada', history)
        self.assertIn('Movimientos financieros por turno', report)
        self.assertIn('Gasto: ${expense.concept}', report)
        self.assertIn('Reinversión:', report)
        self.assertIn('calculation.issues.isNotEmpty', history)

    def test_drift_generator_constraint_matches_published_version(self):
        pubspec = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
        self.assertIn('drift: ^2.35.4', pubspec)
        self.assertIn('drift_dev: ^2.35.3', pubspec)
        self.assertIn('test: ^1.28.0', pubspec)
        self.assertNotIn('drift_dev: ^2.35.4', pubspec)

    def test_expense_grouping_case_insensitive(self):
        items = [
            ('Pago de Frank', Decimal('3000')),
            ('Manuel', Decimal('500')),
            ('pago de frank', Decimal('2600')),
            ('Pago de frank', Decimal('400')),
            ('manuel', Decimal('500')),
        ]
        grouped = {}
        for concept, amount in items:
            key = ' '.join(concept.strip().lower().split())
            if key not in grouped:
                grouped[key] = [concept.strip(), Decimal('0')]
            grouped[key][1] += amount
        self.assertEqual(grouped['pago de frank'], ['Pago de Frank', Decimal('6000')])
        self.assertEqual(grouped['manuel'], ['Manuel', Decimal('1000')])

    def test_two_cycle_alternation_and_backup_exclusion(self):
        def next_kind(kind):
            return 'inventoryOnly' if kind == 'full' else 'full'

        sequence = ['full']
        for _ in range(3):
            sequence.append(next_kind(sequence[-1]))
        self.assertEqual(sequence, ['full', 'inventoryOnly', 'full', 'inventoryOnly'])
        auto_backup = lambda kind: kind == 'full'
        self.assertTrue(auto_backup('full'))
        self.assertFalse(auto_backup('inventoryOnly'))

    def test_historical_reopen_propagates_initials_without_overwriting_later_finals(self):
        # Corrección de C1: el final cambia de 12 a 11. Se actualizan los
        # iniciales posteriores, pero los conteos físicos finales se conservan.
        cycles = [
            {'kind': 'full', 'initial': Decimal('10'), 'final': Decimal('12')},
            {'kind': 'inventoryOnly', 'initial': Decimal('12'), 'final': Decimal('8')},
            {'kind': 'full', 'initial': Decimal('8'), 'final': Decimal('6')},
        ]
        negative_balances = {'p1': Decimal('-0.5')}
        self.assertTrue(any(value < 0 for value in negative_balances.values()))
        cycles[0]['final'] = Decimal('11')
        for index in range(1, len(cycles)):
            cycles[index]['initial'] = cycles[index - 1]['final']
        self.assertEqual(cycles[1]['initial'], Decimal('11'))
        self.assertEqual(cycles[1]['final'], Decimal('8'))
        self.assertEqual(cycles[2]['initial'], Decimal('8'))
        self.assertEqual(cycles[2]['final'], Decimal('6'))

    def test_backup_restore_table_transfer_preserves_referential_integrity(self):
        schema = (ROOT / 'lib/data/schema.sql').read_text(encoding='utf-8')
        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / 'source.sqlite'
            target_path = Path(directory) / 'target.sqlite'
            source = sqlite3.connect(source_path)
            target = sqlite3.connect(target_path)
            try:
                source.executescript(schema)
                target.executescript(schema)
                source.execute('PRAGMA user_version=2')
                target.execute('PRAGMA user_version=2')
                source.execute("INSERT INTO products VALUES ('p1','Pastel','100',0,0,1,1,1)")
                source.execute("INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES ('c1',1,'full','open',1,3,NULL,0,'[]','M','N',1,NULL)")
                source.execute("INSERT INTO cycle_products VALUES ('c1','p1','Pastel',0,'10',0,NULL,NULL,'100',0)")
                target.execute("INSERT INTO products VALUES ('old','Registro antiguo','0',0,0,1,1,1)")
                source.commit()
                target.commit()
                target.execute('PRAGMA foreign_keys=OFF')
                target.execute('ATTACH DATABASE ? AS restore_source', (str(source_path),))
                target_version = target.execute('PRAGMA restore_source.user_version').fetchone()[0]
                self.assertEqual(target_version, 2)
                delete_order = ['cycle_reports','cycle_revisions','price_changes','product_name_changes','reinvestments','expenses','inventory_movements','turns','cycle_products','cycles','products','backups','app_settings']
                insert_order = ['products','cycles','cycle_products','turns','inventory_movements','expenses','reinvestments','product_name_changes','price_changes','cycle_revisions','cycle_reports','backups','app_settings']
                target.execute('BEGIN')
                for table in delete_order:
                    target.execute(f'DELETE FROM main.{table}')
                for table in insert_order:
                    target.execute(f'INSERT INTO main.{table} SELECT * FROM restore_source.{table}')
                violations = target.execute('PRAGMA foreign_key_check').fetchall()
                self.assertEqual(violations, [])
                target.commit()
                target.execute('DETACH DATABASE restore_source')
                target.execute('PRAGMA foreign_keys=ON')
                self.assertEqual(target.execute('SELECT current_name FROM products').fetchone()[0], 'Pastel')
                self.assertEqual(target.execute('SELECT initial_quantity_coefficient FROM cycle_products').fetchone()[0], '10')
            finally:
                source.close()
                target.close()


    def test_restore_checks_sqlite_integrity_before_copying_rows(self):
        backup_service = (ROOT / 'lib/services/backup_service.dart').read_text(encoding='utf-8')
        validation_service = (ROOT / 'packages/business_core/lib/services/backup_validation_service.dart').read_text(encoding='utf-8')
        integrity_pos = backup_service.index("PRAGMA restore_source.integrity_check")
        delete_pos = backup_service.index("DELETE FROM main.")
        self.assertLess(integrity_pos, delete_pos)
        self.assertIn('_validation.validateIntegrityMessages(', backup_service)
        self.assertIn('_validation.validateSchemaVersion(', backup_service)
        self.assertIn('_validation.validateTables(available)', backup_service)
        self.assertIn('_validation.validateForeignKeyViolations(violations.length)', backup_service)
        self.assertIn("'ok'", validation_service)

    def test_final_inventory_change_invalidates_draft_and_checkin_atomically(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        method = repository[repository.index('Future<void> setFinalInventory('):repository.index('Future<CycleRecord?> getCycleById(')]
        self.assertIn('await database.transaction(() async {', method)
        self.assertIn("statusRows.data['status'] == 'pendingClose'", method)
        self.assertIn("'close_draft_invalidated_by_final_inventory_edit'", method)
        self.assertIn('await _markReviewedDayAsModified(cycleId, 5);', method)
        self.assertNotIn('await _markReviewedDayAsModified(cycleId, 5);\n    });\n  }', method)

    def test_historical_correction_marks_checkins_inside_same_transaction(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        method = repository[repository.index('Future<void> correctPreviousInventoryCycleForNegativeBalance('):repository.index('Future<void> _appendCycleRevision(')]
        self.assertIn('await _markAllCheckedDaysAsModified(incident.cycleId);', method)
        self.assertLess(method.index('await _markAllCheckedDaysAsModified(incident.cycleId);'), method.rindex('    });'))

    def test_backup_ui_and_restore_guard_are_wired(self):
        backup_service = (ROOT / 'lib/services/backup_service.dart').read_text(encoding='utf-8')
        backup_screen = (ROOT / 'lib/ui/screens/backup_manager_screen.dart').read_text(encoding='utf-8')
        home = (ROOT / 'lib/ui/home_page.dart').read_text(encoding='utf-8')
        pubspec = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
        self.assertIn("cycle_kind", backup_service)
        self.assertIn("restoreFromFile", backup_service)
        self.assertIn('PRAGMA main.foreign_key_check', backup_service)
        self.assertIn('PRAGMA restore_source.foreign_key_check', backup_service)
        self.assertIn('FilePicker.saveFile', backup_screen)
        self.assertIn('FilePicker.pickFile', backup_screen)
        self.assertIn('BackupManagerScreen', home)
        self.assertIn('file_picker: ^13.3.3', pubspec)


    def test_existing_turn_records_can_be_edited_without_recreating_ids(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        screen = (ROOT / 'lib/ui/screens/turn_editor_screen.dart').read_text(encoding='utf-8')
        for method in ('updateMovement', 'updateExpense', 'updateReinvestment', 'updatePriceChange'):
            self.assertIn(f'Future<void> {method}(', repository)
            self.assertIn(f'repository.{method}(', screen)
        self.assertIn('Editar registro', screen)
        self.assertIn('initialQuantity: activity.quantity', screen)
        self.assertIn('getProducts(activeOnly: false)', screen)
        # Los updates localizan el registro por id + ciclo + turno y no generan un nuevo ID.
        self.assertIn("WHERE id=? AND cycle_id=? AND turn_index=?", repository)
        self.assertIn('SET quantity_coefficient=?,quantity_scale=?', repository)
        self.assertIn('SET concept=?,amount_coefficient=?,amount_scale=?', repository)
        self.assertIn('SET new_price_coefficient=?,new_price_scale=?,balance_coefficient=?,balance_scale=?', repository)

    def test_negative_stock_is_checked_inside_repository_transactions(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        self.assertIn('Future<void> _assertNoNegativeProductBalance(', repository)
        self.assertIn('throw NegativeInventoryException(', repository)
        self.assertIn('minimumPredecessorFinal: openingQuantity + shortfall', repository)
        # The check runs after writes while still inside the transaction, so
        # rejected changes are rolled back rather than left in the ledger.
        self.assertIn('await _assertNoNegativeProductBalance(cycleId, productId);', repository)
        self.assertIn('await _assertNoNegativeProductBalance(cycleId, details.data', repository)
        self.assertIn('await database.transaction(() async {', repository)
        self.assertIn('balance = balance + entries - losses;', repository)
        self.assertIn('balanceAtTurnStart', repository)

    def test_negative_balance_examples_obey_price_checkpoint_rules(self):
        # Start with 10. A change-price cut records 8 at the start of turn 1;
        # then 3 entries and 2 losses leave 9 (valid). Adding 10 losses must
        # be rejected. A later checkpoint cannot claim more stock than known.
        balance = Decimal('10')
        checkpoint = Decimal('8')
        self.assertLessEqual(checkpoint, balance)
        balance = checkpoint + Decimal('3') - Decimal('2')
        self.assertEqual(balance, Decimal('9'))
        with self.assertRaises(AssertionError):
            projected = balance + Decimal('0') - Decimal('10')
            assert projected >= 0
        impossible_checkpoint = Decimal('9.01')
        self.assertGreater(impossible_checkpoint, balance)


    def test_historical_inventory_correction_is_limited_and_audited(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        turn_screen = (ROOT / 'lib/ui/screens/turn_editor_screen.dart').read_text(encoding='utf-8')
        history_screen = (ROOT / 'lib/ui/screens/history_screen.dart').read_text(encoding='utf-8')
        self.assertIn('correctPreviousInventoryCycleForNegativeBalance', repository)
        self.assertIn("'historical_cycle_reopened_for_negative_inventory'", repository)
        self.assertIn("'historical_cycle_closed_after_inventory_correction'", repository)
        self.assertIn("'opening_inventory_refreshed_from_predecessor_correction'", repository)
        self.assertIn('priceCutAlreadyApplied', repository)
        self.assertIn('await _offerPreviousCycleCorrection(error)', turn_screen)
        self.assertIn('Reabrir y corregir', turn_screen)
        self.assertIn('getCycleRevisions(cycle.id)', history_screen)

    def test_historical_correction_sql_changes_only_previous_final_and_current_initial(self):
        schema = (ROOT / 'lib/data/schema.sql').read_text(encoding='utf-8')
        with tempfile.TemporaryDirectory() as directory:
            db_path = Path(directory) / 'cycles.sqlite'
            db = sqlite3.connect(db_path)
            try:
                db.executescript(schema)
                db.execute("INSERT INTO products VALUES ('p1','Pastel','100',0,0,1,1,1)")
                cycles = [
                    ('c1',1,'full','closed',1,3,None,1,'[]','M','N',1,3),
                    ('c2',2,'inventoryOnly','closed',4,6,'c1',1,'[]','M','N',4,6),
                    ('c3',3,'full','open',7,9,'c2',0,'[]','M','N',7,None),
                ]
                db.executemany(
                    'INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    cycles,
                )
                db.execute("INSERT INTO cycle_products VALUES ('c1','p1','Pastel',0,'10',0,'12',0,'100',0)")
                db.execute("INSERT INTO cycle_products VALUES ('c2','p1','Pastel',0,'12',0,'8',0,'100',0)")
                db.execute("INSERT INTO cycle_products VALUES ('c3','p1','Pastel',0,'8',0,NULL,NULL,'100',0)")
                db.commit()

                current_initial = Decimal(db.execute("SELECT initial_quantity_coefficient FROM cycle_products WHERE cycle_id='c3'").fetchone()[0])
                shortage = Decimal('2')
                minimum = current_initial + shortage
                with self.assertRaises(AssertionError):
                    proposed = Decimal('9')
                    assert proposed >= minimum
                proposed = Decimal('10')
                self.assertGreaterEqual(proposed, minimum)

                db.execute("UPDATE cycle_products SET final_quantity_coefficient=?,final_quantity_scale=0 WHERE cycle_id='c2' AND product_id='p1'", (str(proposed),))
                db.execute("UPDATE cycle_products SET initial_quantity_coefficient=?,initial_quantity_scale=0 WHERE cycle_id='c3' AND product_id='p1'", (str(proposed),))
                db.execute("INSERT INTO cycle_revisions VALUES ('r1','c2',2,'historical_cycle_reopened_for_negative_inventory',8,'{}')")
                db.execute("INSERT INTO cycle_revisions VALUES ('r2','c2',3,'historical_cycle_closed_after_inventory_correction',9,'{}')")
                db.execute("INSERT INTO cycle_revisions VALUES ('r3','c3',1,'opening_inventory_refreshed_from_predecessor_correction',9,'{}')")
                db.commit()

                self.assertEqual(db.execute("SELECT final_quantity_coefficient FROM cycle_products WHERE cycle_id='c2'").fetchone()[0], '10')
                self.assertEqual(db.execute("SELECT initial_quantity_coefficient FROM cycle_products WHERE cycle_id='c3'").fetchone()[0], '10')
                # No se cambia el conteo final del ciclo actual ni ciclos posteriores.
                self.assertIsNone(db.execute("SELECT final_quantity_coefficient FROM cycle_products WHERE cycle_id='c3'").fetchone()[0])
                self.assertEqual(db.execute("SELECT status FROM cycles WHERE id='c2'").fetchone()[0], 'closed')
                self.assertEqual(len(db.execute("SELECT action FROM cycle_revisions WHERE cycle_id='c2'").fetchall()), 2)
                self.assertEqual(db.execute('PRAGMA foreign_key_check').fetchall(), [])
            finally:
                db.close()

    def test_windows_powershell_apk_builder_is_present(self):
        script = (ROOT / 'tool/bootstrap_android.ps1').read_text(encoding='utf-8')
        self.assertIn('ANDROID_SDK_ROOT', script)
        self.assertIn("@('pub', 'get')", script)
        self.assertIn("'build_runner'", script)
        self.assertIn("'--delete-conflicting-outputs'", script)
        self.assertIn("'analyze'", script)
        self.assertIn("@('build', 'apk', '--release')", script)

    def test_sql_schema_executes(self):
        schema = (ROOT / 'lib/data/schema.sql').read_text(encoding='utf-8')
        connection = sqlite3.connect(':memory:')
        try:
            connection.executescript(schema)
            tables = {row[0] for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )}
            expected = {
                'products', 'cycles', 'cycle_products', 'turns', 'inventory_movements',
                'expenses', 'reinvestments', 'product_name_changes', 'price_changes', 'cycle_revisions',
                'cycle_reports', 'backups', 'app_settings'
            }
            self.assertTrue(expected.issubset(tables))
            # SQLite enforces that a product can only have one price change per day.
            connection.execute("INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES ('c1',1,'full','open',1794355200000,1794528000000,NULL,0,'[]','Matutino','Nocturno',1794355200000,NULL)")
            connection.execute("INSERT INTO products VALUES ('p1','Pastel','100',0,0,1,'now','now')")
            connection.execute("INSERT INTO cycle_products VALUES ('c1','p1','Pastel',0,'10',0,NULL,NULL,'100',0)")
            connection.execute("INSERT INTO price_changes VALUES ('pc1','c1',2,1,'p1','Pastel','100',0,'200',0,'8',0,'now')")
            with self.assertRaises(sqlite3.IntegrityError):
                connection.execute("INSERT INTO price_changes VALUES ('pc2','c1',3,1,'p1','Pastel','200',0,'220',0,'8',0,'now')")
        finally:
            connection.close()


    def test_editing_a_pending_close_invalidates_the_draft_and_marks_checkin_dirty(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        history_screen = (ROOT / 'lib/ui/screens/history_screen.dart').read_text(encoding='utf-8')
        self.assertIn('Future<void> _markCycleAsModifiedInTransaction(', repository)
        self.assertIn("UPDATE cycles SET status='open' WHERE id=?", repository)
        self.assertIn("'close_draft_invalidated_by_edit'", repository)
        self.assertIn("'modified-after-check-in'", repository)
        self.assertIn('Future<void> _markAllCheckedDaysAsModified(', repository)
        self.assertIn('turn_index IN (1,3,5) AND turn_index>=?', repository)
        self.assertIn('await _markCycleAsModifiedInTransaction(cycleId, turnIndex);', repository)
        self.assertIn("'close_draft_invalidated_by_historical_inventory_correction'", repository)
        self.assertIn("'close_draft_invalidated_by_edit' => 'Borrador de cierre invalidado por una edición'", history_screen)

    def test_historical_correction_is_atomic_and_accepts_editable_pending_close(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        self.assertIn("currentStatus != 'open' && currentStatus != 'pendingClose'", repository)
        self.assertIn("UPDATE cycles SET status='pendingClose',closed_at=NULL WHERE id=?", repository)
        self.assertIn("UPDATE cycles SET status='closed',closed_at=? WHERE id=?", repository)
        # La reapertura, la corrección, el cierre y el refresh del ciclo actual
        # se realizan dentro de una única transacción.
        start = repository.index('Future<void> correctPreviousInventoryCycleForNegativeBalance(')
        end = repository.index('Future<void> _appendCycleRevision(', start)
        correction = repository[start:end]
        self.assertIn('await database.transaction(() async {', correction)
        self.assertIn('await _assertNoNegativeProductBalance(incident.cycleId, incident.productId);', correction)
        self.assertIn('await _markAllCheckedDaysAsModified(incident.cycleId);', correction)

    def test_product_rename_updates_current_cycle_final_label_and_checkin(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        self.assertIn('UPDATE cycle_products SET product_name_snapshot=? WHERE cycle_id=? AND product_id=?', repository)
        self.assertIn('await _markCycleAsModifiedInTransaction(cycle.id, turnIndex);', repository)
        screen = (ROOT / 'lib/ui/screens/catalog_screen.dart').read_text(encoding='utf-8')
        self.assertIn('effectiveTurnIndex: currentCycle?.kind == CycleKind.full ? _effectiveTurn : null', screen)




    def test_product_editor_initializes_widget_dependent_ids_in_init_state(self):
        screen = (ROOT / 'lib/ui/screens/turn_editor_screen.dart').read_text(encoding='utf-8')
        self.assertEqual(screen.count('String? _productId;'), 3)
        self.assertEqual(screen.count('_productId = widget.initialProductId ??'), 3)
        self.assertNotRegex(screen, r'late\s+String\??\s+_productId\s*=\s*widget\.')

    def test_product_names_are_unique_and_picker_never_selects_ambiguous_match(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        picker = (ROOT / 'lib/ui/product_picker.dart').read_text(encoding='utf-8')
        self.assertIn('Future<void> _assertProductNameAvailable(', repository)
        self.assertIn('await _assertProductNameAvailable(cleanName);', repository)
        self.assertIn('await _assertProductNameAvailable(cleanName, exceptProductId: productId);', repository)
        self.assertIn('matches.length == 1 ? matches.single.id : null', picker)

    def test_catalog_editor_waits_for_cycle_before_save_and_rechecks_before_mutation(self):
        screen = (ROOT / 'lib/ui/screens/catalog_screen.dart').read_text(encoding='utf-8')
        self.assertIn('bool _cycleLoading = true;', screen)
        self.assertIn('if (_cycleLoading) return;', screen)
        self.assertIn('final currentCycle = await widget.repository.getCurrentCycle();', screen)
        self.assertIn('_cycleLoadError != null ? null : _save', screen)

    def test_editing_earlier_turn_invalidates_same_and_later_daily_reviews(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        self.assertIn('final firstAffectedNightTurn = (turnIndex ~/ 2) * 2 + 1;', repository)
        self.assertIn("turn_index IN (1,3,5) AND turn_index>=? AND daily_check_in_at IS NOT NULL", repository)
        # Exercise the same SQL predicate with day-end rows: editing turn 1
        # invalidates days 1-3, while editing turn 4 only invalidates day 3.
        with tempfile.TemporaryDirectory() as directory:
            connection = sqlite3.connect(Path(directory) / 'checkins.sqlite')
            try:
                connection.execute('CREATE TABLE turns(cycle_id TEXT, turn_index INTEGER, daily_check_in_note TEXT, daily_check_in_at INTEGER)')
                connection.executemany(
                    'INSERT INTO turns VALUES(?,?,?,?)',
                    [('c1', index, 'reviewed', 1) for index in (1, 3, 5)],
                )
                sql = ("UPDATE turns SET daily_check_in_note='modified-after-check-in' "
                       'WHERE cycle_id=? AND turn_index IN (1,3,5) AND turn_index>=? AND daily_check_in_at IS NOT NULL')
                connection.execute(sql, ('c1', (1 // 2) * 2 + 1))
                self.assertEqual(connection.execute('SELECT COUNT(*) FROM turns WHERE daily_check_in_note=?', ('modified-after-check-in',)).fetchone()[0], 3)
                connection.execute("UPDATE turns SET daily_check_in_note='reviewed'")
                connection.execute(sql, ('c1', (4 // 2) * 2 + 1))
                self.assertEqual(connection.execute('SELECT turn_index FROM turns WHERE daily_check_in_note=? ORDER BY turn_index', ('modified-after-check-in',)).fetchall(), [(5,)])
            finally:
                connection.close()

    def test_catalog_activation_changes_invalidate_full_cycle_reviews(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        start = repository.index('Future<void> setProductActive(')
        end = repository.index('Future<void> _assertProductCanBeArchived(', start)
        method = repository[start:end]
        self.assertIn('if (wasActive != active)', method)
        self.assertIn('if (cycle.kind == CycleKind.full)', method)
        self.assertIn('await _markCycleAsModifiedInTransaction(cycle.id, 0);', method)


    def test_codermagic_bootstrap_runs_static_checks_before_android_generation(self):
        script = (ROOT / 'tool/bootstrap_android.sh').read_text(encoding='utf-8')
        self.assertLess(script.index('python3 tool/check_dart_delimiters.py'), script.index('flutter create'))
        self.assertLess(script.index('python3 tool/verify_reference_rules.py'), script.index('flutter create'))
        self.assertIn('dart run build_runner build --delete-conflicting-outputs', script)
        self.assertIn('flutter analyze', script)
        self.assertNotIn('--no-fatal-warnings', script)
        self.assertIn('dart analyze --fatal-infos', script)
        self.assertIn('dart test', script)

    def test_build_scripts_enforce_lockfiles_when_available(self):
        bash_script = (ROOT / 'tool/bootstrap_android.sh').read_text(encoding='utf-8')
        powershell_script = (ROOT / 'tool/bootstrap_android.ps1').read_text(encoding='utf-8')
        self.assertIn('flutter pub get --enforce-lockfile', bash_script)
        self.assertIn('dart pub get --enforce-lockfile', bash_script)
        self.assertIn("$FlutterPubArgs += '--enforce-lockfile'", powershell_script)
        self.assertIn("$CorePubArgs += '--enforce-lockfile'", powershell_script)

    def test_expense_delete_query_uses_only_existing_expense_columns(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        method = repository[repository.index('Future<void> deleteTurnRecord('):repository.index('Future<void> _refreshCurrentPrice(')]
        self.assertIn("table == 'expenses'", method)
        self.assertIn('SELECT turn_index, NULL AS product_id FROM expenses', method)
        with tempfile.TemporaryDirectory() as directory:
            db = sqlite3.connect(Path(directory) / 'expense.sqlite')
            try:
                db.execute('CREATE TABLE expenses(id TEXT, cycle_id TEXT, turn_index INTEGER, concept TEXT)')
                db.execute("INSERT INTO expenses VALUES ('e1','c1',3,'Luz')")
                row = db.execute(
                    'SELECT turn_index, NULL AS product_id FROM expenses WHERE id=? AND cycle_id=?',
                    ('e1', 'c1'),
                ).fetchone()
                self.assertEqual(row, (3, None))
            finally:
                db.close()

    def test_day_three_checkin_accepts_an_empty_catalog(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        self.assertIn('COALESCE(SUM(CASE WHEN final_quantity_coefficient IS NOT NULL THEN 1 ELSE 0 END), 0)', repository)
        with tempfile.TemporaryDirectory() as directory:
            db = sqlite3.connect(Path(directory) / 'empty.sqlite')
            try:
                db.execute('CREATE TABLE cycle_products(cycle_id TEXT, final_quantity_coefficient TEXT)')
                total, filled = db.execute(
                    'SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN final_quantity_coefficient IS NOT NULL THEN 1 ELSE 0 END), 0) AS filled FROM cycle_products WHERE cycle_id=?',
                    ('empty-cycle',),
                ).fetchone()
                self.assertEqual((total, filled), (0, 0))
            finally:
                db.close()

    def test_day_three_backup_failure_blocks_cycle_close(self):
        screen = (ROOT / 'lib/ui/screens/final_inventory_screen.dart').read_text(encoding='utf-8')
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        prepare = screen[screen.index('Future<void> _prepare('):screen.index('@override\n  Widget build', screen.index('Future<void> _prepare('))]
        self.assertLess(prepare.index('createDailyBackup('), prepare.index('confirmCycleClose('))
        self.assertIn('throw StateError(', prepare[prepare.index('catch (error)'):])
        self.assertNotIn('dailyBackupWarning', prepare)
        close = repository[repository.index('Future<void> confirmCycleClose('):repository.index('Future<void> correctPreviousInventoryCycleForNegativeBalance(')]
        self.assertIn("daily_check_in_note'] != 'reviewed'", close)
        self.assertIn("backup_kind='daily'", close)
        self.assertIn("SELECT file_path FROM backups", close)
        self.assertIn('await file.exists()', close)
        self.assertIn('await file.length() > 0', close)
        self.assertIn('Falta una copia diaria', close)

    def test_late_turn_entries_resolve_product_name_from_effective_turn(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        helper = repository[repository.index('Future<String> _productNameAtTurn('):repository.index('Future<void> _rebuildProductNameHistory(')]
        self.assertIn('turn_index<=?', helper)
        self.assertIn('ORDER BY turn_index DESC, created_at DESC, rowid DESC', helper)
        self.assertGreaterEqual(repository.count('final productName = await _productNameAtTurn(cycleId, productId, turnIndex);'), 3)
        with tempfile.TemporaryDirectory() as directory:
            db = sqlite3.connect(Path(directory) / 'names.sqlite')
            try:
                db.execute('CREATE TABLE product_name_changes(turn_index INTEGER, old_name TEXT, new_name TEXT, created_at INTEGER)')
                db.executemany('INSERT INTO product_name_changes VALUES(?,?,?,?)', [
                    (4, 'Nombre original', 'Nombre nuevo', 400),
                    (5, 'Nombre nuevo', 'Nombre final', 500),
                ])
                before_rename = db.execute(
                    'SELECT new_name FROM product_name_changes WHERE turn_index<=? ORDER BY turn_index DESC, created_at DESC, rowid DESC LIMIT 1',
                    (3,),
                ).fetchone()
                self.assertIsNone(before_rename)
                base = db.execute(
                    'SELECT old_name FROM product_name_changes ORDER BY turn_index ASC, created_at ASC, rowid ASC LIMIT 1'
                ).fetchone()[0]
                during_first_name = db.execute(
                    'SELECT new_name FROM product_name_changes WHERE turn_index<=? ORDER BY turn_index DESC, created_at DESC, rowid DESC LIMIT 1',
                    (4,),
                ).fetchone()[0]
                self.assertEqual(base, 'Nombre original')
                self.assertEqual(during_first_name, 'Nombre nuevo')
            finally:
                db.close()

    def test_restore_checks_attached_database_foreign_keys_before_pre_backup_or_copy(self):
        service = (ROOT / 'lib/services/backup_service.dart').read_text(encoding='utf-8')
        method = service[service.index('Future<BackupArtifact> restoreFromFile('):service.index('Future<List<BackupArtifact>> listBackups(')]
        fk_check = method.index('PRAGMA restore_source.foreign_key_check')
        pre_backup = method.index('createPreRestoreBackup()')
        delete = method.index('DELETE FROM main.')
        self.assertLess(fk_check, pre_backup)
        self.assertLess(pre_backup, delete)
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'source.sqlite'
            target = Path(directory) / 'target.sqlite'
            src = sqlite3.connect(source)
            dst = sqlite3.connect(target)
            try:
                src.execute('PRAGMA foreign_keys=OFF')
                src.execute('CREATE TABLE parent(id TEXT PRIMARY KEY)')
                src.execute('CREATE TABLE child(parent_id TEXT REFERENCES parent(id))')
                src.execute("INSERT INTO child VALUES ('missing')")
                src.commit()
                dst.execute('CREATE TABLE keep_data(value TEXT)')
                dst.execute("INSERT INTO keep_data VALUES ('safe')")
                dst.commit()
                dst.execute('ATTACH DATABASE ? AS restore_source', (str(source),))
                violations = dst.execute('PRAGMA restore_source.foreign_key_check').fetchall()
                self.assertEqual(len(violations), 1)
                self.assertEqual(dst.execute('SELECT value FROM keep_data').fetchone()[0], 'safe')
            finally:
                src.close()
                dst.close()

    def test_empty_inventory_is_valid_for_next_cycle_sequence(self):
        sequence = (ROOT / 'packages/business_core/lib/services/cycle_sequence_service.dart').read_text(encoding='utf-8')
        self.assertNotIn('previous.finalInventory.isEmpty', sequence)
        tests = (ROOT / 'packages/business_core/test/core_logic_test.dart').read_text(encoding='utf-8')
        self.assertIn('permite continuar con inventario final vacío', tests)
        reopening = (ROOT / 'packages/business_core/lib/services/reopening_service.dart').read_text(encoding='utf-8')
        self.assertNotIn('previous.finalInventory.isEmpty', reopening)

    def test_turn_editor_displays_calculated_money_of_sale(self):
        screen = (ROOT / 'lib/ui/screens/turn_editor_screen.dart').read_text(encoding='utf-8')
        self.assertIn('required this.moneyOfSale', screen)
        self.assertIn("activity.kind == 'expenses' || activity.kind == 'reinvestments'", screen)
        self.assertIn('Dinero de Venta calculado', screen)
        self.assertIn('activity.amount ?? ExactDecimal.zero()', screen)

    def test_cycle_workspace_displays_daily_and_turn_money_totals(self):
        screen = (ROOT / 'lib/ui/screens/cycle_workspace_screen.dart').read_text(encoding='utf-8')
        self.assertIn('class _DayCard', screen)
        self.assertIn('final cash = morning.cashCollected + night.cashCollected;', screen)
        self.assertIn('final sale = morning.moneyOfSale + night.moneyOfSale;', screen)
        self.assertIn('turn.moneyOfSale', screen)

    def test_day_three_checkin_is_created_before_full_cycle_close(self):
        final_screen = (ROOT / 'lib/ui/screens/final_inventory_screen.dart').read_text(encoding='utf-8')
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        backup_service = (ROOT / 'lib/services/backup_service.dart').read_text(encoding='utf-8')
        self.assertIn('getDailyCheckInState(widget.cycle.id, 2)', final_screen)
        self.assertIn('hasUsableDailyBackup(', final_screen)
        self.assertIn('widget.repository.checkInDay(widget.cycle.id, 2)', final_screen)
        self.assertIn('createDailyBackup(', final_screen)
        self.assertIn('createCycleCloseBackup(', final_screen)
        self.assertIn('En el tercer día, registra y revisa primero el inventario final.', repository)
        self.assertIn('Future<bool> hasUsableDailyBackup(', backup_service)
        # La revisión diaria y su copia se intentan antes de confirmar el cierre;
        # la copia de cierre se ejecuta después.
        daily = final_screen.index('createDailyBackup(')
        close = final_screen.index('confirmCycleClose(')
        close_copy = final_screen.index('createCycleCloseBackup(')
        self.assertLess(daily, close)
        self.assertLess(close, close_copy)

    def test_final_inventory_edits_invalidate_third_day_checkin(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        start = repository.index('Future<void> setFinalInventory(')
        end = repository.index('Future<CycleRecord?> getCycleById(', start)
        method = repository[start:end]
        self.assertIn("statusRows.data['cycle_kind'] == 'full'", method)
        self.assertIn('await _markReviewedDayAsModified(cycleId, 5);', method)
        self.assertIn('await database.transaction(() async {', method)
        self.assertIn("'close_draft_invalidated_by_final_inventory_edit'", method)

    def test_report_can_be_copied_and_final_inventory_requires_explicit_count(self):
        final_screen = (ROOT / 'lib/ui/screens/final_inventory_screen.dart').read_text(encoding='utf-8')
        history_screen = (ROOT / 'lib/ui/screens/history_screen.dart').read_text(encoding='utf-8')
        self.assertIn('Clipboard.setData(ClipboardData(text: report))', final_screen)
        self.assertIn("TextEditingController(text: line.finalQuantity?.toLocalizedString() ?? '')", final_screen)
        self.assertIn('Los campos vacíos cuentan como 0', final_screen)
        self.assertIn('Clipboard.setData(ClipboardData(text: report))', history_screen)


    def test_cycle_close_and_next_cycle_creation_are_one_atomic_transaction(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        start = repository.index('Future<void> confirmCycleClose(')
        end = repository.index('Future<void> correctPreviousInventoryCycleForNegativeBalance(', start)
        method = repository[start:end]
        transaction_start = method.index('await database.transaction(() async {')
        insert_next = method.index('await _insertCycleData(')
        transaction_end = method.index('});', insert_next)
        self.assertLess(transaction_start, insert_next)
        self.assertLess(insert_next, transaction_end)
        self.assertNotIn('await createNextCycleAfterClose(cycleId)', method)

        # Simula una creación del ciclo siguiente que falla a mitad del cierre.
        # SQLite debe revertir también el cambio del ciclo anterior a closed.
        schema = (ROOT / 'lib/data/schema.sql').read_text(encoding='utf-8')
        with tempfile.TemporaryDirectory() as directory:
            connection = sqlite3.connect(Path(directory) / 'atomic-close.sqlite')
            try:
                connection.execute('PRAGMA foreign_keys=ON')
                connection.executescript(schema)
                connection.execute("INSERT INTO products VALUES ('p1','Pastel','100',0,0,1,1,1)")
                connection.execute("INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES ('c1',1,'full','pendingClose',1,3,NULL,0,'[]','M','N',1,NULL)")
                connection.execute("INSERT INTO cycle_products VALUES ('c1','p1','Pastel',0,'10',0,'8',0,'100',0)")
                connection.commit()
                with self.assertRaises(sqlite3.IntegrityError):
                    connection.execute('BEGIN')
                    connection.execute("UPDATE cycles SET status='closed' WHERE id='c1'")
                    connection.execute("INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES ('c2',2,'inventoryOnly','open',4,6,'c1',0,'[]','M','N',4,NULL)")
                    # Provoca el error de referencia que también podría ocurrir
                    # al crear las filas de productos del ciclo siguiente.
                    connection.execute("INSERT INTO cycle_products VALUES ('c2','missing','Inexistente',0,'8',0,NULL,NULL,'100',0)")
                    connection.commit()
                connection.rollback()
                self.assertEqual(connection.execute("SELECT status FROM cycles WHERE id='c1'").fetchone()[0], 'pendingClose')
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM cycles WHERE id='c2'").fetchone()[0], 0)
            finally:
                connection.close()

    def test_archiving_product_requires_exact_zero_known_stock(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        policy = (ROOT / 'packages/business_core/lib/services/catalog_policy.dart').read_text(encoding='utf-8')
        unit_tests = (ROOT / 'packages/business_core/test/core_logic_test.dart').read_text(encoding='utf-8')
        self.assertIn('await _assertProductCanBeArchived(productId);', repository)
        self.assertNotIn('No puedes retirar el último producto activo', repository)
        self.assertIn('Una vez que todos los artículos de saldo cero se han retirado', repository)
        self.assertIn('Future<void> _assertProductCanBeArchived(', repository)
        self.assertIn('Future<ExactDecimal> _getKnownQuantityInCycle(', repository)
        self.assertIn('price_changes WHERE cycle_id=? AND product_id=? AND turn_index=?', repository)
        self.assertIn('inventory_movements ', repository)
        self.assertIn('reinvestments ', repository)
        self.assertIn('if (!knownQuantity.isZero)', policy)
        self.assertIn('permite retirar un producto sin existencias', unit_tests)
        self.assertIn('impide retirar un producto que todavía tiene existencias', unit_tests)
        self.assertIn('await database.transaction(() async {', repository[repository.index('Future<void> setProductActive('):repository.index('Future<void> _assertProductCanBeArchived(')])
        self.assertEqual(Decimal('0.00'), Decimal('0'))
        self.assertNotEqual(Decimal('0.01'), Decimal('0'))


    def test_empty_inventory_cycle_can_close_after_all_zero_stock_products_are_archived(self):
        repository = (ROOT / 'lib/data/app_repository.dart').read_text(encoding='utf-8')
        start = repository.index('Future<void> confirmCycleClose(')
        end = repository.index('Future<void> correctPreviousInventoryCycleForNegativeBalance(', start)
        method = repository[start:end]
        self.assertNotIn('finalInventory.isEmpty', method)
        self.assertNotIn('products.isEmpty', method)
        schema = (ROOT / 'lib/data/schema.sql').read_text(encoding='utf-8')
        with tempfile.TemporaryDirectory() as directory:
            connection = sqlite3.connect(Path(directory) / 'empty-inventory.sqlite')
            try:
                connection.executescript(schema)
                connection.execute("INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES ('c1',1,'full','closed',1,3,NULL,0,'[]','M','N',1,3)")
                connection.execute("INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES ('c2',2,'inventoryOnly','pendingClose',4,6,'c1',0,'[]','M','N',4,NULL)")
                connection.commit()
                connection.execute('BEGIN')
                connection.execute("UPDATE cycles SET status='closed',closed_at=7 WHERE id='c2'")
                connection.execute("INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) VALUES ('c3',3,'full','open',7,9,'c2',0,'[]','M','N',8,NULL)")
                connection.commit()
                self.assertEqual(connection.execute("SELECT cycle_kind,status FROM cycles WHERE id='c3'").fetchone(), ('full','open'))
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM cycle_products WHERE cycle_id='c3'").fetchone()[0], 0)
            finally:
                connection.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)

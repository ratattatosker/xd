#!/usr/bin/env python3
"""Lightweight structural check for Dart delimiters; not a Dart parser/analyzer."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
OPEN_TO_CLOSE = {'(': ')', '[': ']', '{': '}'}
CLOSE_TO_OPEN = {value: key for key, value in OPEN_TO_CLOSE.items()}


def check(path: Path) -> list[str]:
    source = path.read_text(encoding='utf-8')
    stack: list[tuple[str, int, int]] = []
    errors: list[str] = []
    i = 0
    line = 1
    column = 1
    state = 'code'
    quote = ''
    triple = False
    block_depth = 0

    def advance(text: str) -> None:
        nonlocal line, column
        parts = text.split('\n')
        if len(parts) > 1:
            line += len(parts) - 1
            column = len(parts[-1]) + 1
        else:
            column += len(text)

    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ''

        if state == 'line_comment':
            if ch == '\n':
                state = 'code'
            advance(ch); i += 1; continue

        if state == 'block_comment':
            if ch == '/' and nxt == '*':
                block_depth += 1; advance('/*'); i += 2; continue
            if ch == '*' and nxt == '/':
                block_depth -= 1; advance('*/'); i += 2
                if block_depth == 0:
                    state = 'code'
                continue
            advance(ch); i += 1; continue

        if state == 'string':
            if ch == '\\' and not quote.startswith('r'):
                consumed = source[i:i + 2]
                advance(consumed); i += len(consumed); continue
            if triple:
                terminator = quote[-1] * 3
                if source.startswith(terminator, i):
                    advance(terminator); i += 3; state = 'code'; continue
            elif ch == quote[-1]:
                advance(ch); i += 1; state = 'code'; continue
            advance(ch); i += 1; continue

        # code state
        if ch == '/' and nxt == '/':
            state = 'line_comment'; advance('//'); i += 2; continue
        if ch == '/' and nxt == '*':
            state = 'block_comment'; block_depth = 1; advance('/*'); i += 2; continue

        # Support ordinary and raw Dart strings (r'...', r"...", triple strings).
        prefix_len = 0
        if ch in 'rR' and nxt in "'\"":
            prefix_len = 1
        qpos = i + prefix_len
        if source[qpos:qpos + 1] in ("'", '"'):
            q = source[qpos]
            is_triple = source.startswith(q * 3, qpos)
            opening = ('r' if prefix_len else '') + (q * 3 if is_triple else q)
            quote = ('r' if prefix_len else '') + q
            triple = is_triple
            state = 'string'
            advance(opening); i += len(opening); continue

        if ch in OPEN_TO_CLOSE:
            stack.append((ch, line, column))
        elif ch in CLOSE_TO_OPEN:
            if not stack or stack[-1][0] != CLOSE_TO_OPEN[ch]:
                errors.append(f'{path.relative_to(ROOT)}:{line}:{column}: unexpected {ch}')
            else:
                stack.pop()
        advance(ch); i += 1

    if state == 'block_comment':
        errors.append(f'{path.relative_to(ROOT)}: unclosed block comment')
    if state == 'string':
        errors.append(f'{path.relative_to(ROOT)}: unclosed string')
    for ch, start_line, start_col in reversed(stack):
        errors.append(f'{path.relative_to(ROOT)}:{start_line}:{start_col}: unclosed {ch}')
    return errors


def main() -> int:
    files = sorted(ROOT.rglob('*.dart'))
    failures = [error for path in files for error in check(path)]
    if failures:
        print('\n'.join(failures))
        return 1
    print(f'{len(files)} archivos Dart: delimitadores balanceados (comprobación léxica; no sustituye al analizador Dart).')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

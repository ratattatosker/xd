import 'package:flutter/material.dart';

import 'data/app_database.dart';
import 'data/catalog_seeder.dart';
import 'ui/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final database = AppDatabase();
  await CatalogSeeder(database).seedIfEmpty();
  runApp(ControlComercialApp(database: database));
}

class ControlComercialApp extends StatelessWidget {
  const ControlComercialApp({super.key, required this.database});

  final AppDatabase database;

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF245B75),
      brightness: Brightness.light,
    );
    return MaterialApp(
      title: 'Control Comercial',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: scheme,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F7F8),
        cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: scheme.outlineVariant),
          ),
        ),
      ),
      home: HomePage(database: database),
    );
  }
}

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../../data/app_database.dart';
import '../../services/backup_service.dart';

class BackupManagerScreen extends StatefulWidget {
  const BackupManagerScreen({super.key, required this.database});

  final AppDatabase database;

  @override
  State<BackupManagerScreen> createState() => _BackupManagerScreenState();
}

class _BackupManagerScreenState extends State<BackupManagerScreen> {
  late final BackupService _service = BackupService(widget.database);
  late Future<List<BackupArtifact>> _backups = _service.listBackups();
  bool _busy = false;

  void _reload() => setState(() => _backups = _service.listBackups());

  Future<void> _createAndExport() async {
    setState(() => _busy = true);
    try {
      final backup = await _service.createManualBackup();
      final bytes = await backup.file.readAsBytes();
      final destination = await FilePicker.saveFile(
        dialogTitle: 'Guardar copia de seguridad',
        fileName: 'control_comercial_${_stamp(DateTime.now())}.sqlite',
        bytes: bytes,
        mimeType: 'application/vnd.sqlite3',
      );
      if (destination != null) {
        await _service.markExported(backup.id);
        _message('Copia exportada correctamente: ${destination.path}');
      } else {
        _message('La copia manual quedó guardada dentro de la aplicación. No se exportó a otra ubicación.');
      }
      _reload();
    } catch (error) {
      _message('No se pudo crear o exportar la copia: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    final selected = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: const ['sqlite', 'db'],
    );
    if (selected == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Reemplazar todos los datos'),
        content: Text(
          'Se restaurará «${selected.name}». Esto sustituirá el catálogo, ciclos, movimientos, inventarios e informes actuales. Antes se creará una copia de seguridad del estado actual. ¿Continuar?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Restaurar')),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _busy = true);
    File? temporary;
    try {
      final bytes = await selected.readAsBytes();
      final support = await getApplicationSupportDirectory();
      temporary = File('${support.path}${Platform.pathSeparator}selected_restore_${DateTime.now().microsecondsSinceEpoch}.sqlite');
      await temporary.writeAsBytes(bytes, flush: true);
      final safety = await _service.restoreFromFile(temporary);
      _message('Restauración completada. Copia de seguridad del estado anterior: ${safety.file.path}');
      _reload();
    } catch (error) {
      _message('No se pudo restaurar la copia: $error');
    } finally {
      if (temporary != null && await temporary.exists()) await temporary.delete();
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 7)),
    );
  }

  String _stamp(DateTime date) =>
      '${date.year}${date.month.toString().padLeft(2, '0')}${date.day.toString().padLeft(2, '0')}_'
      '${date.hour.toString().padLeft(2, '0')}${date.minute.toString().padLeft(2, '0')}';

  String _kindLabel(String kind) => switch (kind) {
        'daily' => 'Automática diaria',
        'cycleClose' => 'Cierre de ciclo',
        'manual' => 'Manual',
        'preRestore' => 'Antes de restaurar',
        _ => kind,
      };

  String _date(DateTime value) =>
      '${value.day.toString().padLeft(2, '0')}/${value.month.toString().padLeft(2, '0')}/${value.year} '
      '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Copias de seguridad')),
      body: FutureBuilder<List<BackupArtifact>>(
        future: _backups,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          final backups = snapshot.data ?? const <BackupArtifact>[];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Protección de los datos', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 8),
                    const Text(
                      'Las copias automáticas se generan en ciclos completos: al confirmar la revisión nocturna y al cerrar el ciclo. Los ciclos exclusivamente de inventario no generan copias automáticas.',
                      style: TextStyle(height: 1.4),
                    ),
                    const SizedBox(height: 14),
                    FilledButton.icon(
                      onPressed: _busy ? null : _createAndExport,
                      icon: const Icon(Icons.save_alt),
                      label: const Text('Crear copia manual y exportar'),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _busy ? null : _restore,
                      icon: const Icon(Icons.settings_backup_restore),
                      label: const Text('Restaurar desde un archivo'),
                    ),
                    if (_busy) ...[
                      const SizedBox(height: 12),
                      const LinearProgressIndicator(),
                    ],
                  ]),
                ),
              ),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: Text('Copias guardadas en este teléfono', style: Theme.of(context).textTheme.titleMedium)),
                IconButton(onPressed: _busy ? null : _reload, icon: const Icon(Icons.refresh)),
              ]),
              if (backups.isEmpty)
                const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Todavía no hay copias registradas.')))
              else
                ...backups.map((backup) => Card(
                      child: ListTile(
                        leading: const Icon(Icons.backup_outlined),
                        title: Text(_kindLabel(backup.kind)),
                        subtitle: Text('${_date(backup.createdAt)}\n${backup.file.path}', maxLines: 3, overflow: TextOverflow.ellipsis),
                        isThreeLine: true,
                        trailing: Icon(backup.file.existsSync() ? Icons.check_circle_outline : Icons.error_outline),
                      ),
                    )),
            ],
          );
        },
      ),
    );
  }
}

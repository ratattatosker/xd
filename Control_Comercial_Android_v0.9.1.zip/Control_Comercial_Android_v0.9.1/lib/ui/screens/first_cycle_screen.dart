import 'package:flutter/material.dart';

import 'package:business_core/business_core.dart';
import '../../data/app_repository.dart';

class FirstCycleScreen extends StatefulWidget {
  const FirstCycleScreen({super.key, required this.repository});
  final AppRepository repository;

  @override
  State<FirstCycleScreen> createState() => _FirstCycleScreenState();
}

class _FirstCycleScreenState extends State<FirstCycleScreen> {
  DateTime _startDate = DateTime.now();
  final Map<String, TextEditingController> _controllers = {};
  bool _saving = false;
  late final Future<List<ProductRecord>> _products = widget.repository.getProducts();

  @override
  void dispose() {
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  TextEditingController _controllerFor(String productId) =>
      _controllers.putIfAbsent(productId, () => TextEditingController(text: '0'));

  Future<void> _chooseDate() async {
    final selected = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      helpText: 'Fecha inicial del primer ciclo',
    );
    if (selected != null) setState(() => _startDate = selected);
  }

  Future<void> _save(List<ProductRecord> products) async {
    setState(() => _saving = true);
    try {
      final inventory = <String, ExactDecimal>{};
      for (final product in products) {
        final raw = _controllerFor(product.id).text.trim();
        inventory[product.id] = raw.isEmpty ? ExactDecimal.zero() : ExactDecimal.parse(raw);
      }
      await widget.repository.createFirstCycle(startDate: _startDate, initialInventory: inventory);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Primer ciclo creado.')));
      Navigator.of(context).pop();
    } catch (error) {
      if (mounted) _showError(error.toString());
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showError(String message) => showDialog<void>(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('No se pudo crear el ciclo'),
      content: Text(message),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Entendido'))],
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Primer ciclo')),
      body: FutureBuilder<List<ProductRecord>>(
        future: _products,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          final products = snapshot.data ?? const <ProductRecord>[];
          final missingPrices = products.where((p) => p.price.isZero).length;
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Card(
                child: ListTile(
                  leading: const Icon(Icons.calendar_month),
                  title: const Text('Fecha inicial'),
                  subtitle: Text(_date(_startDate)),
                  trailing: const Icon(Icons.edit_calendar),
                  onTap: _chooseDate,
                ),
              ),
            ),
            if (missingPrices > 0)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Material(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text('$missingPrices productos tienen precio 0. Revísalos en Catálogo antes de registrar ventas estimadas.',
                        style: TextStyle(color: Colors.brown.shade800)),
                  ),
                ),
              ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Inventario inicial', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                itemCount: products.length,
                separatorBuilder: (_, __) => const SizedBox(height: 6),
                itemBuilder: (context, index) {
                  final product = products[index];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      child: Row(children: [
                        Expanded(child: Text(product.name, style: const TextStyle(fontWeight: FontWeight.w500))),
                        SizedBox(
                          width: 106,
                          child: TextField(
                            controller: _controllerFor(product.id),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: false),
                            textAlign: TextAlign.end,
                            decoration: const InputDecoration(labelText: 'Cantidad', isDense: true),
                          ),
                        ),
                      ]),
                    ),
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _saving ? null : () => _save(products),
                    icon: _saving
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.check),
                    label: Text(_saving ? 'Guardando…' : 'Crear primer ciclo'),
                  ),
                ),
              ),
            ),
          ]);
        },
      ),
    );
  }

  String _date(DateTime d) => '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}

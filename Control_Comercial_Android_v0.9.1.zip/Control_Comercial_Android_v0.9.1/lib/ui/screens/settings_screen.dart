import 'package:flutter/material.dart';

import '../../data/app_repository.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.repository});
  final AppRepository repository;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final Future<AppConfiguration> _configuration = widget.repository.getConfiguration();
  final _reportNames = TextEditingController();
  final _morningName = TextEditingController();
  final _nightName = TextEditingController();
  bool _loaded = false;
  bool _saving = false;

  @override
  void dispose() {
    _reportNames.dispose();
    _morningName.dispose();
    _nightName.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await widget.repository.saveConfiguration(
        reportNames: _reportNames.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
        morningWorkerName: _morningName.text,
        nightWorkerName: _nightName.text,
      );
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Configuración guardada.')));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configuración')),
      body: FutureBuilder<AppConfiguration>(
        future: _configuration,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          if (!_loaded) {
            final config = snapshot.data!;
            _reportNames.text = config.reportNames.join(', ');
            _morningName.text = config.morningWorkerName;
            _nightName.text = config.nightWorkerName;
            _loaded = true;
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Informe de cierre', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              TextField(
                controller: _reportNames,
                decoration: const InputDecoration(
                  labelText: 'Nombres del encabezado',
                  hintText: 'Mario, Isabel',
                  helperText: 'Escribe uno o varios nombres separados por comas.',
                ),
              ),
              const SizedBox(height: 22),
              Text('Trabajadores', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              TextField(controller: _morningName, decoration: const InputDecoration(labelText: 'Trabajador matutino')),
              const SizedBox(height: 10),
              TextField(controller: _nightName, decoration: const InputDecoration(labelText: 'Trabajador nocturno')),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: const Icon(Icons.save_outlined),
                label: Text(_saving ? 'Guardando…' : 'Guardar configuración'),
              ),
              const SizedBox(height: 18),
              const Text(
                'Los salarios se calculan al cerrar cada ciclo completo: 5 % de los tres turnos matutinos y 5 % de los tres turnos nocturnos. La aplicación solo informa los importes; no registra pagos ni deudas.',
                style: TextStyle(color: Colors.black54, height: 1.45),
              ),
            ],
          );
        },
      ),
    );
  }
}

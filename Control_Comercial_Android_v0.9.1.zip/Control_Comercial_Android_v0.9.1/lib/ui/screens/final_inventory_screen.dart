import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:business_core/business_core.dart';
import '../../data/app_repository.dart';
import '../../services/backup_service.dart';

class FinalInventoryScreen extends StatefulWidget {
  const FinalInventoryScreen({super.key, required this.repository, required this.cycle});
  final AppRepository repository;
  final CycleRecord cycle;

  @override
  State<FinalInventoryScreen> createState() => _FinalInventoryScreenState();
}

class _FinalInventoryScreenState extends State<FinalInventoryScreen> {
  final Map<String, TextEditingController> _controllers = {};
  late Future<List<InventoryLine>> _lines = widget.repository.getInventoryLines(widget.cycle.id);
  bool _saving = false;

  TextEditingController _controller(InventoryLine line) => _controllers.putIfAbsent(
    line.productId,
    // Si todavía no se ha contado físicamente, el campo queda vacío. No se
    // debe confundir el inventario inicial con el inventario final real.
    () => TextEditingController(text: line.finalQuantity?.toLocalizedString() ?? ''),
  );

  @override
  void dispose() {
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _prepare(List<InventoryLine> lines) async {
    setState(() => _saving = true);
    try {
      final values = <String, ExactDecimal>{};
      for (final line in lines) {
        final raw = _controller(line).text.trim();
        values[line.productId] = ExactDecimal.parse(raw);
      }
      final preview = await widget.repository.prepareCycleClose(widget.cycle.id, values);
      if (!mounted) return;
      final confirm = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _CloseReviewDialog(preview: preview),
      );
      if (confirm != true) return;

      String? dailyBackupPath;
      if (widget.cycle.kind == CycleKind.full) {
        final backupService = BackupService(widget.repository.database);
        final businessDate = DateTime(
          widget.cycle.startDate.year,
          widget.cycle.startDate.month,
          widget.cycle.startDate.day,
        ).add(const Duration(days: 2));
        try {
          final checkInState = await widget.repository.getDailyCheckInState(widget.cycle.id, 2);
          final hasDailyCopy = await backupService.hasUsableDailyBackup(
            cycleId: widget.cycle.id,
            businessDate: businessDate,
          );
          // El inventario final ya quedó guardado y revisado antes de llegar
          // aquí. El cierre confirma también la revisión nocturna del tercer
          // día y garantiza su copia diaria antes de generar la copia de cierre.
          if (checkInState != 'reviewed' || !hasDailyCopy) {
            await widget.repository.checkInDay(widget.cycle.id, 2);
            final daily = await backupService.createDailyBackup(
              cycleId: widget.cycle.id,
              businessDate: businessDate,
            );
            dailyBackupPath = daily.file.path;
          }
        } catch (error) {
          // La copia diaria del tercer día es un requisito previo del cierre.
          // No se permite confirmar el ciclo si no pudo generarse.
          throw StateError(
            'No se puede cerrar el ciclo porque falló la copia diaria del tercer día. '
            'Corrige el problema de almacenamiento y vuelve a intentarlo. Detalle: $error',
          );
        }
      }

      await widget.repository.confirmCycleClose(widget.cycle.id);
      String message = 'Ciclo cerrado. El siguiente ciclo ya está preparado.';
      if (widget.cycle.kind == CycleKind.full) {
        try {
          final artifact = await BackupService(widget.repository.database).createCycleCloseBackup(cycleId: widget.cycle.id);
          message = dailyBackupPath == null
              ? 'Ciclo cerrado y copia adicional de cierre creada: ${artifact.file.path}'
              : 'Ciclo cerrado. Copia diaria: $dailyBackupPath. Copia de cierre: ${artifact.file.path}';
        } catch (error) {
          message = 'Ciclo cerrado, pero falló la copia adicional de cierre. Exporta una copia manual cuanto antes. Detalle: $error';
        }
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 6)));
        Navigator.of(context).pop();
      }
    } catch (error) {
      if (mounted) {
        showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('No se puede preparar el cierre'),
            content: SingleChildScrollView(child: Text(error.toString())),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Entendido'))],
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final full = widget.cycle.kind == CycleKind.full;
    return Scaffold(
      appBar: AppBar(title: Text(full ? 'Inventario final' : 'Conteo final del ciclo')),
      body: FutureBuilder<List<InventoryLine>>(
        future: _lines,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          final lines = snapshot.data ?? const <InventoryLine>[];
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Text(
                full
                    ? 'Cuenta físicamente todos los productos al finalizar el tercer día. Introduce cada cantidad, incluso 0. Los campos sin contar quedan vacíos. El total se utilizará como inventario inicial del ciclo exclusivamente de inventario.'
                    : 'Este es el único registro comercial de este ciclo. Introduce cada inventario físico final, incluso 0. Los campos sin contar quedan vacíos; no se solicitarán turnos ni movimientos.',
                style: const TextStyle(color: Colors.black54, height: 1.4),
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                itemCount: lines.length,
                separatorBuilder: (_, __) => const SizedBox(height: 6),
                itemBuilder: (context, index) {
                  final line = lines[index];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      child: Row(children: [
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(line.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                          Text('Inicio: ${line.initial.toLocalizedString()}', style: const TextStyle(color: Colors.black54, fontSize: 12)),
                        ])),
                        SizedBox(
                          width: 110,
                          child: TextField(
                            controller: _controller(line),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            textAlign: TextAlign.end,
                            decoration: const InputDecoration(labelText: 'Final', isDense: true),
                          ),
                        ),
                      ]),
                    ),
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _saving ? null : () => _prepare(lines),
                    icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.fact_check_outlined),
                    label: Text(_saving ? 'Calculando…' : 'Revisar y cerrar ciclo'),
                  ),
                ),
              ),
            ),
          ]);
        },
      ),
    );
  }
}

class _CloseReviewDialog extends StatelessWidget {
  const _CloseReviewDialog({required this.preview});
  final ClosePreview preview;

  @override
  Widget build(BuildContext context) {
    final calculation = preview.calculation;
    return AlertDialog(
      title: const Text('Revisión del cierre'),
      content: SizedBox(
        width: 560,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            if (calculation == null) ...[
              const Text('Ciclo exclusivamente de inventario.'),
              const SizedBox(height: 8),
              const Text('Se guardarán los inventarios finales y se abrirá el siguiente ciclo completo. No se generarán datos financieros ni copias automáticas.'),
            ] else ...[
              Text('Dinero Recogido: \$${calculation.totalCashCollected.toLocalizedString(groupThousands: true)}'),
              Text('Dinero de Venta Total: \$${calculation.totalMoneyOfSale.toLocalizedString(groupThousands: true)}'),
              Text('Venta estimada por inventario: \$${calculation.totalEstimatedSales.toLocalizedString(groupThousands: true)}'),
              const Divider(height: 24),
              Text('Salario de ${calculation.salarySummary.morningWorkerName}: \$${calculation.salarySummary.morningSalary.toLocalizedString(groupThousands: true)}'),
              Text('Salario de ${calculation.salarySummary.nightWorkerName}: \$${calculation.salarySummary.nightSalary.toLocalizedString(groupThousands: true)}'),
              const SizedBox(height: 6),
              const Text('Los salarios son informativos y no se añaden a Gastos ni al informe copiable.', style: TextStyle(color: Colors.black54, fontSize: 12)),
              const SizedBox(height: 8),
              const Text('Al confirmar el cierre también se confirmará la revisión nocturna del tercer día y se intentará crear su copia diaria. Después se creará la copia adicional del cierre.', style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.35)),
              const Divider(height: 24),
              Row(
                children: [
                  const Expanded(child: Text('Informe final en texto plano', style: TextStyle(fontWeight: FontWeight.bold))),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final report = preview.reportText ?? '';
                      await Clipboard.setData(ClipboardData(text: report));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Informe copiado al portapapeles.')),
                        );
                      }
                    },
                    icon: const Icon(Icons.copy_outlined, size: 18),
                    label: const Text('Copiar'),
                  ),
                ],
              ),
              SelectableText(preview.reportText ?? ''),
            ],
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Seguir revisando')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Confirmar cierre')),
      ],
    );
  }
}

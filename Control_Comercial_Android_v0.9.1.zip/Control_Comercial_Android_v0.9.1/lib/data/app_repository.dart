import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:drift/drift.dart';

import 'app_database.dart';
import 'package:business_core/business_core.dart';

class ProductRecord {
  const ProductRecord({
    required this.id,
    required this.name,
    required this.price,
    required this.sortOrder,
    required this.active,
  });

  final String id;
  final String name;
  final ExactDecimal price;
  final int sortOrder;
  final bool active;
}

class CycleRecord {
  const CycleRecord({
    required this.id,
    required this.sequenceNumber,
    required this.kind,
    required this.status,
    required this.startDate,
    required this.endDate,
    required this.previousCycleId,
    required this.revisionNumber,
  });

  final String id;
  final int sequenceNumber;
  final CycleKind kind;
  final CycleStatus status;
  final DateTime startDate;
  final DateTime endDate;
  final String? previousCycleId;
  final int revisionNumber;

  String get kindLabel => kind == CycleKind.full ? 'Ciclo completo' : 'Solo inventario';
  String get statusLabel => switch (status) {
        CycleStatus.open => 'Abierto',
        CycleStatus.pendingClose => 'Pendiente de cierre',
        CycleStatus.closed => 'Cerrado',
      };
}

class InventoryLine {
  const InventoryLine({required this.productId, required this.name, required this.initial, required this.finalQuantity, required this.sortOrder});
  final String productId;
  final String name;
  final ExactDecimal initial;
  final ExactDecimal? finalQuantity;
  final int sortOrder;
}

class TurnActivity {
  const TurnActivity({
    required this.id,
    required this.kind,
    required this.title,
    required this.quantityOrAmount,
    required this.subtitle,
    this.productId,
    this.movementKind,
    this.concept,
    this.quantity,
    this.amount,
    this.newPrice,
    this.balanceAtTurnStart,
  });

  final String id;
  final String kind;
  final String title;
  final String quantityOrAmount;
  final String subtitle;
  final String? productId;
  final MovementKind? movementKind;
  final String? concept;
  final ExactDecimal? quantity;
  final ExactDecimal? amount;
  final ExactDecimal? newPrice;
  final ExactDecimal? balanceAtTurnStart;
}

class AppConfiguration {
  const AppConfiguration({
    required this.reportNames,
    required this.morningWorkerName,
    required this.nightWorkerName,
  });

  final List<String> reportNames;
  final String morningWorkerName;
  final String nightWorkerName;
}

class ClosePreview {
  const ClosePreview({
    required this.cycle,
    required this.reportText,
    required this.calculation,
  });

  final CycleRecord cycle;
  final String? reportText;
  final CycleCalculation? calculation;
}

/// Resultado tipado de una operación rechazada porque dejaría inventario
/// negativo. Solo ofrece corregir el ciclo anterior si el problema nace del
/// inventario inicial heredado y no de un corte de precio posterior.
class NegativeInventoryException implements Exception {
  const NegativeInventoryException({
    required this.cycleId,
    required this.productId,
    required this.productName,
    required this.turnIndex,
    required this.shortfall,
    required this.minimumPredecessorFinal,
    required this.canCorrectPreviousInventoryCycle,
    required this.hasPriorPriceCut,
    this.predecessorCycleId,
  });

  final String cycleId;
  final String productId;
  final String productName;
  final int turnIndex;
  final ExactDecimal shortfall;
  final ExactDecimal minimumPredecessorFinal;
  final bool canCorrectPreviousInventoryCycle;
  final bool hasPriorPriceCut;
  final String? predecessorCycleId;

  @override
  String toString() {
    final detail = hasPriorPriceCut
        ? 'El saldo negativo aparece después de un cambio de precio. Revisa el saldo registrado en ese cambio; la corrección de un ciclo anterior no modifica ese corte.'
        : 'Corrige la cantidad o registra la entrada que falta.';
    return 'La operación dejaría $productName con inventario negativo en ${CalculationService.turnLabel(turnIndex)}. '
        'No se guardó. $detail';
  }
}

class CycleRevisionRecord {
  const CycleRevisionRecord({
    required this.revisionNumber,
    required this.action,
    required this.changedAt,
    required this.payload,
  });

  final int revisionNumber;
  final String action;
  final DateTime changedAt;
  final Map<String, dynamic> payload;
}

class AppRepository {
  AppRepository(this.database);

  final AppDatabase database;
  final Random _random = Random.secure();

  String _newId(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}-${_random.nextInt(1 << 30)}';

  Variable<String> _text(String value) => Variable.withString(value);
  Variable<int> _integer(int value) => Variable.withInt(value);

  ExactDecimal _decimal(Object? coefficient, Object? scale) =>
      ExactDecimal.fromParts(coefficient.toString(), (scale as num).toInt());

  DateTime _date(Object? value) =>
      DateTime.fromMillisecondsSinceEpoch((value as num).toInt());

  DateTime _dayOnly(DateTime value) => DateTime(value.year, value.month, value.day);

  /// Devuelve el nombre que corresponde al producto al inicio del turno.
  /// Los cambios son efectivos desde el turno indicado, incluso cuando una
  /// operación se registra tardíamente en un turno anterior.
  Future<String> _productNameAtTurn(
    String cycleId,
    String productId,
    int turnIndex,
  ) async {
    final applicable = await database.customSelect(
      'SELECT new_name FROM product_name_changes '
      'WHERE cycle_id=? AND product_id=? AND turn_index<=? '
      'ORDER BY turn_index DESC, created_at DESC, rowid DESC LIMIT 1',
      variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
    ).get();
    if (applicable.isNotEmpty) return applicable.first.data['new_name'] as String;

    // La primera old_name conserva el nombre anterior al primer cambio.
    final firstChange = await database.customSelect(
      'SELECT old_name FROM product_name_changes '
      'WHERE cycle_id=? AND product_id=? '
      'ORDER BY turn_index ASC, created_at ASC, rowid ASC LIMIT 1',
      variables: [_text(cycleId), _text(productId)],
    ).get();
    if (firstChange.isNotEmpty) return firstChange.first.data['old_name'] as String;

    final product = await database.customSelect(
      'SELECT current_name FROM products WHERE id=?',
      variables: [_text(productId)],
    ).get();
    if (product.isEmpty) throw StateError('No se encontró el producto.');
    return product.first.data['current_name'] as String;
  }

  /// Recalcula el historial nominal y las instantáneas de cada turno. Esto
  /// permite insertar una renombrada retroactiva sin sobrescribir otra
  /// renombrada que ya sea efectiva en un turno posterior.
  Future<void> _rebuildProductNameHistory(String cycleId, String productId) async {
    final changes = await database.customSelect(
      'SELECT id,old_name,new_name FROM product_name_changes '
      'WHERE cycle_id=? AND product_id=? '
      'ORDER BY turn_index ASC, created_at ASC, rowid ASC',
      variables: [_text(cycleId), _text(productId)],
    ).get();
    if (changes.isEmpty) return;

    var priorName = changes.first.data['old_name'] as String;
    for (final change in changes) {
      await database.customStatement(
        'UPDATE product_name_changes SET old_name=? WHERE id=?',
        [_text(priorName), _text(change.data['id'] as String)],
      );
      priorName = change.data['new_name'] as String;
    }

    for (var turnIndex = 0; turnIndex < 6; turnIndex++) {
      final effectiveName = await _productNameAtTurn(cycleId, productId, turnIndex);
      for (final table in ['inventory_movements', 'reinvestments', 'price_changes']) {
        await database.customStatement(
          'UPDATE $table SET product_name_snapshot=? WHERE cycle_id=? AND product_id=? AND turn_index=?',
          [_text(effectiveName), _text(cycleId), _text(productId), _integer(turnIndex)],
        );
      }
    }
    final finalName = await _productNameAtTurn(cycleId, productId, 5);
    await database.customStatement(
      'UPDATE cycle_products SET product_name_snapshot=? WHERE cycle_id=? AND product_id=?',
      [_text(finalName), _text(cycleId), _text(productId)],
    );
    await database.customStatement(
      'UPDATE products SET current_name=?,updated_at=? WHERE id=?',
      [_text(finalName), _integer(DateTime.now().millisecondsSinceEpoch), _text(productId)],
    );
  }

  Future<void> seedCatalogIfEmpty() async {
    final count = await database.customSelect('SELECT COUNT(*) AS c FROM products').getSingle();
    if ((count.data['c'] as num).toInt() > 0) return;
    // La carga inicial se realiza desde CatalogSeeder para conservar el archivo
    // de catálogo incluido en los assets del proyecto.
    throw StateError('El catálogo todavía no se ha importado. Ejecuta CatalogSeeder.');
  }

  Future<List<ProductRecord>> getProducts({bool activeOnly = true}) async {
    final rows = await database.customSelect(
      'SELECT * FROM products ${activeOnly ? 'WHERE is_active = 1' : ''} ORDER BY sort_order, current_name COLLATE NOCASE',
    ).get();
    return rows.map((row) => ProductRecord(
      id: row.data['id'] as String,
      name: row.data['current_name'] as String,
      price: _decimal(row.data['current_price_coefficient'], row.data['current_price_scale']),
      sortOrder: (row.data['sort_order'] as num).toInt(),
      active: (row.data['is_active'] as num).toInt() == 1,
    )).toList(growable: false);
  }

  Future<AppConfiguration> getConfiguration() async {
    final rows = await database.customSelect('SELECT setting_key, setting_value FROM app_settings').get();
    final values = {for (final row in rows) row.data['setting_key'] as String: row.data['setting_value'] as String};
    List<String> names;
    try {
      names = (jsonDecode(values['report_names'] ?? '[]') as List<dynamic>)
          .map((value) => value.toString().trim())
          .where((value) => value.isNotEmpty)
          .toList();
    } catch (_) {
      names = const [];
    }
    return AppConfiguration(
      reportNames: names,
      morningWorkerName: values['morning_worker_name'] ?? 'Matutino',
      nightWorkerName: values['night_worker_name'] ?? 'Nocturno',
    );
  }

  Future<void> saveConfiguration({
    required List<String> reportNames,
    required String morningWorkerName,
    required String nightWorkerName,
  }) async {
    await database.transaction(() async {
      await _saveSetting('report_names', jsonEncode(reportNames.map((v) => v.trim()).where((v) => v.isNotEmpty).toList()));
      await _saveSetting('morning_worker_name', morningWorkerName.trim().isEmpty ? 'Matutino' : morningWorkerName.trim());
      await _saveSetting('night_worker_name', nightWorkerName.trim().isEmpty ? 'Nocturno' : nightWorkerName.trim());
    });
  }

  Future<void> _saveSetting(String key, String value) async {
    await database.customStatement(
      'INSERT INTO app_settings(setting_key, setting_value) VALUES(?, ?) '
      'ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value',
      [_text(key), _text(value)],
    );
  }

  Future<void> addProduct({required String name, required ExactDecimal price}) async {
    final cleanName = name.trim();
    if (cleanName.isEmpty) throw ArgumentError('El nombre del producto no puede estar vacío.');
    if (price.isNegative) throw ArgumentError('El precio no puede ser negativo.');
    final rows = await database.customSelect('SELECT COALESCE(MAX(sort_order), -1) AS m FROM products').getSingle();
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = _newId('product');
    await database.transaction(() async {
      await database.customStatement(
        'INSERT INTO products(id,current_name,current_price_coefficient,current_price_scale,sort_order,is_active,created_at,updated_at) '
        'VALUES(?,?,?,?,?,1,?,?)',
        [
          _text(id), _text(cleanName), _text(price.databaseCoefficient),
          _integer(price.scale), _integer((rows.data['m'] as num).toInt() + 1),
          _integer(now), _integer(now),
        ],
      );
      final current = await getCurrentCycle();
      if (current != null) {
        await _ensureCycleProduct(current.id, id, cleanName, (rows.data['m'] as num).toInt() + 1,
            ExactDecimal.zero(), price);
      }
    });
  }

  Future<void> setProductActive(String productId, bool active) async {
    // La comprobación de saldo y la retirada se confirman juntas para evitar
    // que el catálogo cambie entre la lectura del inventario y la escritura.
    await database.transaction(() async {
      final exists = await database.customSelect(
        'SELECT id,is_active FROM products WHERE id=?',
        variables: [_text(productId)],
      ).get();
      if (exists.isEmpty) throw StateError('No se encontró el producto.');

      if (!active && (exists.first.data['is_active'] as num).toInt() == 1) {
        await _assertProductCanBeArchived(productId);
      }

      await database.customStatement(
        'UPDATE products SET is_active = ?, updated_at = ? WHERE id = ?',
        [_integer(active ? 1 : 0), _integer(DateTime.now().millisecondsSinceEpoch), _text(productId)],
      );
      if (active) {
        final cycle = await getCurrentCycle();
        if (cycle != null) await _ensureProductInCycle(cycle.id, productId);
      }
    });
  }

  /// Solo permite retirar del catálogo un producto cuyo saldo conocido sea
  /// exactamente cero. Así la creación del ciclo siguiente no omite stock.
  Future<void> _assertProductCanBeArchived(String productId) async {
    final productRows = await database.customSelect(
      'SELECT current_name FROM products WHERE id=?',
      variables: [_text(productId)],
    ).get();
    if (productRows.isEmpty) throw StateError('No se encontró el producto.');
    final productName = productRows.first.data['current_name'] as String;

    final cycle = await getCurrentCycle();
    if (cycle != null) {
      final stock = await _getKnownQuantityInCycle(cycle.id, cycle.kind, productId);
      CatalogPolicy().ensureCanArchive(productName: productName, knownQuantity: stock);
      return;
    }

    // Salvaguarda para una base restaurada o una instalación en la que no
    // exista un ciclo abierto: consulta el último final físico confirmado.
    final latest = await database.customSelect(
      'SELECT cp.final_quantity_coefficient,cp.final_quantity_scale,cp.initial_quantity_coefficient,cp.initial_quantity_scale,c.cycle_kind FROM cycle_products cp JOIN cycles c ON c.id=cp.cycle_id WHERE cp.product_id=? ORDER BY c.sequence_number DESC LIMIT 1',
      variables: [_text(productId)],
    ).get();
    if (latest.isEmpty) return;
    final row = latest.first.data;
    final coefficient = row['final_quantity_coefficient'] ?? row['initial_quantity_coefficient'];
    final scale = row['final_quantity_scale'] ?? row['initial_quantity_scale'];
    final stock = _decimal(coefficient, scale);
    CatalogPolicy().ensureCanArchive(productName: productName, knownQuantity: stock);
  }

  Future<ExactDecimal> _getKnownQuantityInCycle(
    String cycleId,
    CycleKind kind,
    String productId,
  ) async {
    final rows = await database.customSelect(
      'SELECT initial_quantity_coefficient,initial_quantity_scale,final_quantity_coefficient,final_quantity_scale '
      'FROM cycle_products WHERE cycle_id=? AND product_id=?',
      variables: [_text(cycleId), _text(productId)],
    ).get();
    if (rows.isEmpty) return ExactDecimal.zero();
    final row = rows.first.data;
    if (kind == CycleKind.inventoryOnly) {
      final finalCoefficient = row['final_quantity_coefficient'];
      final finalScale = row['final_quantity_scale'];
      return finalCoefficient == null
          ? _decimal(row['initial_quantity_coefficient'], row['initial_quantity_scale'])
          : _decimal(finalCoefficient, finalScale);
    }

    // Un final físico ya introducido en un ciclo pendiente de cierre es más
    // fiable que una proyección calculada a partir de movimientos.
    final currentCycle = await getCycleById(cycleId);
    if (currentCycle?.status == CycleStatus.pendingClose && row['final_quantity_coefficient'] != null) {
      return _decimal(row['final_quantity_coefficient'], row['final_quantity_scale']);
    }

    var balance = _decimal(row['initial_quantity_coefficient'], row['initial_quantity_scale']);
    for (var turnIndex = 0; turnIndex < 6; turnIndex++) {
      final checkpoint = await database.customSelect(
        'SELECT balance_coefficient,balance_scale FROM price_changes WHERE cycle_id=? AND product_id=? AND turn_index=?',
        variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
      ).get();
      if (checkpoint.isNotEmpty) {
        balance = _decimal(
          checkpoint.first.data['balance_coefficient'],
          checkpoint.first.data['balance_scale'],
        );
      }

      final movementRows = await database.customSelect(
        'SELECT movement_kind,quantity_coefficient,quantity_scale FROM inventory_movements '
        'WHERE cycle_id=? AND product_id=? AND turn_index=?',
        variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
      ).get();
      var entries = ExactDecimal.zero();
      var losses = ExactDecimal.zero();
      for (final movement in movementRows) {
        final quantity = _decimal(
          movement.data['quantity_coefficient'],
          movement.data['quantity_scale'],
        );
        if (movement.data['movement_kind'] == 'entry') {
          entries = entries + quantity;
        } else {
          losses = losses + quantity;
        }
      }
      final reinvestmentRows = await database.customSelect(
        'SELECT quantity_coefficient,quantity_scale FROM reinvestments '
        'WHERE cycle_id=? AND product_id=? AND turn_index=?',
        variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
      ).get();
      for (final reinvestment in reinvestmentRows) {
        entries = entries + _decimal(
          reinvestment.data['quantity_coefficient'],
          reinvestment.data['quantity_scale'],
        );
      }
      balance = balance + entries - losses;
    }
    return balance;
  }

  Future<void> archiveProduct(String productId) => setProductActive(productId, false);

  Future<void> updateProductPriceOutsideCycle(String productId, ExactDecimal price) async {
    if (price.isNegative) throw ArgumentError('El precio no puede ser negativo.');
    final current = await getCurrentCycle();
    if (current != null && current.kind == CycleKind.full) {
      throw StateError('Con un ciclo completo abierto, usa «Cambio de precio» dentro del turno correspondiente.');
    }
    await database.customStatement(
      'UPDATE products SET current_price_coefficient=?, current_price_scale=?, updated_at=? WHERE id=?',
      [_text(price.databaseCoefficient), _integer(price.scale), _integer(DateTime.now().millisecondsSinceEpoch), _text(productId)],
    );
  }

  Future<void> renameProduct({
    required String productId,
    required String newName,
    int? effectiveTurnIndex,
  }) async {
    final cleanName = newName.trim();
    if (cleanName.isEmpty) throw ArgumentError('El nombre no puede estar vacío.');
    final productRows = await database.customSelect(
      'SELECT current_name FROM products WHERE id=?',
      variables: [_text(productId)],
    ).get();
    if (productRows.isEmpty) throw StateError('No se encontró el producto.');

    final cycle = await getCurrentCycle();
    final now = DateTime.now().millisecondsSinceEpoch;
    var changed = false;
    if (cycle != null && cycle.kind == CycleKind.full && effectiveTurnIndex != null) {
      if (effectiveTurnIndex < 0 || effectiveTurnIndex > 5) {
        throw ArgumentError('Turno no válido.');
      }
      await database.transaction(() async {
        await _ensureProductInCycle(cycle.id, productId);
        final nameAtTurn = await _productNameAtTurn(cycle.id, productId, effectiveTurnIndex);
        if (nameAtTurn == cleanName) return;
        await database.customStatement(
          'INSERT INTO product_name_changes(id,cycle_id,turn_index,product_id,old_name,new_name,created_at) VALUES(?,?,?,?,?,?,?)',
          [
            _text(_newId('rename')),
            _text(cycle.id),
            _integer(effectiveTurnIndex),
            _text(productId),
            _text(nameAtTurn),
            _text(cleanName),
            _integer(now),
          ],
        );
        await _rebuildProductNameHistory(cycle.id, productId);
        changed = true;
      });
      if (changed) await _markCycleAsModified(cycle.id, effectiveTurnIndex);
      return;
    }

    final oldName = productRows.first.data['current_name'] as String;
    if (oldName == cleanName) return;
    await database.transaction(() async {
      if (cycle != null && cycle.kind == CycleKind.inventoryOnly) {
        await database.customStatement(
          'UPDATE cycle_products SET product_name_snapshot=? WHERE cycle_id=? AND product_id=?',
          [_text(cleanName), _text(cycle.id), _text(productId)],
        );
      }
      await database.customStatement(
        'UPDATE products SET current_name=?, updated_at=? WHERE id=?',
        [_text(cleanName), _integer(now), _text(productId)],
      );
    });
    if (cycle != null && cycle.kind == CycleKind.inventoryOnly && cycle.status == CycleStatus.pendingClose) {
      await database.customStatement("UPDATE cycles SET status='open' WHERE id=?", [_text(cycle.id)]);
      await _appendCycleRevision(
        cycle.id,
        'inventory_cycle_close_draft_invalidated_by_catalog_edit',
        {'productId': productId, 'reason': 'product_name_changed'},
      );
    }
  }

  Future<CycleRecord?> getCurrentCycle() async {
    final rows = await database.customSelect(
      "SELECT * FROM cycles WHERE status IN ('open','pendingClose') ORDER BY sequence_number DESC LIMIT 1",
    ).get();
    if (rows.isEmpty) return null;
    return _cycleRecord(rows.first.data);
  }

  Future<List<CycleRecord>> getCycleHistory() async {
    final rows = await database.customSelect('SELECT * FROM cycles ORDER BY sequence_number DESC').get();
    return rows.map((r) => _cycleRecord(r.data)).toList(growable: false);
  }

  Future<List<CycleRevisionRecord>> getCycleRevisions(String cycleId) async {
    final rows = await database.customSelect(
      'SELECT revision_number,action,changed_at,payload_json FROM cycle_revisions WHERE cycle_id=? ORDER BY revision_number DESC',
      variables: [_text(cycleId)],
    ).get();
    return rows.map((row) {
      Map<String, dynamic> payload;
      try {
        payload = Map<String, dynamic>.from(jsonDecode(row.data['payload_json'] as String) as Map);
      } catch (_) {
        payload = const {};
      }
      return CycleRevisionRecord(
        revisionNumber: (row.data['revision_number'] as num).toInt(),
        action: row.data['action'] as String,
        changedAt: _date(row.data['changed_at']),
        payload: payload,
      );
    }).toList(growable: false);
  }

  CycleRecord _cycleRecord(Map<String, dynamic> row) => CycleRecord(
    id: row['id'] as String,
    sequenceNumber: (row['sequence_number'] as num).toInt(),
    kind: row['cycle_kind'] == 'full' ? CycleKind.full : CycleKind.inventoryOnly,
    status: switch (row['status'] as String) {
      'pendingClose' => CycleStatus.pendingClose,
      'closed' => CycleStatus.closed,
      _ => CycleStatus.open,
    },
    startDate: _date(row['start_date']),
    endDate: _date(row['end_date']),
    previousCycleId: row['previous_cycle_id'] as String?,
    revisionNumber: (row['revision_number'] as num).toInt(),
  );

  Future<void> createFirstCycle({
    required DateTime startDate,
    required Map<String, ExactDecimal> initialInventory,
  }) async {
    final count = await database.customSelect('SELECT COUNT(*) AS c FROM cycles').getSingle();
    if ((count.data['c'] as num).toInt() != 0) throw StateError('El primer ciclo ya fue creado.');
    final products = await getProducts();
    if (products.isEmpty) throw StateError('Añade al menos un producto antes de comenzar.');
    await _createCycle(
      sequenceNumber: 1,
      kind: CycleKind.full,
      startDate: _dayOnly(startDate),
      initialInventory: initialInventory,
      products: products,
      previousCycleId: null,
    );
  }

  Future<void> _createCycle({
    required int sequenceNumber,
    required CycleKind kind,
    required DateTime startDate,
    required Map<String, ExactDecimal> initialInventory,
    required List<ProductRecord> products,
    required String? previousCycleId,
  }) async {
    final config = await getConfiguration();
    await database.transaction(() => _insertCycleData(
      sequenceNumber: sequenceNumber,
      kind: kind,
      startDate: startDate,
      initialInventory: initialInventory,
      products: products,
      previousCycleId: previousCycleId,
      config: config,
    ));
  }

  /// Inserta el ciclo y sus filas dependientes en la transacción que invoque
  /// el método. Se reutiliza para hacer atómico el cierre + ciclo siguiente.
  Future<void> _insertCycleData({
    required int sequenceNumber,
    required CycleKind kind,
    required DateTime startDate,
    required Map<String, ExactDecimal> initialInventory,
    required List<ProductRecord> products,
    required String? previousCycleId,
    required AppConfiguration config,
  }) async {
    final id = _newId('cycle');
    final start = _dayOnly(startDate);
    final end = start.add(const Duration(days: 2));
    final now = DateTime.now().millisecondsSinceEpoch;
    await database.customStatement(
      'INSERT INTO cycles(id,sequence_number,cycle_kind,status,start_date,end_date,previous_cycle_id,revision_number,report_names_json,morning_worker_name,night_worker_name,created_at,closed_at) '
      'VALUES(?,?,?,\'open\',?,?,?,0,?,?,?, ?,NULL)',
      [
        _text(id), _integer(sequenceNumber), _text(kind == CycleKind.full ? 'full' : 'inventoryOnly'),
        _integer(start.millisecondsSinceEpoch), _integer(end.millisecondsSinceEpoch),
        if (previousCycleId == null) Variable<String?>(null) else _text(previousCycleId),
        _text(jsonEncode(config.reportNames)), _text(config.morningWorkerName), _text(config.nightWorkerName), _integer(now),
      ],
    );
    for (final product in products) {
      final quantity = initialInventory[product.id] ?? ExactDecimal.zero();
      await _ensureCycleProduct(id, product.id, product.name, product.sortOrder, quantity, product.price);
    }
    if (kind == CycleKind.full) {
      for (var index = 0; index < 6; index++) {
        await database.customStatement(
          'INSERT INTO turns(id,cycle_id,turn_index,cash_coefficient,cash_scale,daily_check_in_at,daily_check_in_note) VALUES(?,?,?,?,0,NULL,NULL)',
          [_text(_newId('turn')), _text(id), _integer(index), _text('0')],
        );
      }
    }
  }

  Future<void> _ensureCycleProduct(
    String cycleId,
    String productId,
    String name,
    int sortOrder,
    ExactDecimal initial,
    ExactDecimal price,
  ) async {
    await database.customStatement(
      'INSERT OR IGNORE INTO cycle_products(cycle_id,product_id,product_name_snapshot,sort_order_snapshot,initial_quantity_coefficient,initial_quantity_scale,final_quantity_coefficient,final_quantity_scale,initial_price_coefficient,initial_price_scale) '
      'VALUES(?,?,?,?,?,?,NULL,NULL,?,?)',
      [_text(cycleId), _text(productId), _text(name), _integer(sortOrder), _text(initial.databaseCoefficient), _integer(initial.scale), _text(price.databaseCoefficient), _integer(price.scale)],
    );
  }

  Future<void> _ensureProductInCycle(String cycleId, String productId) async {
    final existing = await database.customSelect(
      'SELECT product_id FROM cycle_products WHERE cycle_id=? AND product_id=?',
      variables: [_text(cycleId), _text(productId)],
    ).get();
    if (existing.isNotEmpty) return;
    final rows = await database.customSelect('SELECT * FROM products WHERE id=?', variables: [_text(productId)]).get();
    if (rows.isEmpty) throw StateError('No se encontró el producto.');
    final row = rows.first.data;
    final price = _decimal(row['current_price_coefficient'], row['current_price_scale']);
    await _ensureCycleProduct(cycleId, productId, row['current_name'] as String,
        (row['sort_order'] as num).toInt(), ExactDecimal.zero(), price);
  }

  Future<List<InventoryLine>> getInventoryLines(String cycleId) async {
    final rows = await database.customSelect(
      'SELECT * FROM cycle_products WHERE cycle_id=? ORDER BY sort_order_snapshot',
      variables: [_text(cycleId)],
    ).get();
    return rows.map((row) => InventoryLine(
      productId: row.data['product_id'] as String,
      name: row.data['product_name_snapshot'] as String,
      initial: _decimal(row.data['initial_quantity_coefficient'], row.data['initial_quantity_scale']),
      finalQuantity: row.data['final_quantity_coefficient'] == null
          ? null
          : _decimal(row.data['final_quantity_coefficient'], row.data['final_quantity_scale']),
      sortOrder: (row.data['sort_order_snapshot'] as num).toInt(),
    )).toList(growable: false);
  }

  Future<List<TurnActivity>> getTurnActivities(String cycleId, int turnIndex) async {
    final activities = <TurnActivity>[];
    final movementRows = await database.customSelect(
      'SELECT id,product_id,movement_kind,product_name_snapshot,quantity_coefficient,quantity_scale FROM inventory_movements WHERE cycle_id=? AND turn_index=? ORDER BY created_at',
      variables: [_text(cycleId), _integer(turnIndex)],
    ).get();
    for (final row in movementRows) {
      final isEntry = row.data['movement_kind'] == 'entry';
      final q = _decimal(row.data['quantity_coefficient'], row.data['quantity_scale']);
      activities.add(TurnActivity(
        id: row.data['id'] as String,
        kind: 'inventory_movements',
        title: '${isEntry ? 'Entrada' : 'Baja'} · ${row.data['product_name_snapshot']}',
        quantityOrAmount: q.toLocalizedString(),
        subtitle: isEntry ? 'Aumenta el inventario' : 'Reduce el inventario',
        productId: row.data['product_id'] as String,
        movementKind: isEntry ? MovementKind.entry : MovementKind.loss,
        quantity: q,
      ));
    }
    final expenseRows = await database.customSelect(
      'SELECT id,concept,amount_coefficient,amount_scale FROM expenses WHERE cycle_id=? AND turn_index=? ORDER BY created_at',
      variables: [_text(cycleId), _integer(turnIndex)],
    ).get();
    for (final row in expenseRows) {
      activities.add(TurnActivity(
        id: row.data['id'] as String,
        kind: 'expenses',
        title: row.data['concept'] as String,
        quantityOrAmount: '\$${_decimal(row.data['amount_coefficient'], row.data['amount_scale']).toLocalizedString(groupThousands: true)}',
        subtitle: 'Gasto',
        concept: row.data['concept'] as String,
        amount: _decimal(row.data['amount_coefficient'], row.data['amount_scale']),
      ));
    }
    final reinvestmentRows = await database.customSelect(
      'SELECT id,product_id,product_name_snapshot,quantity_coefficient,quantity_scale,amount_coefficient,amount_scale FROM reinvestments WHERE cycle_id=? AND turn_index=? ORDER BY created_at',
      variables: [_text(cycleId), _integer(turnIndex)],
    ).get();
    for (final row in reinvestmentRows) {
      activities.add(TurnActivity(
        id: row.data['id'] as String,
        kind: 'reinvestments',
        title: 'Reinversión · ${row.data['product_name_snapshot']}',
        quantityOrAmount: '${_decimal(row.data['quantity_coefficient'], row.data['quantity_scale']).toLocalizedString()} unidades',
        subtitle: '\$${_decimal(row.data['amount_coefficient'], row.data['amount_scale']).toLocalizedString(groupThousands: true)} invertidos',
        productId: row.data['product_id'] as String,
        quantity: _decimal(row.data['quantity_coefficient'], row.data['quantity_scale']),
        amount: _decimal(row.data['amount_coefficient'], row.data['amount_scale']),
      ));
    }
    final priceRows = await database.customSelect(
      'SELECT id,product_id,product_name_snapshot,old_price_coefficient,old_price_scale,new_price_coefficient,new_price_scale,balance_coefficient,balance_scale FROM price_changes WHERE cycle_id=? AND turn_index=? ORDER BY created_at',
      variables: [_text(cycleId), _integer(turnIndex)],
    ).get();
    for (final row in priceRows) {
      activities.add(TurnActivity(
        id: row.data['id'] as String,
        kind: 'price_changes',
        title: 'Cambio de precio · ${row.data['product_name_snapshot']}',
        quantityOrAmount: '\$${_decimal(row.data['old_price_coefficient'], row.data['old_price_scale']).toLocalizedString()} → \$${_decimal(row.data['new_price_coefficient'], row.data['new_price_scale']).toLocalizedString()}',
        subtitle: 'Precio nuevo desde este turno',
        productId: row.data['product_id'] as String,
        newPrice: _decimal(row.data['new_price_coefficient'], row.data['new_price_scale']),
        balanceAtTurnStart: _decimal(row.data['balance_coefficient'], row.data['balance_scale']),
      ));
    }
    return activities;
  }

  Future<ExactDecimal> getTurnCash(String cycleId, int turnIndex) async {
    final row = await database.customSelect(
      'SELECT cash_coefficient,cash_scale FROM turns WHERE cycle_id=? AND turn_index=?',
      variables: [_text(cycleId), _integer(turnIndex)],
    ).getSingle();
    return _decimal(row.data['cash_coefficient'], row.data['cash_scale']);
  }

  Future<bool> isDayCheckedIn(String cycleId, int dayIndex) async {
    final row = await database.customSelect(
      'SELECT daily_check_in_at,daily_check_in_note FROM turns WHERE cycle_id=? AND turn_index=?',
      variables: [_text(cycleId), _integer(dayIndex * 2 + 1)],
    ).getSingle();
    return row.data['daily_check_in_at'] != null && row.data['daily_check_in_note'] != 'modified-after-check-in';
  }

  Future<String?> getDailyCheckInState(String cycleId, int dayIndex) async {
    final row = await database.customSelect(
      'SELECT daily_check_in_at,daily_check_in_note FROM turns WHERE cycle_id=? AND turn_index=?',
      variables: [_text(cycleId), _integer(dayIndex * 2 + 1)],
    ).getSingle();
    if (row.data['daily_check_in_at'] == null) return null;
    return row.data['daily_check_in_note'] as String? ?? 'reviewed';
  }

  Future<void> setTurnCash(String cycleId, int turnIndex, ExactDecimal cash) async {
    _validateTurnIndex(turnIndex);
    _validateNonNegative(cash, 'El efectivo no puede ser negativo.');
    await _requireEditableFullCycle(cycleId);
    await database.customStatement(
      'UPDATE turns SET cash_coefficient=?, cash_scale=? WHERE cycle_id=? AND turn_index=?',
      [_text(cash.databaseCoefficient), _integer(cash.scale), _text(cycleId), _integer(turnIndex)],
    );
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> addMovement({
    required String cycleId,
    required int turnIndex,
    required String productId,
    required ExactDecimal quantity,
    required MovementKind kind,
  }) async {
    _validateTurnIndex(turnIndex);
    _validatePositive(quantity, 'La cantidad debe ser mayor que cero.');
    await _requireEditableFullCycle(cycleId);
    await _ensureProductInCycle(cycleId, productId);
    await database.transaction(() async {
      final productName = await _productNameAtTurn(cycleId, productId, turnIndex);
      await database.customStatement(
        'INSERT INTO inventory_movements(id,cycle_id,turn_index,product_id,product_name_snapshot,movement_kind,quantity_coefficient,quantity_scale,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
        [_text(_newId('movement')), _text(cycleId), _integer(turnIndex), _text(productId), _text(productName), _text(kind == MovementKind.entry ? 'entry' : 'loss'), _text(quantity.databaseCoefficient), _integer(quantity.scale), _integer(DateTime.now().millisecondsSinceEpoch)],
      );
      // Una baja no puede dejar el inventario proyectado por debajo de cero.
      // La validación contempla reinversiones y cortes de precio de cada turno.
      await _assertNoNegativeProductBalance(cycleId, productId);
    });
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> addExpense({
    required String cycleId,
    required int turnIndex,
    required String concept,
    required ExactDecimal amount,
  }) async {
    _validateTurnIndex(turnIndex);
    if (concept.trim().isEmpty) throw ArgumentError('Escribe el concepto del gasto.');
    _validateNonNegative(amount, 'El importe del gasto no puede ser negativo.');
    await _requireEditableFullCycle(cycleId);
    await database.customStatement(
      'INSERT INTO expenses(id,cycle_id,turn_index,concept,amount_coefficient,amount_scale,created_at) VALUES(?,?,?,?,?,?,?)',
      [_text(_newId('expense')), _text(cycleId), _integer(turnIndex), _text(concept.trim()), _text(amount.databaseCoefficient), _integer(amount.scale), _integer(DateTime.now().millisecondsSinceEpoch)],
    );
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> addReinvestment({
    required String cycleId,
    required int turnIndex,
    required String productId,
    required ExactDecimal quantity,
    required ExactDecimal amount,
  }) async {
    _validateTurnIndex(turnIndex);
    _validatePositive(quantity, 'La cantidad comprada debe ser mayor que cero.');
    _validateNonNegative(amount, 'El importe invertido no puede ser negativo.');
    await _requireEditableFullCycle(cycleId);
    await _ensureProductInCycle(cycleId, productId);
    final productName = await _productNameAtTurn(cycleId, productId, turnIndex);
    await database.customStatement(
      'INSERT INTO reinvestments(id,cycle_id,turn_index,product_id,product_name_snapshot,quantity_coefficient,quantity_scale,amount_coefficient,amount_scale,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
      [_text(_newId('reinvestment')), _text(cycleId), _integer(turnIndex), _text(productId), _text(productName), _text(quantity.databaseCoefficient), _integer(quantity.scale), _text(amount.databaseCoefficient), _integer(amount.scale), _integer(DateTime.now().millisecondsSinceEpoch)],
    );
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> addPriceChange({
    required String cycleId,
    required int turnIndex,
    required String productId,
    required ExactDecimal newPrice,
    required ExactDecimal balanceAtTurnStart,
  }) async {
    _validateTurnIndex(turnIndex);
    _validateNonNegative(newPrice, 'El precio nuevo no puede ser negativo.');
    _validateNonNegative(balanceAtTurnStart, 'El saldo no puede ser negativo.');
    await _requireEditableFullCycle(cycleId);
    await _ensureProductInCycle(cycleId, productId);
    final dayIndex = turnIndex ~/ 2;
    final duplicate = await database.customSelect(
      'SELECT id FROM price_changes WHERE cycle_id=? AND product_id=? AND day_index=?',
      variables: [_text(cycleId), _text(productId), _integer(dayIndex)],
    ).get();
    if (duplicate.isNotEmpty) throw StateError('Este producto ya tiene un cambio de precio ese día.');
    final cycleProduct = await database.customSelect(
      'SELECT initial_price_coefficient, initial_price_scale FROM cycle_products WHERE cycle_id=? AND product_id=?',
      variables: [_text(cycleId), _text(productId)],
    ).getSingle();
    final previousChanges = await database.customSelect(
      'SELECT new_price_coefficient, new_price_scale FROM price_changes WHERE cycle_id=? AND product_id=? AND turn_index<? ORDER BY turn_index DESC LIMIT 1',
      variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
    ).get();
    final oldPrice = previousChanges.isNotEmpty
        ? _decimal(previousChanges.first.data['new_price_coefficient'], previousChanges.first.data['new_price_scale'])
        : _decimal(cycleProduct.data['initial_price_coefficient'], cycleProduct.data['initial_price_scale']);
    final productName = await _productNameAtTurn(cycleId, productId, turnIndex);
    await database.transaction(() async {
      await database.customStatement(
        'INSERT INTO price_changes(id,cycle_id,turn_index,day_index,product_id,product_name_snapshot,old_price_coefficient,old_price_scale,new_price_coefficient,new_price_scale,balance_coefficient,balance_scale,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [_text(_newId('price')), _text(cycleId), _integer(turnIndex), _integer(dayIndex), _text(productId), _text(productName), _text(oldPrice.databaseCoefficient), _integer(oldPrice.scale), _text(newPrice.databaseCoefficient), _integer(newPrice.scale), _text(balanceAtTurnStart.databaseCoefficient), _integer(balanceAtTurnStart.scale), _integer(DateTime.now().millisecondsSinceEpoch)],
      );
      await _rebuildPriceHistory(cycleId, productId);
      await _assertNoNegativeProductBalance(cycleId, productId);
    });
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> _rebuildPriceHistory(String cycleId, String productId) async {
    final base = await database.customSelect(
      'SELECT initial_price_coefficient,initial_price_scale FROM cycle_products WHERE cycle_id=? AND product_id=?',
      variables: [_text(cycleId), _text(productId)],
    ).getSingle();
    var current = _decimal(base.data['initial_price_coefficient'], base.data['initial_price_scale']);
    final changes = await database.customSelect(
      'SELECT id,new_price_coefficient,new_price_scale FROM price_changes WHERE cycle_id=? AND product_id=? ORDER BY turn_index',
      variables: [_text(cycleId), _text(productId)],
    ).get();
    for (final change in changes) {
      await database.customStatement(
        'UPDATE price_changes SET old_price_coefficient=?,old_price_scale=? WHERE id=?',
        [_text(current.databaseCoefficient), _integer(current.scale), _text(change.data['id'] as String)],
      );
      current = _decimal(change.data['new_price_coefficient'], change.data['new_price_scale']);
    }
    await database.customStatement(
      'UPDATE products SET current_price_coefficient=?,current_price_scale=?,updated_at=? WHERE id=?',
      [_text(current.databaseCoefficient), _integer(current.scale), _integer(DateTime.now().millisecondsSinceEpoch), _text(productId)],
    );
  }

  Future<void> _markCycleAsModified(String cycleId, int turnIndex) async {
    final cycleRows = await database.customSelect(
      'SELECT status FROM cycles WHERE id=?',
      variables: [_text(cycleId)],
    ).get();
    if (cycleRows.isNotEmpty && cycleRows.first.data['status'] == 'pendingClose') {
      await database.transaction(() async {
        await database.customStatement("UPDATE cycles SET status='open' WHERE id=?", [_text(cycleId)]);
        await _appendCycleRevision(
          cycleId,
          'close_draft_invalidated_by_edit',
          {'turnIndex': turnIndex, 'reason': 'cycle_data_changed_before_confirmation'},
        );
      });
    }
    await _markReviewedDayAsModified(cycleId, turnIndex);
  }

  Future<void> _markReviewedDayAsModified(String cycleId, int turnIndex) async {
    final dayIndex = turnIndex ~/ 2;
    final nightIndex = dayIndex * 2 + 1;
    final rows = await database.customSelect(
      'SELECT daily_check_in_at FROM turns WHERE cycle_id=? AND turn_index=?',
      variables: [_text(cycleId), _integer(nightIndex)],
    ).get();
    if (rows.isNotEmpty && rows.first.data['daily_check_in_at'] != null) {
      await database.customStatement(
        'UPDATE turns SET daily_check_in_note=\'modified-after-check-in\' WHERE cycle_id=? AND turn_index=?',
        [_text(cycleId), _integer(nightIndex)],
      );
    }
  }

  Future<void> _markAllCheckedDaysAsModified(String cycleId) async {
    await database.customStatement(
      "UPDATE turns SET daily_check_in_note='modified-after-check-in' WHERE cycle_id=? AND turn_index IN (1,3,5) AND daily_check_in_at IS NOT NULL",
      [_text(cycleId)],
    );
  }

  Future<void> checkInDay(String cycleId, int dayIndex) async {
    if (dayIndex < 0 || dayIndex > 2) throw ArgumentError('Día no válido.');
    await _requireEditableFullCycle(cycleId);
    if (dayIndex == 2) {
      final finalRows = await database.customSelect(
        'SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN final_quantity_coefficient IS NOT NULL THEN 1 ELSE 0 END), 0) AS filled FROM cycle_products WHERE cycle_id=?',
        variables: [_text(cycleId)],
      ).getSingle();
      if ((finalRows.data['total'] as num).toInt() != (finalRows.data['filled'] as num).toInt()) {
        throw StateError('En el tercer día, registra y revisa primero el inventario final.');
      }
    }
    final turnIndex = dayIndex * 2 + 1;
    final now = DateTime.now().millisecondsSinceEpoch;
    await database.customStatement(
      'UPDATE turns SET daily_check_in_at=?, daily_check_in_note=\'reviewed\' WHERE cycle_id=? AND turn_index=?',
      [_integer(now), _text(cycleId), _integer(turnIndex)],
    );
  }

  Future<void> setFinalInventory(String cycleId, Map<String, ExactDecimal> quantities) async {
    final cycle = await getCycleById(cycleId);
    if (cycle == null) throw StateError('No se encontró el ciclo.');
    if (cycle.status == CycleStatus.closed) throw StateError('El ciclo está cerrado.');

    await database.transaction(() async {
      // Relee el estado dentro de la transacción para evitar guardar el final
      // sobre un ciclo que haya sido cerrado por otra operación.
      final statusRows = await database.customSelect(
        'SELECT status,cycle_kind FROM cycles WHERE id=?',
        variables: [_text(cycleId)],
      ).getSingle();
      if (statusRows.data['status'] == 'closed') {
        throw StateError('El ciclo está cerrado.');
      }

      final productRows = await database.customSelect(
        'SELECT product_id,final_quantity_coefficient,final_quantity_scale FROM cycle_products WHERE cycle_id=?',
        variables: [_text(cycleId)],
      ).get();
      final validIds = productRows.map((row) => row.data['product_id'] as String).toSet();
      final unknownIds = quantities.keys.where((id) => !validIds.contains(id)).toList();
      if (unknownIds.isNotEmpty) {
        throw StateError('El inventario contiene productos que no pertenecen a este ciclo.');
      }

      final validated = <String, ExactDecimal>{};
      var hasChanges = false;
      for (final row in productRows) {
        final productId = row.data['product_id'] as String;
        final quantity = quantities[productId];
        if (quantity == null) throw StateError('Falta el inventario final de un producto.');
        _validateNonNegative(quantity, 'El inventario final no puede ser negativo.');
        validated[productId] = quantity;
        final oldCoefficient = row.data['final_quantity_coefficient'];
        final oldScale = row.data['final_quantity_scale'];
        if (oldCoefficient == null || oldScale == null ||
            oldCoefficient.toString() != quantity.databaseCoefficient ||
            (oldScale as num).toInt() != quantity.scale) {
          hasChanges = true;
        }
      }

      for (final entry in validated.entries) {
        await database.customStatement(
          'UPDATE cycle_products SET final_quantity_coefficient=?, final_quantity_scale=? WHERE cycle_id=? AND product_id=?',
          [_text(entry.value.databaseCoefficient), _integer(entry.value.scale), _text(cycleId), _text(entry.key)],
        );
      }

      // Si el usuario había preparado el borrador y cambia un final, el
      // borrador anterior deja de ser válido. Se registra antes de volver a
      // abrir el ciclo, en la misma transacción del conteo nuevo.
      if (hasChanges && statusRows.data['status'] == 'pendingClose') {
        await database.customStatement("UPDATE cycles SET status='open' WHERE id=?", [_text(cycleId)]);
        await _appendCycleRevision(
          cycleId,
          'close_draft_invalidated_by_final_inventory_edit',
          {'reason': 'final_inventory_changed'},
        );
      }

      // La modificación de los finales del ciclo completo también invalida
      // el check-in nocturno y su copia diaria, sin dejar una ventana entre
      // la escritura del inventario y la marca de revisión modificada.
      if (hasChanges && statusRows.data['cycle_kind'] == 'full') {
        await _markReviewedDayAsModified(cycleId, 5);
      }
    });
  }

  Future<CycleRecord?> getCycleById(String id) async {
    final rows = await database.customSelect('SELECT * FROM cycles WHERE id=?', variables: [_text(id)]).get();
    return rows.isEmpty ? null : _cycleRecord(rows.first.data);
  }

  Future<CycleData> loadCycleData(String cycleId) async {
    final cycleRows = await database.customSelect('SELECT * FROM cycles WHERE id=?', variables: [_text(cycleId)]).get();
    if (cycleRows.isEmpty) throw StateError('No se encontró el ciclo.');
    final cycleRow = cycleRows.first.data;
    final kind = cycleRow['cycle_kind'] == 'full' ? CycleKind.full : CycleKind.inventoryOnly;
    final productRows = await database.customSelect(
      'SELECT * FROM cycle_products WHERE cycle_id=? ORDER BY sort_order_snapshot',
      variables: [_text(cycleId)],
    ).get();
    final ids = <String>[];
    final names = <String, String>{};
    final initial = <String, ExactDecimal>{};
    final finalQty = <String, ExactDecimal>{};
    final prices = <String, ExactDecimal>{};
    for (final row in productRows) {
      final data = row.data;
      final id = data['product_id'] as String;
      ids.add(id);
      names[id] = data['product_name_snapshot'] as String;
      initial[id] = _decimal(data['initial_quantity_coefficient'], data['initial_quantity_scale']);
      prices[id] = _decimal(data['initial_price_coefficient'], data['initial_price_scale']);
      if (data['final_quantity_coefficient'] != null) {
        finalQty[id] = _decimal(data['final_quantity_coefficient'], data['final_quantity_scale']);
      }
    }

    final turns = <TurnData>[];
    if (kind == CycleKind.full) {
      final turnRows = await database.customSelect(
        'SELECT * FROM turns WHERE cycle_id=? ORDER BY turn_index', variables: [_text(cycleId)]).get();
      for (final turnRow in turnRows) {
        final td = turnRow.data;
        final index = (td['turn_index'] as num).toInt();
        final movementRows = await database.customSelect(
          'SELECT * FROM inventory_movements WHERE cycle_id=? AND turn_index=? ORDER BY created_at',
          variables: [_text(cycleId), _integer(index)],
        ).get();
        final expensesRows = await database.customSelect(
          'SELECT * FROM expenses WHERE cycle_id=? AND turn_index=? ORDER BY created_at',
          variables: [_text(cycleId), _integer(index)],
        ).get();
        final reinvestmentRows = await database.customSelect(
          'SELECT * FROM reinvestments WHERE cycle_id=? AND turn_index=? ORDER BY created_at',
          variables: [_text(cycleId), _integer(index)],
        ).get();
        turns.add(TurnData(
          index: index,
          cashCollected: _decimal(td['cash_coefficient'], td['cash_scale']),
          movements: movementRows.map((row) => InventoryMovement(
            productId: row.data['product_id'] as String,
            productNameSnapshot: row.data['product_name_snapshot'] as String,
            quantity: _decimal(row.data['quantity_coefficient'], row.data['quantity_scale']),
            kind: row.data['movement_kind'] == 'entry' ? MovementKind.entry : MovementKind.loss,
            turnIndex: index,
          )).toList(),
          expenses: expensesRows.map((row) => ExpenseEntry(
            concept: row.data['concept'] as String,
            amount: _decimal(row.data['amount_coefficient'], row.data['amount_scale']),
            turnIndex: index,
          )).toList(),
          reinvestments: reinvestmentRows.map((row) => ReinvestmentEntry(
            productId: row.data['product_id'] as String,
            productNameSnapshot: row.data['product_name_snapshot'] as String,
            quantity: _decimal(row.data['quantity_coefficient'], row.data['quantity_scale']),
            amount: _decimal(row.data['amount_coefficient'], row.data['amount_scale']),
            turnIndex: index,
          )).toList(),
        ));
      }
    }

    final changesRows = await database.customSelect(
      'SELECT * FROM price_changes WHERE cycle_id=? ORDER BY turn_index', variables: [_text(cycleId)]).get();
    final priceChanges = changesRows.map((row) => PriceChange(
      productId: row.data['product_id'] as String,
      productNameSnapshot: row.data['product_name_snapshot'] as String,
      turnIndex: (row.data['turn_index'] as num).toInt(),
      oldPrice: _decimal(row.data['old_price_coefficient'], row.data['old_price_scale']),
      newPrice: _decimal(row.data['new_price_coefficient'], row.data['new_price_scale']),
      balanceAtTurnStart: _decimal(row.data['balance_coefficient'], row.data['balance_scale']),
    )).toList();

    final renameRows = await database.customSelect(
      'SELECT * FROM product_name_changes WHERE cycle_id=? ORDER BY turn_index', variables: [_text(cycleId)]).get();
    final nameChanges = renameRows.map((row) => ProductNameChange(
      productId: row.data['product_id'] as String,
      turnIndex: (row.data['turn_index'] as num).toInt(),
      oldName: row.data['old_name'] as String,
      newName: row.data['new_name'] as String,
    )).toList();

    List<String> reportNames = const [];
    try {
      reportNames = (jsonDecode(cycleRow['report_names_json'] as String) as List<dynamic>).map((v) => v.toString()).toList();
    } catch (_) {}
    return CycleData(
      id: cycleId,
      kind: kind,
      status: switch (cycleRow['status'] as String) {
        'pendingClose' => CycleStatus.pendingClose,
        'closed' => CycleStatus.closed,
        _ => CycleStatus.open,
      },
      startDate: _date(cycleRow['start_date']),
      productsInOrder: ids,
      productNames: names,
      initialInventory: initial,
      finalInventory: finalQty,
      initialPrices: prices,
      turns: turns,
      priceChanges: priceChanges,
      nameChanges: nameChanges,
      reportNames: reportNames,
      morningWorkerName: cycleRow['morning_worker_name'] as String,
      nightWorkerName: cycleRow['night_worker_name'] as String,
    );
  }

  Future<ClosePreview> prepareCycleClose(String cycleId, Map<String, ExactDecimal> finalInventory) async {
    final cycle = await getCycleById(cycleId);
    if (cycle == null) throw StateError('No se encontró el ciclo.');
    await setFinalInventory(cycleId, finalInventory);
    final data = await loadCycleData(cycleId);
    if (cycle.kind == CycleKind.inventoryOnly) {
      await database.customStatement('UPDATE cycles SET status=\'pendingClose\' WHERE id=?', [_text(cycleId)]);
      return ClosePreview(cycle: cycle, reportText: null, calculation: null);
    }
    final calculation = CalculationService().calculate(data);
    if (calculation.issues.isNotEmpty) {
      throw StateError(calculation.issues.join('\n'));
    }
    final report = ReportService(CalculationService()).buildFullCycleReport(data, calculation);
    await database.transaction(() async {
      await database.customStatement('UPDATE cycles SET status=\'pendingClose\' WHERE id=?', [_text(cycleId)]);
      final prior = await database.customSelect(
        'SELECT COALESCE(MAX(revision_number),0) AS m FROM cycle_reports WHERE cycle_id=?',
        variables: [_text(cycleId)],
      ).getSingle();
      final revision = (prior.data['m'] as num).toInt() + 1;
      await database.customStatement(
        'INSERT INTO cycle_reports(id,cycle_id,revision_number,report_text,is_final,created_at) VALUES(?,?,?,?,0,?)',
        [_text(_newId('report')), _text(cycleId), _integer(revision), _text(report), _integer(DateTime.now().millisecondsSinceEpoch)],
      );
    });
    return ClosePreview(cycle: cycle, reportText: report, calculation: calculation);
  }

  Future<void> confirmCycleClose(String cycleId) async {
    final cycle = await getCycleById(cycleId);
    if (cycle == null || cycle.status != CycleStatus.pendingClose) {
      throw StateError('El ciclo todavía no está preparado para el cierre.');
    }
    final latestReport = await database.customSelect(
      'SELECT id,revision_number FROM cycle_reports WHERE cycle_id=? ORDER BY revision_number DESC LIMIT 1',
      variables: [_text(cycleId)],
    ).get();
    if (cycle.kind == CycleKind.full && latestReport.isEmpty) {
      throw StateError('Falta generar el borrador del informe antes del cierre.');
    }
    if (cycle.kind == CycleKind.full) {
      final dayThreeTurn = await database.customSelect(
        'SELECT daily_check_in_at,daily_check_in_note FROM turns WHERE cycle_id=? AND turn_index=5',
        variables: [_text(cycleId)],
      ).getSingle();
      if (dayThreeTurn.data['daily_check_in_at'] == null ||
          dayThreeTurn.data['daily_check_in_note'] != 'reviewed') {
        throw StateError('Antes de cerrar, revisa y confirma el check-in nocturno del tercer día.');
      }
      final dayThree = _dayOnly(cycle.startDate.add(const Duration(days: 2)));
      final dailyCopies = await database.customSelect(
        "SELECT file_path FROM backups WHERE backup_kind='daily' AND cycle_id=? AND business_date=? ORDER BY created_at DESC",
        variables: [_text(cycleId), _integer(dayThree.millisecondsSinceEpoch)],
      ).get();
      var hasUsableDailyCopy = false;
      for (final row in dailyCopies) {
        final file = File(row.data['file_path'] as String);
        if (await file.exists() && await file.length() > 0) {
          hasUsableDailyCopy = true;
          break;
        }
      }
      if (!hasUsableDailyCopy) {
        throw StateError('Falta una copia diaria del tercer día accesible y no vacía. No se puede confirmar el cierre.');
      }
    }

    // Prepara todos los datos del siguiente ciclo antes de abrir la transacción.
    // El cierre del actual y la creación del siguiente deben confirmarse juntos:
    // nunca puede quedar la aplicación sin un ciclo activo por un fallo intermedio.
    final finalRows = await database.customSelect(
      'SELECT product_id,final_quantity_coefficient,final_quantity_scale FROM cycle_products WHERE cycle_id=?',
      variables: [_text(cycleId)],
    ).get();
    final finalInventory = <String, ExactDecimal>{};
    for (final row in finalRows) {
      final coefficient = row.data['final_quantity_coefficient'];
      final scale = row.data['final_quantity_scale'];
      if (coefficient == null || scale == null) {
        throw StateError('Falta el inventario final de uno o más productos.');
      }
      final quantity = _decimal(coefficient, scale);
      _validateNonNegative(quantity, 'No se puede cerrar con inventario negativo.');
      finalInventory[row.data['product_id'] as String] = quantity;
    }
    // Una vez que todos los artículos de saldo cero se han retirado, un ciclo
    // puede legítimamente transferir un inventario vacío. Un producto nuevo
    // podrá incorporarse después desde el catálogo.

    final products = await getProducts();
    final config = await getConfiguration();
    final nextKind = cycle.kind == CycleKind.full ? CycleKind.inventoryOnly : CycleKind.full;
    final nextStart = cycle.endDate.add(const Duration(days: 1));
    final reportRevision = latestReport.isEmpty
        ? 0
        : (latestReport.first.data['revision_number'] as num).toInt();
    final nextRevision = reportRevision > cycle.revisionNumber
        ? reportRevision
        : cycle.revisionNumber + 1;

    await database.transaction(() async {
      final now = DateTime.now().millisecondsSinceEpoch;
      await database.customStatement(
        'UPDATE cycles SET status=\'closed\',closed_at=?,revision_number=? WHERE id=?',
        [_integer(now), _integer(nextRevision), _text(cycleId)],
      );
      if (latestReport.isNotEmpty) {
        await database.customStatement(
          'UPDATE cycle_reports SET is_final=1 WHERE id=?',
          [_text(latestReport.first.data['id'] as String)],
        );
      }
      await database.customStatement(
        'INSERT INTO cycle_revisions(id,cycle_id,revision_number,action,changed_at,payload_json) VALUES(?,?,?,?,?,?)',
        [
          _text(_newId('revision')),
          _text(cycleId),
          _integer(nextRevision),
          _text('cycle_closed'),
          _integer(now),
          _text(jsonEncode({'kind': cycle.kind.name, 'nextCycleKind': nextKind.name})),
        ],
      );
      await _insertCycleData(
        sequenceNumber: cycle.sequenceNumber + 1,
        kind: nextKind,
        startDate: nextStart,
        initialInventory: finalInventory,
        products: products,
        previousCycleId: cycleId,
        config: config,
      );
    });
  }

  /// Corrige el inventario final del ciclo exclusivamente de inventario que
  /// suministró el inventario inicial del ciclo completo actual. Solo se
  /// permite como respuesta a un saldo negativo detectado antes de cualquier
  /// corte de precio. El movimiento rechazado no se guarda y debe repetirse.
  Future<void> correctPreviousInventoryCycleForNegativeBalance({
    required NegativeInventoryException incident,
    required ExactDecimal correctedFinalQuantity,
  }) async {
    if (!incident.canCorrectPreviousInventoryCycle || incident.predecessorCycleId == null) {
      throw StateError('Este saldo negativo no puede corregirse reabriendo el ciclo anterior.');
    }
    _validateNonNegative(correctedFinalQuantity, 'El inventario corregido no puede ser negativo.');

    final currentRows = await database.customSelect(
      'SELECT * FROM cycles WHERE id=?',
      variables: [_text(incident.cycleId)],
    ).get();
    if (currentRows.isEmpty) throw StateError('No se encontró el ciclo actual.');
    final current = currentRows.first.data;
    final currentStatus = current['status'] as String;
    if (current['cycle_kind'] != 'full' ||
        (currentStatus != 'open' && currentStatus != 'pendingClose')) {
      throw StateError('La corrección solo se permite desde un ciclo completo que siga editable.');
    }
    if (current['previous_cycle_id'] != incident.predecessorCycleId) {
      throw StateError('El ciclo anterior cambió. Vuelve a revisar el historial.');
    }

    final predecessorRows = await database.customSelect(
      'SELECT * FROM cycles WHERE id=?',
      variables: [_text(incident.predecessorCycleId!)],
    ).get();
    if (predecessorRows.isEmpty) throw StateError('No se encontró el ciclo de inventario anterior.');
    final predecessor = predecessorRows.first.data;
    if (predecessor['cycle_kind'] != 'inventoryOnly' || predecessor['status'] != 'closed') {
      throw StateError('Solo se puede corregir el ciclo cerrado exclusivamente de inventario anterior.');
    }

    final predecessorProductRows = await database.customSelect(
      'SELECT final_quantity_coefficient,final_quantity_scale FROM cycle_products WHERE cycle_id=? AND product_id=?',
      variables: [_text(incident.predecessorCycleId!), _text(incident.productId)],
    ).get();
    final currentProductRows = await database.customSelect(
      'SELECT initial_quantity_coefficient,initial_quantity_scale FROM cycle_products WHERE cycle_id=? AND product_id=?',
      variables: [_text(incident.cycleId), _text(incident.productId)],
    ).get();
    if (predecessorProductRows.isEmpty || currentProductRows.isEmpty) {
      throw StateError('El producto no está presente en los dos ciclos relacionados.');
    }
    final oldFinalCoefficient = predecessorProductRows.first.data['final_quantity_coefficient'];
    final oldFinalScale = predecessorProductRows.first.data['final_quantity_scale'];
    if (oldFinalCoefficient == null || oldFinalScale == null) {
      throw StateError('El ciclo anterior no tiene un inventario final confirmado para este producto.');
    }
    final oldFinal = _decimal(oldFinalCoefficient, oldFinalScale);
    final currentInitial = _decimal(
      currentProductRows.first.data['initial_quantity_coefficient'],
      currentProductRows.first.data['initial_quantity_scale'],
    );
    if (oldFinal.compareTo(currentInitial) != 0) {
      throw StateError('El inventario inicial actual ya no coincide con el final del ciclo anterior. No se modificó nada.');
    }
    if (correctedFinalQuantity.compareTo(incident.minimumPredecessorFinal) < 0) {
      throw StateError(
        'Para evitar el saldo negativo en ${CalculationService.turnLabel(incident.turnIndex)}, '
        'el inventario final corregido debe ser al menos ${incident.minimumPredecessorFinal.toLocalizedString()}.',
      );
    }

    await database.transaction(() async {
      // Se registra explícitamente la reapertura y el nuevo cierre. El estado
      // final del ciclo permanece cerrado: no queda una cadena con dos ciclos
      // abiertos ni se habilita un ciclo nuevo.
      await _appendCycleRevision(
        incident.predecessorCycleId!,
        'historical_cycle_reopened_for_negative_inventory',
        {
          'triggerCycleId': incident.cycleId,
          'productId': incident.productId,
          'productName': incident.productName,
          'turnIndex': incident.turnIndex,
          'shortfall': incident.shortfall.toLocalizedString(),
        },
      );
      await database.customStatement(
        "UPDATE cycles SET status='pendingClose',closed_at=NULL WHERE id=?",
        [_text(incident.predecessorCycleId!)],
      );

      await database.customStatement(
        'UPDATE cycle_products SET final_quantity_coefficient=?,final_quantity_scale=? WHERE cycle_id=? AND product_id=?',
        [
          _text(correctedFinalQuantity.databaseCoefficient),
          _integer(correctedFinalQuantity.scale),
          _text(incident.predecessorCycleId!),
          _text(incident.productId),
        ],
      );

      await database.customStatement(
        "UPDATE cycles SET status='closed',closed_at=? WHERE id=?",
        [_integer(DateTime.now().millisecondsSinceEpoch), _text(incident.predecessorCycleId!)],
      );
      await _appendCycleRevision(
        incident.predecessorCycleId!,
        'historical_cycle_closed_after_inventory_correction',
        {
          'triggerCycleId': incident.cycleId,
          'productId': incident.productId,
          'productName': incident.productName,
          'oldFinal': oldFinal.toLocalizedString(),
          'newFinal': correctedFinalQuantity.toLocalizedString(),
          'turnIndex': incident.turnIndex,
        },
      );

      // Solo se actualiza el inventario inicial heredado del ciclo actual.
      // Su inventario final y los conteos físicos posteriores nunca se tocan.
      await database.customStatement(
        'UPDATE cycle_products SET initial_quantity_coefficient=?,initial_quantity_scale=? WHERE cycle_id=? AND product_id=?',
        [
          _text(correctedFinalQuantity.databaseCoefficient),
          _integer(correctedFinalQuantity.scale),
          _text(incident.cycleId),
          _text(incident.productId),
        ],
      );
      await _appendCycleRevision(
        incident.cycleId,
        'opening_inventory_refreshed_from_predecessor_correction',
        {
          'predecessorCycleId': incident.predecessorCycleId,
          'productId': incident.productId,
          'oldInitial': currentInitial.toLocalizedString(),
          'newInitial': correctedFinalQuantity.toLocalizedString(),
          'reason': 'negative_inventory_prevention',
        },
      );

      // Comprueba que las operaciones ya guardadas siguen siendo válidas con
      // el nuevo inventario inicial. La operación que disparó la alerta fue
      // revertida y debe volver a registrarse manualmente.
      await _assertNoNegativeProductBalance(incident.cycleId, incident.productId);
      if (current['status'] == 'pendingClose') {
        await database.customStatement("UPDATE cycles SET status='open' WHERE id=?", [_text(incident.cycleId)]);
        await _appendCycleRevision(
          incident.cycleId,
          'close_draft_invalidated_by_historical_inventory_correction',
          {
            'predecessorCycleId': incident.predecessorCycleId,
            'productId': incident.productId,
            'reason': 'opening_inventory_changed',
          },
        );
      }
      // La invalidación del check-in forma parte de la misma transacción que
      // cambia los inventarios. Si falla, tampoco se confirma la corrección.
      await _markAllCheckedDaysAsModified(incident.cycleId);
    });
  }

  Future<void> _appendCycleRevision(
    String cycleId,
    String action,
    Map<String, dynamic> payload,
  ) async {
    final rows = await database.customSelect(
      'SELECT revision_number FROM cycles WHERE id=?',
      variables: [_text(cycleId)],
    ).getSingle();
    final existing = (rows.data['revision_number'] as num).toInt();
    final priorRows = await database.customSelect(
      'SELECT COALESCE(MAX(revision_number),0) AS m FROM cycle_revisions WHERE cycle_id=?',
      variables: [_text(cycleId)],
    ).getSingle();
    final next = (priorRows.data['m'] as num).toInt() + 1;
    final revision = next > existing ? next : existing + 1;
    final now = DateTime.now().millisecondsSinceEpoch;
    await database.customStatement(
      'UPDATE cycles SET revision_number=? WHERE id=?',
      [_integer(revision), _text(cycleId)],
    );
    await database.customStatement(
      'INSERT INTO cycle_revisions(id,cycle_id,revision_number,action,changed_at,payload_json) VALUES(?,?,?,?,?,?)',
      [_text(_newId('revision')), _text(cycleId), _integer(revision), _text(action), _integer(now), _text(jsonEncode(payload))],
    );
  }

  Future<String?> getLatestReport(String cycleId) async {
    final rows = await database.customSelect(
      'SELECT report_text FROM cycle_reports WHERE cycle_id=? ORDER BY revision_number DESC LIMIT 1',
      variables: [_text(cycleId)],
    ).get();
    return rows.isEmpty ? null : rows.first.data['report_text'] as String;
  }

  Future<CycleCalculation?> calculateCycle(String cycleId) async {
    final cycle = await loadCycleData(cycleId);
    if (cycle.kind != CycleKind.full) return null;
    return CalculationService().calculate(cycle);
  }

  /// Edición directa de registros. El tipo, producto y turno del movimiento
  /// permanecen estables; se corrigen los valores capturados sin recrear el
  /// movimiento ni cambiar su posición histórica.
  Future<void> updateMovement({
    required String cycleId,
    required String id,
    required int turnIndex,
    required ExactDecimal quantity,
  }) async {
    _validateTurnIndex(turnIndex);
    _validatePositive(quantity, 'La cantidad debe ser mayor que cero.');
    await _requireEditableFullCycle(cycleId);
    final rows = await database.customSelect(
      'SELECT id FROM inventory_movements WHERE id=? AND cycle_id=? AND turn_index=?',
      variables: [_text(id), _text(cycleId), _integer(turnIndex)],
    ).get();
    if (rows.isEmpty) throw StateError('El movimiento ya no existe en este turno.');
    await database.transaction(() async {
      await database.customStatement(
        'UPDATE inventory_movements SET quantity_coefficient=?,quantity_scale=? WHERE id=? AND cycle_id=? AND turn_index=?',
        [_text(quantity.databaseCoefficient), _integer(quantity.scale), _text(id), _text(cycleId), _integer(turnIndex)],
      );
      final details = await database.customSelect(
        'SELECT product_id FROM inventory_movements WHERE id=? AND cycle_id=? AND turn_index=?',
        variables: [_text(id), _text(cycleId), _integer(turnIndex)],
      ).getSingle();
      await _assertNoNegativeProductBalance(cycleId, details.data['product_id'] as String);
    });
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> updateExpense({
    required String cycleId,
    required String id,
    required int turnIndex,
    required String concept,
    required ExactDecimal amount,
  }) async {
    _validateTurnIndex(turnIndex);
    if (concept.trim().isEmpty) throw ArgumentError('Escribe el concepto del gasto.');
    _validateNonNegative(amount, 'El importe del gasto no puede ser negativo.');
    await _requireEditableFullCycle(cycleId);
    final rows = await database.customSelect(
      'SELECT id FROM expenses WHERE id=? AND cycle_id=? AND turn_index=?',
      variables: [_text(id), _text(cycleId), _integer(turnIndex)],
    ).get();
    if (rows.isEmpty) throw StateError('El gasto ya no existe en este turno.');
    await database.customStatement(
      'UPDATE expenses SET concept=?,amount_coefficient=?,amount_scale=? WHERE id=? AND cycle_id=? AND turn_index=?',
      [_text(concept.trim()), _text(amount.databaseCoefficient), _integer(amount.scale), _text(id), _text(cycleId), _integer(turnIndex)],
    );
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> updateReinvestment({
    required String cycleId,
    required String id,
    required int turnIndex,
    required ExactDecimal quantity,
    required ExactDecimal amount,
  }) async {
    _validateTurnIndex(turnIndex);
    _validatePositive(quantity, 'La cantidad comprada debe ser mayor que cero.');
    _validateNonNegative(amount, 'El importe invertido no puede ser negativo.');
    await _requireEditableFullCycle(cycleId);
    final rows = await database.customSelect(
      'SELECT id FROM reinvestments WHERE id=? AND cycle_id=? AND turn_index=?',
      variables: [_text(id), _text(cycleId), _integer(turnIndex)],
    ).get();
    if (rows.isEmpty) throw StateError('La reinversión ya no existe en este turno.');
    await database.transaction(() async {
      await database.customStatement(
        'UPDATE reinvestments SET quantity_coefficient=?,quantity_scale=?,amount_coefficient=?,amount_scale=? WHERE id=? AND cycle_id=? AND turn_index=?',
        [_text(quantity.databaseCoefficient), _integer(quantity.scale), _text(amount.databaseCoefficient), _integer(amount.scale), _text(id), _text(cycleId), _integer(turnIndex)],
      );
      final details = await database.customSelect(
        'SELECT product_id FROM reinvestments WHERE id=? AND cycle_id=? AND turn_index=?',
        variables: [_text(id), _text(cycleId), _integer(turnIndex)],
      ).getSingle();
      await _assertNoNegativeProductBalance(cycleId, details.data['product_id'] as String);
    });
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> updatePriceChange({
    required String cycleId,
    required String id,
    required int turnIndex,
    required ExactDecimal newPrice,
    required ExactDecimal balanceAtTurnStart,
  }) async {
    _validateTurnIndex(turnIndex);
    _validateNonNegative(newPrice, 'El precio nuevo no puede ser negativo.');
    _validateNonNegative(balanceAtTurnStart, 'El saldo no puede ser negativo.');
    await _requireEditableFullCycle(cycleId);
    final rows = await database.customSelect(
      'SELECT product_id FROM price_changes WHERE id=? AND cycle_id=? AND turn_index=?',
      variables: [_text(id), _text(cycleId), _integer(turnIndex)],
    ).get();
    if (rows.isEmpty) throw StateError('El cambio de precio ya no existe en este turno.');
    final productId = rows.first.data['product_id'] as String;
    await database.transaction(() async {
      await database.customStatement(
        'UPDATE price_changes SET new_price_coefficient=?,new_price_scale=?,balance_coefficient=?,balance_scale=? WHERE id=? AND cycle_id=? AND turn_index=?',
        [_text(newPrice.databaseCoefficient), _integer(newPrice.scale), _text(balanceAtTurnStart.databaseCoefficient), _integer(balanceAtTurnStart.scale), _text(id), _text(cycleId), _integer(turnIndex)],
      );
      await _rebuildPriceHistory(cycleId, productId);
      await _assertNoNegativeProductBalance(cycleId, productId);
    });
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> deleteTurnRecord({required String table, required String id, required String cycleId}) async {
    const allowed = {'inventory_movements', 'expenses', 'reinvestments', 'price_changes'};
    if (!allowed.contains(table)) throw ArgumentError('Tipo de registro no permitido.');
    await _requireEditableFullCycle(cycleId);
    final turnRows = table == 'expenses'
        ? await database.customSelect(
            'SELECT turn_index, NULL AS product_id FROM expenses WHERE id=? AND cycle_id=?',
            variables: [_text(id), _text(cycleId)],
          ).get()
        : await database.customSelect(
            'SELECT turn_index,product_id FROM $table WHERE id=? AND cycle_id=?',
            variables: [_text(id), _text(cycleId)],
          ).get();
    if (turnRows.isEmpty) throw StateError('El registro ya no existe.');
    final turnIndex = (turnRows.first.data['turn_index'] as num).toInt();
    final productId = turnRows.first.data['product_id'] as String?;
    await database.transaction(() async {
      await database.customStatement('DELETE FROM $table WHERE id=? AND cycle_id=?', [_text(id), _text(cycleId)]);
      if (table == 'price_changes') await _refreshCurrentPrice(cycleId);
      if (productId != null && (table == 'inventory_movements' || table == 'reinvestments' || table == 'price_changes')) {
        await _assertNoNegativeProductBalance(cycleId, productId);
      }
    });
    await _markCycleAsModified(cycleId, turnIndex);
  }

  Future<void> _refreshCurrentPrice(String cycleId) async {
    final rows = await database.customSelect('SELECT product_id,initial_price_coefficient,initial_price_scale FROM cycle_products WHERE cycle_id=?', variables: [_text(cycleId)]).get();
    for (final row in rows) {
      final id = row.data['product_id'] as String;
      final changes = await database.customSelect(
        'SELECT new_price_coefficient,new_price_scale FROM price_changes WHERE cycle_id=? AND product_id=? ORDER BY turn_index DESC LIMIT 1',
        variables: [_text(cycleId), _text(id)],
      ).get();
      final coefficient = changes.isEmpty ? row.data['initial_price_coefficient'] : changes.first.data['new_price_coefficient'];
      final scale = changes.isEmpty ? row.data['initial_price_scale'] : changes.first.data['new_price_scale'];
      await database.customStatement(
        'UPDATE products SET current_price_coefficient=?,current_price_scale=?,updated_at=? WHERE id=?',
        [_text(coefficient as String), _integer((scale as num).toInt()), _integer(DateTime.now().millisecondsSinceEpoch), _text(id)],
      );
    }
  }

  Future<void> _requireEditableFullCycle(String cycleId) async {
    final cycle = await getCycleById(cycleId);
    if (cycle == null) throw StateError('No se encontró el ciclo.');
    if (cycle.kind != CycleKind.full) throw StateError('Este ciclo solo permite registrar inventarios finales.');
    if (cycle.status == CycleStatus.closed) throw StateError('El ciclo está cerrado.');
  }

  /// Recorre el saldo conocido del producto a lo largo de los seis turnos.
  /// Un cambio de precio introduce un punto de corte: el saldo declarado no
  /// puede superar lo que razonablemente había disponible; la diferencia
  /// puede representar ventas anteriores al corte. Después se aplican todas
  /// las entradas, reinversiones y bajas del turno. No se usan horas.
  Future<void> _assertNoNegativeProductBalance(String cycleId, String productId) async {
    final openingRows = await database.customSelect(
      'SELECT initial_quantity_coefficient,initial_quantity_scale,product_name_snapshot FROM cycle_products WHERE cycle_id=? AND product_id=?',
      variables: [_text(cycleId), _text(productId)],
    ).get();
    if (openingRows.isEmpty) throw StateError('No existe inventario inicial para este producto.');
    final opening = openingRows.first.data;
    final name = opening['product_name_snapshot'] as String;
    var balance = _decimal(opening['initial_quantity_coefficient'], opening['initial_quantity_scale']);
    var priceCutAlreadyApplied = false;

    for (var turnIndex = 0; turnIndex < 6; turnIndex++) {
      final checkpointRows = await database.customSelect(
        'SELECT balance_coefficient,balance_scale FROM price_changes WHERE cycle_id=? AND product_id=? AND turn_index=?',
        variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
      ).get();
      if (checkpointRows.isNotEmpty) {
        final checkpoint = _decimal(
          checkpointRows.first.data['balance_coefficient'],
          checkpointRows.first.data['balance_scale'],
        );
        if (checkpoint.compareTo(balance) > 0) {
          throw StateError(
            'El saldo declarado para $name al cambiar el precio supera las existencias disponibles al inicio de ${CalculationService.turnLabel(turnIndex)}. Revisa entradas y bajas anteriores.',
          );
        }
        balance = checkpoint;
        priceCutAlreadyApplied = true;
      }

      final movementRows = await database.customSelect(
        'SELECT movement_kind,quantity_coefficient,quantity_scale FROM inventory_movements WHERE cycle_id=? AND product_id=? AND turn_index=?',
        variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
      ).get();
      var entries = ExactDecimal.zero();
      var losses = ExactDecimal.zero();
      for (final row in movementRows) {
        final quantity = _decimal(row.data['quantity_coefficient'], row.data['quantity_scale']);
        if (row.data['movement_kind'] == 'entry') {
          entries = entries + quantity;
        } else {
          losses = losses + quantity;
        }
      }
      final reinvestments = await database.customSelect(
        'SELECT quantity_coefficient,quantity_scale FROM reinvestments WHERE cycle_id=? AND product_id=? AND turn_index=?',
        variables: [_text(cycleId), _text(productId), _integer(turnIndex)],
      ).get();
      for (final row in reinvestments) {
        entries = entries + _decimal(row.data['quantity_coefficient'], row.data['quantity_scale']);
      }
      balance = balance + entries - losses;
      if (balance.isNegative) {
        final shortfall = ExactDecimal.zero() - balance;
        final cycleMetaRows = await database.customSelect(
          'SELECT previous_cycle_id FROM cycles WHERE id=?',
          variables: [_text(cycleId)],
        ).get();
        final predecessorId = cycleMetaRows.isEmpty ? null : cycleMetaRows.first.data['previous_cycle_id'] as String?;
        var canCorrectPreviousCycle = false;
        if (!priceCutAlreadyApplied && predecessorId != null) {
          final predecessorRows = await database.customSelect(
            'SELECT cycle_kind,status FROM cycles WHERE id=?',
            variables: [_text(predecessorId)],
          ).get();
          canCorrectPreviousCycle = predecessorRows.isNotEmpty &&
              predecessorRows.first.data['cycle_kind'] == 'inventoryOnly' &&
              predecessorRows.first.data['status'] == 'closed';
        }
        final openingQuantity = _decimal(
          opening['initial_quantity_coefficient'],
          opening['initial_quantity_scale'],
        );
        throw NegativeInventoryException(
          cycleId: cycleId,
          productId: productId,
          productName: name,
          turnIndex: turnIndex,
          shortfall: shortfall,
          minimumPredecessorFinal: openingQuantity + shortfall,
          canCorrectPreviousInventoryCycle: canCorrectPreviousCycle,
          hasPriorPriceCut: priceCutAlreadyApplied,
          predecessorCycleId: canCorrectPreviousCycle ? predecessorId : null,
        );
      }
    }
  }

  void _validateTurnIndex(int value) {
    if (value < 0 || value > 5) throw ArgumentError('El turno debe estar entre 0 y 5.');
  }

  void _validateNonNegative(ExactDecimal value, String message) {
    if (value.isNegative) throw ArgumentError(message);
  }

  void _validatePositive(ExactDecimal value, String message) {
    if (value.isNegative || value.isZero) throw ArgumentError(message);
  }
}

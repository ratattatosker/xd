PRAGMA foreign_keys = ON;

-- Esquema de referencia equivalente a las tablas Drift de app_database.dart.
-- Las fechas se guardan como milisegundos Unix (INTEGER), igual que Drift.

CREATE TABLE IF NOT EXISTS products (
  id TEXT NOT NULL PRIMARY KEY,
  current_name TEXT NOT NULL,
  current_price_coefficient TEXT NOT NULL DEFAULT '0',
  current_price_scale INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS cycles (
  id TEXT NOT NULL PRIMARY KEY,
  sequence_number INTEGER NOT NULL UNIQUE,
  cycle_kind TEXT NOT NULL CHECK (cycle_kind IN ('full','inventoryOnly')),
  status TEXT NOT NULL CHECK (status IN ('open','pendingClose','closed')),
  start_date INTEGER NOT NULL,
  end_date INTEGER NOT NULL,
  previous_cycle_id TEXT REFERENCES cycles(id),
  revision_number INTEGER NOT NULL DEFAULT 0,
  report_names_json TEXT NOT NULL DEFAULT '[]',
  morning_worker_name TEXT NOT NULL DEFAULT 'Matutino',
  night_worker_name TEXT NOT NULL DEFAULT 'Nocturno',
  created_at INTEGER NOT NULL,
  closed_at INTEGER
);

CREATE TABLE IF NOT EXISTS cycle_products (
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  product_id TEXT NOT NULL REFERENCES products(id),
  product_name_snapshot TEXT NOT NULL,
  sort_order_snapshot INTEGER NOT NULL,
  initial_quantity_coefficient TEXT NOT NULL,
  initial_quantity_scale INTEGER NOT NULL,
  final_quantity_coefficient TEXT,
  final_quantity_scale INTEGER,
  initial_price_coefficient TEXT NOT NULL,
  initial_price_scale INTEGER NOT NULL,
  PRIMARY KEY (cycle_id, product_id)
);

CREATE TABLE IF NOT EXISTS turns (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL CHECK (turn_index BETWEEN 0 AND 5),
  cash_coefficient TEXT NOT NULL DEFAULT '0',
  cash_scale INTEGER NOT NULL DEFAULT 0,
  daily_check_in_at INTEGER,
  daily_check_in_note TEXT,
  UNIQUE (cycle_id, turn_index)
);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL,
  turn_index INTEGER NOT NULL CHECK (turn_index BETWEEN 0 AND 5),
  product_id TEXT NOT NULL,
  product_name_snapshot TEXT NOT NULL,
  movement_kind TEXT NOT NULL CHECK (movement_kind IN ('entry','loss')),
  quantity_coefficient TEXT NOT NULL,
  quantity_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (cycle_id, product_id) REFERENCES cycle_products(cycle_id, product_id)
);

CREATE TABLE IF NOT EXISTS expenses (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL CHECK (turn_index BETWEEN 0 AND 5),
  concept TEXT NOT NULL,
  amount_coefficient TEXT NOT NULL,
  amount_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reinvestments (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL,
  turn_index INTEGER NOT NULL CHECK (turn_index BETWEEN 0 AND 5),
  product_id TEXT NOT NULL,
  product_name_snapshot TEXT NOT NULL,
  quantity_coefficient TEXT NOT NULL,
  quantity_scale INTEGER NOT NULL,
  amount_coefficient TEXT NOT NULL,
  amount_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (cycle_id, product_id) REFERENCES cycle_products(cycle_id, product_id)
);

CREATE TABLE IF NOT EXISTS product_name_changes (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  turn_index INTEGER NOT NULL CHECK (turn_index BETWEEN 0 AND 5),
  product_id TEXT NOT NULL REFERENCES products(id),
  old_name TEXT NOT NULL,
  new_name TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS price_changes (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL,
  turn_index INTEGER NOT NULL CHECK (turn_index BETWEEN 0 AND 5),
  day_index INTEGER NOT NULL CHECK (day_index BETWEEN 0 AND 2),
  product_id TEXT NOT NULL,
  product_name_snapshot TEXT NOT NULL,
  old_price_coefficient TEXT NOT NULL,
  old_price_scale INTEGER NOT NULL,
  new_price_coefficient TEXT NOT NULL,
  new_price_scale INTEGER NOT NULL,
  balance_coefficient TEXT NOT NULL,
  balance_scale INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (cycle_id, product_id) REFERENCES cycle_products(cycle_id, product_id),
  UNIQUE (cycle_id, product_id, day_index)
);

CREATE TABLE IF NOT EXISTS cycle_revisions (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  revision_number INTEGER NOT NULL,
  action TEXT NOT NULL,
  changed_at INTEGER NOT NULL,
  payload_json TEXT NOT NULL,
  UNIQUE (cycle_id, revision_number)
);

CREATE TABLE IF NOT EXISTS cycle_reports (
  id TEXT NOT NULL PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES cycles(id),
  revision_number INTEGER NOT NULL,
  report_text TEXT NOT NULL,
  is_final INTEGER NOT NULL DEFAULT 0 CHECK (is_final IN (0,1)),
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS backups (
  id TEXT NOT NULL PRIMARY KEY,
  backup_kind TEXT NOT NULL CHECK (backup_kind IN ('daily','cycleClose','manual','preRestore')),
  cycle_id TEXT,
  business_date INTEGER,
  file_path TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  is_exported INTEGER NOT NULL DEFAULT 0 CHECK (is_exported IN (0,1))
);

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key TEXT NOT NULL PRIMARY KEY,
  setting_value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cycles_dates ON cycles(start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_movements_cycle_turn ON inventory_movements(cycle_id, turn_index);
CREATE INDEX IF NOT EXISTS idx_expenses_cycle_turn ON expenses(cycle_id, turn_index);
CREATE INDEX IF NOT EXISTS idx_reinvestments_cycle_turn ON reinvestments(cycle_id, turn_index);
CREATE INDEX IF NOT EXISTS idx_price_changes_cycle_product_turn ON price_changes(cycle_id, product_id, turn_index);

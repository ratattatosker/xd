# Registro de cambios

## v0.9.1+10

- Corrección de borrado de gastos: la consulta de metadatos usa la estructura real de `expenses` y no intenta leer una columna `product_id` inexistente.
- El check-in nocturno del Día 3 utiliza `COALESCE` para tratar correctamente un catálogo vacío.
- Se bloquea el cierre completo cuando no se pudo crear la copia diaria del Día 3. El repositorio exige check-in vigente y comprueba que exista un archivo de copia diaria accesible y no vacío antes de cerrar, aunque se invoque fuera de la pantalla de cierre.
- Las operaciones de inventario, reinversiones y cambios de precio resuelven el nombre del producto según el turno efectivo. Las renombradas retroactivas reconstruyen el historial y las instantáneas por turno sin sobrescribir renombradas posteriores.
- La restauración valida claves foráneas en la base adjunta antes de cualquier sustitución y solo genera la copia preventiva cuando el archivo entrante ya superó las validaciones.
- La secuencia de ciclos y la propagación histórica aceptan mapas de inventario final vacíos para ciclos cerrados.
- Se amplían las comprobaciones independientes Python/SQLite de 29 a 35.
- Sigue pendiente ejecutar `flutter pub get`, `build_runner`, `dart format`, `flutter analyze`, `dart test` y `flutter build apk` en el PC del usuario.

# Registro de cambios

## v0.9.0+9

- La restauración de respaldos verifica `PRAGMA integrity_check` antes de modificar la base local. También comprueba versión de esquema, tablas obligatorias y claves foráneas.
- Se encapsulan las comprobaciones del archivo de respaldo en `BackupValidationService`, con pruebas unitarias para bases corruptas, versiones incompatibles, tablas faltantes y referencias inválidas.
- Cambiar el inventario final invalida, dentro de la misma transacción, el borrador de cierre si existe y el check-in nocturno si había sido realizado. Los ceros finales de los decimales se consideran parte del dato introducido.
- La corrección histórica marca los check-ins como modificados dentro de la transacción de corrección del inventario heredado.
- El historial presenta un texto legible para la invalidación del borrador por cambio del inventario final.
- Se añadieron tres verificaciones independientes de restauración íntegra, invalidación atómica del inventario final y check-ins históricos.

# Registro de cambios

## v0.8.0+8

- Cierre de ciclo + creación del siguiente ciclo dentro de una única transacción SQLite.
- Validación de inventario para retirar productos del catálogo activo: solo se permite saldo conocido exactamente cero.
- La verificación de saldo y la retirada se confirman en una sola transacción SQLite.
- El ciclo puede continuar aunque todos los productos de saldo cero se retiren; no se impone un producto activo obligatorio.
- El saldo calculado para retirada considera el inventario inicial, cortes de precio, entradas, reinversiones y bajas.
- Servicio de dominio `CatalogPolicy` con pruebas para saldo cero y positivo.
- Tres verificaciones independientes adicionales: atomicidad del cierre con rollback simulado, retirada segura y continuidad con un ciclo vacío.

## v0.7.0+7

- Check-in del tercer día y copia diaria comprobados antes del cierre completo.
- No se generan copias automáticas en ciclos exclusivamente de inventario.
- Revisión del PDF de la Biblia y correcciones de maquetación.

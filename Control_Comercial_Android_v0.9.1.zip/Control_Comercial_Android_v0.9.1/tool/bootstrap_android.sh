#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
BUILD_APK=0
for arg in "$@"; do
  case "$arg" in
    --build-apk) BUILD_APK=1 ;;
    *) echo "Opción desconocida: $arg" >&2; exit 2 ;;
  esac
done
trap 'rm -rf "$TEMP_DIR"' EXIT

if ! command -v flutter >/dev/null 2>&1; then
  echo "No se encontró Flutter. Instala Flutter 3.47.9 stable y vuelve a ejecutar este script." >&2
  exit 1
fi
if ! command -v dart >/dev/null 2>&1; then
  echo "No se encontró Dart. Debe instalarse junto con Flutter." >&2
  exit 1
fi

FLUTTER_VERSION="$(flutter --version | head -n 1)"
echo "Usando: $FLUTTER_VERSION"
echo "Generando la plataforma Android..."
flutter create --platforms=android --org=com.controlcomercial --project-name=control_comercial "$TEMP_DIR/host"
rm -rf "$APP_DIR/android"
cp -R "$TEMP_DIR/host/android" "$APP_DIR/android"
cp "$TEMP_DIR/host/.metadata" "$APP_DIR/.metadata"

cd "$APP_DIR"
echo "Instalando dependencias Flutter..."
flutter pub get
echo "Generando adaptadores de Drift..."
dart run build_runner build --delete-conflicting-outputs
echo "Ejecutando análisis estático..."
flutter analyze

echo "Ejecutando pruebas del motor comercial..."
(cd packages/business_core && dart pub get && dart test)

if [[ "$BUILD_APK" -eq 1 ]]; then
  echo "Compilando APK de producción..."
  flutter build apk --release
  echo "APK generado en: $APP_DIR/build/app/outputs/flutter-apk/app-release.apk"
else
  echo "Plataforma Android generada y comprobaciones terminadas."
  echo "Para generar el APK: flutter build apk --release"
fi

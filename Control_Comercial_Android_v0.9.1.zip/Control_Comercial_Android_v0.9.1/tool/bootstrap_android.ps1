[CmdletBinding()]
param(
    [switch]$BuildApk,
    [switch]$SkipAndroidPlatformGeneration
)

$ErrorActionPreference = 'Stop'
$AppDir = Split-Path -Parent $PSScriptRoot
$TempDir = Join-Path $env:TEMP ("control-comercial-android-" + [guid]::NewGuid().ToString('N'))

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)][string]$Executable,
        [Parameter(Mandatory = $true)][string[]]$CommandArgs,
        [Parameter(Mandatory = $true)][string]$Step
    )
    Write-Host "`n== $Step ==" -ForegroundColor Cyan
    & $Executable @CommandArgs
    if ($LASTEXITCODE -ne 0) {
        throw "Falló: $Step (código $LASTEXITCODE). Revisa el error anterior."
    }
}

try {
    $FlutterCommand = Get-Command flutter -ErrorAction SilentlyContinue
    $DartCommand = Get-Command dart -ErrorAction SilentlyContinue
    $JavaCommand = Get-Command java -ErrorAction SilentlyContinue

    if ($null -eq $FlutterCommand) {
        throw 'No se encontró Flutter en PATH. Abre una terminal nueva y comprueba `flutter --version`.'
    }
    if ($null -eq $DartCommand) {
        throw 'No se encontró Dart. Instala Flutter correctamente: Dart viene incluido con Flutter.'
    }
    if ($null -eq $JavaCommand) {
        throw 'No se encontró Java. Instala un JDK compatible con Android Gradle y configura JAVA_HOME/PATH.'
    }

    $SdkRoot = $env:ANDROID_SDK_ROOT
    if ([string]::IsNullOrWhiteSpace($SdkRoot)) { $SdkRoot = $env:ANDROID_HOME }
    if ([string]::IsNullOrWhiteSpace($SdkRoot)) {
        $DefaultSdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
        if (Test-Path $DefaultSdk) { $SdkRoot = $DefaultSdk }
    }
    if ([string]::IsNullOrWhiteSpace($SdkRoot) -or -not (Test-Path $SdkRoot)) {
        throw @'
No se encontró Android SDK. Visual Studio no lo instala automáticamente.
Puedes instalar el Android SDK Command-line Tools (sin Android Studio), crear una carpeta como C:\Android\cmdline-tools\latest\bin\sdkmanager.bat,
y definir ANDROID_SDK_ROOT=C:\Android. Consulta la sección «Preparar Android SDK en Windows» del README.
'@
    }

    $SdkRoot = (Resolve-Path $SdkRoot).Path
    $env:ANDROID_SDK_ROOT = $SdkRoot
    $env:ANDROID_HOME = $SdkRoot

    $SdkManager = Join-Path $SdkRoot 'cmdline-tools\latest\bin\sdkmanager.bat'
    if (-not (Test-Path $SdkManager)) {
        $SdkToolsDir = Join-Path $SdkRoot 'cmdline-tools'
        if (Test-Path $SdkToolsDir) {
            $SdkManagerCandidate = Get-ChildItem $SdkToolsDir -Filter 'sdkmanager.bat' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($null -ne $SdkManagerCandidate) { $SdkManager = $SdkManagerCandidate.FullName }
        }
    }
    if (-not (Test-Path $SdkManager)) {
        throw "No se encontró sdkmanager.bat dentro de '$SdkRoot\cmdline-tools'. Descarga Android SDK Command-line Tools y sigue el README."
    }

    Write-Host 'Flutter:' -ForegroundColor Green
    Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @('--version') -Step 'Comprobar Flutter'
    Invoke-Checked -Executable $DartCommand.Source -CommandArgs @('--version') -Step 'Comprobar Dart'
    Invoke-Checked -Executable $JavaCommand.Source -CommandArgs @('-version') -Step 'Comprobar Java/JDK'

    Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @('config', '--android-sdk', $SdkRoot) -Step 'Configurar ruta del Android SDK'

    $SdkPackages = @(
        "--sdk_root=$SdkRoot",
        'platform-tools',
        'platforms;android-36',
        'build-tools;36.0.0'
    )
    Invoke-Checked -Executable $SdkManager -CommandArgs $SdkPackages -Step 'Instalar componentes Android necesarios'
    Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @('doctor', '--android-licenses') -Step 'Aceptar licencias Android'
    Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @('doctor', '-v') -Step 'Verificar herramientas Android'

    if (-not $SkipAndroidPlatformGeneration) {
        New-Item -ItemType Directory -Path $TempDir -Force | Out-Null
        $HostProject = Join-Path $TempDir 'host'
        Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @(
            'create', '--platforms=android', '--org=com.controlcomercial',
            '--project-name=control_comercial', $HostProject
        ) -Step 'Generar estructura Android de Flutter'

        $TargetAndroid = Join-Path $AppDir 'android'
        if (Test-Path $TargetAndroid) { Remove-Item $TargetAndroid -Recurse -Force }
        Copy-Item (Join-Path $HostProject 'android') $TargetAndroid -Recurse -Force
        $Metadata = Join-Path $HostProject '.metadata'
        if (Test-Path $Metadata) { Copy-Item $Metadata (Join-Path $AppDir '.metadata') -Force }
    }

    Push-Location $AppDir
    try {
        Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @('pub', 'get') -Step 'Instalar dependencias Flutter'
        Invoke-Checked -Executable $DartCommand.Source -CommandArgs @('run', 'build_runner', 'build', '--delete-conflicting-outputs') -Step 'Generar adaptadores SQLite/Drift'
        Invoke-Checked -Executable $DartCommand.Source -CommandArgs @('format', 'lib', 'packages\business_core\lib', 'packages\business_core\test') -Step 'Formatear código Dart'
        Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @('analyze') -Step 'Analizar el proyecto'

        Push-Location (Join-Path $AppDir 'packages\business_core')
        try {
            Invoke-Checked -Executable $DartCommand.Source -CommandArgs @('pub', 'get') -Step 'Instalar dependencias del motor comercial'
            Invoke-Checked -Executable $DartCommand.Source -CommandArgs @('test') -Step 'Ejecutar pruebas Dart del motor comercial'
        }
        finally {
            Pop-Location
        }

        if ($BuildApk) {
            Invoke-Checked -Executable $FlutterCommand.Source -CommandArgs @('build', 'apk', '--release') -Step 'Compilar APK de producción'
            $ApkPath = Join-Path $AppDir 'build\app\outputs\flutter-apk\app-release.apk'
            if (-not (Test-Path $ApkPath)) { throw 'Flutter terminó pero no se encontró el APK esperado.' }
            Write-Host "`nAPK creado correctamente: $ApkPath" -ForegroundColor Green
        }
        else {
            Write-Host "`nPreparación terminada. Para compilar el APK ejecuta: flutter build apk --release" -ForegroundColor Green
        }
    }
    finally {
        Pop-Location
    }
}
finally {
    if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue }
}

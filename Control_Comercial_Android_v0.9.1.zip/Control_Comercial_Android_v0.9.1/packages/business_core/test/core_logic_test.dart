import 'package:test/test.dart';

import 'package:business_core/domain/exact_decimal.dart';
import 'package:business_core/domain/models.dart';
import 'package:business_core/services/calculation_service.dart';
import 'package:business_core/services/cycle_sequence_service.dart';
import 'package:business_core/services/backup_policy.dart';
import 'package:business_core/services/backup_validation_service.dart';
import 'package:business_core/services/report_service.dart';
import 'package:business_core/services/cycle_lifecycle_service.dart';
import 'package:business_core/services/reopening_service.dart';
import 'package:business_core/services/catalog_policy.dart';

ExactDecimal d(String value) => ExactDecimal.parse(value);

CycleData sampleCycle({List<PriceChange>? changes}) {
  final turns = List<TurnData>.generate(
    6,
    (index) => TurnData(index: index, cashCollected: d('0')),
  );
  turns[0] = TurnData(
    index: 0,
    cashCollected: d('1000,00'),
    expenses: [
      ExpenseEntry(concept: 'Pago de Frank', amount: d('3000'), turnIndex: 0),
      ExpenseEntry(concept: 'Manuel', amount: d('500'), turnIndex: 0),
    ],
  );
  turns[1] = TurnData(
    index: 1,
    cashCollected: d('500'),
    expenses: [
      ExpenseEntry(concept: 'pago de frank', amount: d('2600'), turnIndex: 1),
    ],
  );
  turns[2] = TurnData(
    index: 2,
    cashCollected: d('200'),
    movements: [
      InventoryMovement(
        productId: 'p1',
        productNameSnapshot: 'Pastel',
        quantity: d('5,00'),
        kind: MovementKind.entry,
        turnIndex: 2,
      ),
      InventoryMovement(
        productId: 'p1',
        productNameSnapshot: 'Pastel',
        quantity: d('1'),
        kind: MovementKind.loss,
        turnIndex: 2,
      ),
    ],
    reinvestments: [
      ReinvestmentEntry(
        productId: 'p1',
        productNameSnapshot: 'Pastel',
        quantity: d('2'),
        amount: d('200'),
        turnIndex: 2,
      ),
    ],
  );
  turns[4] = TurnData(
    index: 4,
    cashCollected: d('100'),
    expenses: [ExpenseEntry(concept: 'PAGO DE FRANK', amount: d('400'), turnIndex: 4)],
  );
  turns[5] = TurnData(
    index: 5,
    cashCollected: d('100'),
    expenses: [ExpenseEntry(concept: 'manuel', amount: d('500'), turnIndex: 5)],
  );

  return CycleData(
    id: 'cycle-1',
    kind: CycleKind.full,
    status: CycleStatus.open,
    startDate: DateTime(2026, 11, 11),
    productsInOrder: const ['p1'],
    productNames: const {'p1': 'Pastel'},
    initialInventory: {'p1': d('10')},
    finalInventory: {'p1': d('10')},
    initialPrices: {'p1': d('100')},
    turns: turns,
    priceChanges: changes ?? [
      PriceChange(
        productId: 'p1',
        productNameSnapshot: 'Pastel',
        turnIndex: 2,
        oldPrice: d('100'),
        newPrice: d('200'),
        balanceAtTurnStart: d('8'),
      ),
    ],
    reportNames: const ['Mario', 'Isabel'],
    morningWorkerName: 'Mario',
    nightWorkerName: 'Isabel',
  );
}

void main() {
  group('ExactDecimal', () {
    test('preserva los ceros decimales finales', () {
      expect(d('1,30').toLocalizedString(), '1,30');
      expect(d('1.30').toLocalizedString(), '1,30');
    });

    test('suma y multiplica sin coma flotante', () {
      expect((d('0,10') + d('0,20')).toLocalizedString(), '0,30');
      expect((d('1,20') * d('2,5')).toLocalizedString(), '3,000');
    });
  });

  group('CalculationService', () {
    test('infiere unidades y valora por períodos de precio', () {
      final result = CalculationService().calculate(sampleCycle());
      final sales = result.productSales['p1']!;
      expect(sales.totalUnitsSold.toLocalizedString(), '6');
      expect(sales.periods[0].unitsSold.toLocalizedString(), '2');
      expect(sales.periods[0].estimatedRevenue.toLocalizedString(), '200');
      expect(sales.periods[1].unitsSold.toLocalizedString(), '4');
      expect(sales.periods[1].estimatedRevenue.toLocalizedString(), '800');
      expect(sales.estimatedRevenue.toLocalizedString(), '1 000');
    });

    test('suma el Dinero de Venta y calcula salarios independientes', () {
      final result = CalculationService().calculate(sampleCycle());
      expect(result.turnMoneyOfSale[0]!.toLocalizedString(), '4 500,00');
      expect(result.salarySummary.morningSalary.toLocalizedString(), '270,0000');
      expect(result.salarySummary.nightSalary.toLocalizedString(), '185,00');
    });

    test('agrupa gastos sin distinguir mayúsculas y conserva la primera escritura', () {
      final result = CalculationService().calculate(sampleCycle());
      expect(result.expensesByConcept.length, 2);
      expect(result.expensesByConcept[0].firstWrittenConcept, 'Pago de Frank');
      expect(result.expensesByConcept[0].amount.toLocalizedString(), '6 000');
      expect(result.expensesByConcept[1].firstWrittenConcept, 'Manuel');
      expect(result.expensesByConcept[1].amount.toLocalizedString(), '1 000');
    });

    test('conserva el nombre antiguo en movimientos y utiliza el nuevo en Finales', () {
      final cycle = sampleCycle().copyWith(nameChanges: [
        ProductNameChange(
          productId: 'p1',
          turnIndex: 4,
          oldName: 'Pastel',
          newName: 'Pastel Premium',
        ),
      ]);
      final calculations = CalculationService().calculate(cycle);
      final report = ReportService(CalculationService()).buildFullCycleReport(cycle, calculations);
      expect(report.contains('5,00 Pastel'), isTrue);
      expect(report.contains('Pastel Premium - 10'), isTrue);
    });

    test('un cambio nocturno comienza en el turno nocturno y no afecta al matutino', () {
      final base = sampleCycle();
      final nightChange = PriceChange(
        productId: 'p1',
        productNameSnapshot: 'Pastel',
        turnIndex: 1,
        oldPrice: d('100'),
        newPrice: d('150'),
        balanceAtTurnStart: d('9'),
      );
      final cycle = base.copyWith(nameChanges: const []);
      final eventCycle = CycleData(
        id: cycle.id,
        kind: cycle.kind,
        status: cycle.status,
        startDate: cycle.startDate,
        productsInOrder: cycle.productsInOrder,
        productNames: cycle.productNames,
        initialInventory: cycle.initialInventory,
        initialPrices: cycle.initialPrices,
        finalInventory: cycle.finalInventory,
        turns: cycle.turns,
        priceChanges: [nightChange],
      );
      final result = CalculationService().calculate(eventCycle);
      final product = result.productSales['p1']!;
      expect(product.periods.first.fromTurnIndex, 0);
      expect(product.periods.first.toTurnIndexExclusive, 1);
      expect(product.periods.last.fromTurnIndex, 1);
    });

    test('rechaza dos cambios del mismo producto en un mismo día', () {
      final base = sampleCycle();
      final invalid = sampleCycle(changes: [
        base.priceChanges.first,
        PriceChange(
          productId: 'p1',
          productNameSnapshot: 'Pastel',
          turnIndex: 3,
          oldPrice: d('200'),
          newPrice: d('220'),
          balanceAtTurnStart: d('8'),
        ),
      ]);
      final result = CalculationService().calculate(invalid);
      expect(result.issues.any((issue) => issue.contains('dos veces en el mismo día')), isTrue);
    });
  });

  group('BackupValidationService', () {
    final validation = BackupValidationService();

    test('acepta solo una comprobación SQLite íntegra con resultado ok', () {
      expect(() => validation.validateIntegrityMessages(['ok']), returnsNormally);
      expect(() => validation.validateIntegrityMessages(['ok', 'extra']), throwsStateError);
      expect(() => validation.validateIntegrityMessages(['*** in database main ***']), throwsStateError);
    });

    test('rechaza una versión o tablas obligatorias incompatibles', () {
      expect(() => validation.validateSchemaVersion(incoming: 1, expected: 2), throwsStateError);
      expect(() => validation.validateSchemaVersion(incoming: 2, expected: 2), returnsNormally);
      expect(() => validation.validateTables({'products', 'cycles'}), throwsStateError);
      expect(() => validation.validateForeignKeyViolations(1), throwsStateError);
      expect(() => validation.validateForeignKeyViolations(0), returnsNormally);
    });
  });

  group('CatalogPolicy', () {
    test('permite retirar un producto sin existencias', () {
      expect(
        () => CatalogPolicy().ensureCanArchive(
          productName: 'Pastel',
          knownQuantity: d('0,00'),
        ),
        returnsNormally,
      );
    });

    test('impide retirar un producto que todavía tiene existencias', () {
      expect(
        () => CatalogPolicy().ensureCanArchive(
          productName: 'Pastel',
          knownQuantity: d('0,25'),
        ),
        throwsA(isA<StateError>().having(
          (error) => error.message,
          'message',
          contains('0,25 unidades'),
        )),
      );
    });
  });

  group('CycleSequenceService', () {
    test('alterna ciclos y no crea copias automáticas en ciclos de inventario', () {
      final service = CycleSequenceService();
      expect(service.nextKind(CycleKind.full), CycleKind.inventoryOnly);
      expect(service.nextKind(CycleKind.inventoryOnly), CycleKind.full);
      expect(service.shouldCreateDailyBackup(CycleKind.inventoryOnly), isFalse);
      expect(service.shouldCreateCloseBackup(CycleKind.inventoryOnly), isFalse);
      expect(service.shouldCreateDailyBackup(CycleKind.full), isTrue);
    });

    test('permite continuar con inventario final vacío cuando el ciclo está cerrado', () {
      final service = CycleSequenceService();
      final emptyClosedCycle = CycleData(
        id: 'empty-cycle',
        kind: CycleKind.full,
        status: CycleStatus.closed,
        startDate: DateTime(2026, 11, 12),
        productsInOrder: const [],
        productNames: const {},
        initialInventory: const {},
        initialPrices: const {},
        finalInventory: const {},
      );

      final next = service.nextCycleSeed(emptyClosedCycle);
      expect(next['initialInventory'], isEmpty);
      expect(next['productsInOrder'], isEmpty);
      expect(next['kind'], CycleKind.inventoryOnly);
    });

    test('la política de respaldos excluye los ciclos de inventario', () {
      final policy = BackupPolicy();
      expect(policy.shouldCreateDailyBackup(CycleKind.inventoryOnly), isFalse);
      expect(policy.shouldCreateCloseBackup(CycleKind.inventoryOnly), isFalse);
      expect(policy.shouldAllowManualBackup(), isTrue);
    });

    test('solo cierra tras revisión y valida el inventario final', () {
      final cycle = sampleCycle();
      final lifecycle = CycleLifecycleService(CalculationService());
      final pending = lifecycle.prepareForReview(cycle, {'p1': d('10')});
      expect(pending.status, CycleStatus.pendingClose);
      final closed = lifecycle.confirmClose(pending);
      expect(closed.status, CycleStatus.closed);
    });

    test('propaga también un inventario vacío como estado válido', () {
      final service = ReopeningService();
      CycleData closedCycle(String id, int day, Map<String, ExactDecimal> finalInventory) => CycleData(
        id: id,
        kind: CycleKind.inventoryOnly,
        status: CycleStatus.closed,
        startDate: DateTime(2026, 11, day),
        productsInOrder: finalInventory.keys.toList(),
        productNames: const {},
        initialInventory: const {},
        initialPrices: const {},
        finalInventory: finalInventory,
      );
      final chain = [
        closedCycle('c1', 1, const {}),
        closedCycle('c2', 4, {'p-new': d('2')}),
      ];
      final propagated = service.propagateCorrectedInventory(
        chronologicalCycles: chain,
        correctedCycleIndex: 0,
      );
      expect(propagated[1].initialInventory, isEmpty);
      expect(propagated[1].finalInventory['p-new'], d('2'));
    });

    test('la reapertura histórica exige una incidencia negativa', () {
      final reopening = ReopeningService();
      expect(() => reopening.ensureNegativeInventoryReason({'p1': d('0')}), throwsStateError);
      expect(() => reopening.ensureNegativeInventoryReason({'p1': d('-0,5')}), returnsNormally);
    });

    test('reabrir un ciclo propaga los inventarios iniciales sin pisar finales físicos', () {
      final service = ReopeningService();
      CycleData closedCycle(String id, String start, String initial, String finalQty, CycleKind kind) =>
          CycleData(
            id: id,
            kind: kind,
            status: CycleStatus.closed,
            startDate: DateTime.parse(start),
            productsInOrder: const ['p1'],
            productNames: const {'p1': 'Pastel'},
            initialInventory: {'p1': d(initial)},
            initialPrices: {'p1': d('100')},
            finalInventory: {'p1': d(finalQty)},
          );

      final cycles = [
        closedCycle('c1', '2026-11-01', '10', '12', CycleKind.full),
        closedCycle('c2', '2026-11-04', '12', '8', CycleKind.inventoryOnly),
        closedCycle('c3', '2026-11-07', '8', '6', CycleKind.full),
      ];
      final corrected = cycles[0].copyWith(finalInventory: {'p1': d('11')});
      final result = service.propagateCorrectedInventory(
        chronologicalCycles: [corrected, cycles[1], cycles[2]],
        correctedCycleIndex: 0,
      );

      expect(result[1].initialInventory['p1']!.toLocalizedString(), '11');
      expect(result[1].finalInventory['p1']!.toLocalizedString(), '8');
      expect(result[2].initialInventory['p1']!.toLocalizedString(), '8');
      expect(result[2].finalInventory['p1']!.toLocalizedString(), '6');
    });
  });
}

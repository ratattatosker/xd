import 'exact_decimal.dart';

enum CycleKind { full, inventoryOnly }
enum CycleStatus { open, pendingClose, closed }
enum MovementKind { entry, loss }
enum TurnKind { morning, night }

class Product {
  const Product({
    required this.id,
    required this.name,
    required this.currentPrice,
    required this.sortOrder,
    this.active = true,
  });

  final String id;
  final String name;
  final ExactDecimal currentPrice;
  final int sortOrder;
  final bool active;
}

class InventoryMovement {
  const InventoryMovement({
    required this.productId,
    required this.productNameSnapshot,
    required this.quantity,
    required this.kind,
    required this.turnIndex,
  });

  final String productId;
  final String productNameSnapshot;
  final ExactDecimal quantity;
  final MovementKind kind;
  final int turnIndex;
}

class ExpenseEntry {
  const ExpenseEntry({
    required this.concept,
    required this.amount,
    required this.turnIndex,
  });

  final String concept;
  final ExactDecimal amount;
  final int turnIndex;
}

class ReinvestmentEntry {
  const ReinvestmentEntry({
    required this.productId,
    required this.productNameSnapshot,
    required this.quantity,
    required this.amount,
    required this.turnIndex,
  });

  final String productId;
  final String productNameSnapshot;
  final ExactDecimal quantity;
  final ExactDecimal amount;
  final int turnIndex;
}

class ProductNameChange {
  const ProductNameChange({
    required this.productId,
    required this.turnIndex,
    required this.oldName,
    required this.newName,
  });

  final String productId;
  final int turnIndex;
  final String oldName;
  final String newName;
}

class PriceChange {
  const PriceChange({
    required this.productId,
    required this.productNameSnapshot,
    required this.turnIndex,
    required this.oldPrice,
    required this.newPrice,
    required this.balanceAtTurnStart,
  });

  final String productId;
  final String productNameSnapshot;
  final int turnIndex;
  final ExactDecimal oldPrice;
  final ExactDecimal newPrice;

  /// Saldo existente al comienzo del turno donde se activa el nuevo precio,
  /// antes de las entradas y bajas de ese mismo turno.
  final ExactDecimal balanceAtTurnStart;
}

class TurnData {
  TurnData({
    required this.index,
    required this.cashCollected,
    List<InventoryMovement> movements = const [],
    List<ExpenseEntry> expenses = const [],
    List<ReinvestmentEntry> reinvestments = const [],
  })  : movements = List.unmodifiable(movements),
        expenses = List.unmodifiable(expenses),
        reinvestments = List.unmodifiable(reinvestments) {
    if (index < 0 || index > 5) {
      throw ArgumentError.value(index, 'index', 'Debe estar entre 0 y 5.');
    }
  }

  final int index;
  final ExactDecimal cashCollected;
  final List<InventoryMovement> movements;
  final List<ExpenseEntry> expenses;
  final List<ReinvestmentEntry> reinvestments;

  ExactDecimal get expenseTotal => expenses.fold(
        ExactDecimal.zero(),
        (sum, item) => sum + item.amount,
      );

  ExactDecimal get reinvestmentTotal => reinvestments.fold(
        ExactDecimal.zero(),
        (sum, item) => sum + item.amount,
      );

  ExactDecimal get moneyOfSale =>
      cashCollected + expenseTotal + reinvestmentTotal;
}

class CycleData {
  CycleData({
    required this.id,
    required this.kind,
    required this.status,
    required this.startDate,
    required this.productsInOrder,
    required this.productNames,
    required this.initialInventory,
    required this.initialPrices,
    this.finalInventory = const {},
    this.turns = const [],
    this.priceChanges = const [],
    this.nameChanges = const [],
    this.reportNames = const [],
    this.morningWorkerName = 'Matutino',
    this.nightWorkerName = 'Nocturno',
  });

  final String id;
  final CycleKind kind;
  final CycleStatus status;
  final DateTime startDate;
  final List<String> productsInOrder;
  final Map<String, String> productNames;
  final Map<String, ExactDecimal> initialInventory;
  final Map<String, ExactDecimal> initialPrices;
  final Map<String, ExactDecimal> finalInventory;
  final List<TurnData> turns;
  final List<PriceChange> priceChanges;
  final List<ProductNameChange> nameChanges;
  final List<String> reportNames;
  final String morningWorkerName;
  final String nightWorkerName;

  DateTime get endDate => startDate.add(const Duration(days: 2));

  CycleData copyWith({
    CycleKind? kind,
    CycleStatus? status,
    Map<String, ExactDecimal>? initialInventory,
    Map<String, ExactDecimal>? finalInventory,
    List<ProductNameChange>? nameChanges,
  }) => CycleData(
        id: id,
        kind: kind ?? this.kind,
        status: status ?? this.status,
        startDate: startDate,
        productsInOrder: productsInOrder,
        productNames: productNames,
        initialInventory: initialInventory ?? this.initialInventory,
        initialPrices: initialPrices,
        finalInventory: finalInventory ?? this.finalInventory,
        turns: turns,
        priceChanges: priceChanges,
        nameChanges: nameChanges ?? this.nameChanges,
        reportNames: reportNames,
        morningWorkerName: morningWorkerName,
        nightWorkerName: nightWorkerName,
      );
}

class DailyTotals {
  const DailyTotals({
    required this.day,
    required this.cashCollected,
    required this.moneyOfSale,
  });

  final int day;
  final ExactDecimal cashCollected;
  final ExactDecimal moneyOfSale;
}

class PricePeriodResult {
  const PricePeriodResult({
    required this.fromTurnIndex,
    required this.toTurnIndexExclusive,
    required this.price,
    required this.unitsSold,
    required this.estimatedRevenue,
  });

  final int fromTurnIndex;
  final int toTurnIndexExclusive;
  final ExactDecimal price;
  final ExactDecimal unitsSold;
  final ExactDecimal estimatedRevenue;
}

class ProductSalesResult {
  const ProductSalesResult({
    required this.productId,
    required this.productName,
    required this.totalUnitsSold,
    required this.estimatedRevenue,
    required this.periods,
    required this.isConsistent,
    required this.issues,
  });

  final String productId;
  final String productName;
  final ExactDecimal totalUnitsSold;
  final ExactDecimal estimatedRevenue;
  final List<PricePeriodResult> periods;
  final bool isConsistent;
  final List<String> issues;
}

class SalarySummary {
  const SalarySummary({
    required this.morningWorkerName,
    required this.morningBase,
    required this.morningSalary,
    required this.nightWorkerName,
    required this.nightBase,
    required this.nightSalary,
  });

  final String morningWorkerName;
  final ExactDecimal morningBase;
  final ExactDecimal morningSalary;
  final String nightWorkerName;
  final ExactDecimal nightBase;
  final ExactDecimal nightSalary;
}

class CycleCalculation {
  const CycleCalculation({
    required this.turnMoneyOfSale,
    required this.dailyTotals,
    required this.totalCashCollected,
    required this.totalMoneyOfSale,
    required this.totalEstimatedSales,
    required this.differenceEstimatedVsRecorded,
    required this.productSales,
    required this.expensesByConcept,
    required this.salarySummary,
    required this.issues,
  });

  final Map<int, ExactDecimal> turnMoneyOfSale;
  final List<DailyTotals> dailyTotals;
  final ExactDecimal totalCashCollected;
  final ExactDecimal totalMoneyOfSale;
  final ExactDecimal totalEstimatedSales;
  final ExactDecimal differenceEstimatedVsRecorded;
  final Map<String, ProductSalesResult> productSales;
  final List<AggregatedExpense> expensesByConcept;
  final SalarySummary salarySummary;
  final List<String> issues;
}

class AggregatedExpense {
  const AggregatedExpense({
    required this.firstWrittenConcept,
    required this.amount,
  });

  final String firstWrittenConcept;
  final ExactDecimal amount;
}

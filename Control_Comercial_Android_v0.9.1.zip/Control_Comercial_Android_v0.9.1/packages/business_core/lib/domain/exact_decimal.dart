/// Decimal exacto con escala conservada.
///
/// Se almacena como coeficiente BigInt + escala. No utiliza double, por lo que
/// 1,30 permanece 1,30 y las sumas/multiplicaciones no introducen errores
/// binarios de coma flotante.
class ExactDecimal implements Comparable<ExactDecimal> {
  final BigInt coefficient;
  final int scale;

  const ExactDecimal._(this.coefficient, this.scale);

  factory ExactDecimal.zero({int scale = 0}) =>
      ExactDecimal._(BigInt.zero, scale);

  factory ExactDecimal.fromParts(String coefficient, int scale) {
    if (scale < 0) throw ArgumentError.value(scale, 'scale');
    return ExactDecimal._(BigInt.parse(coefficient), scale);
  }

  factory ExactDecimal.parse(String input) {
    var value = input.trim().replaceAll(RegExp(r'[\s\u00A0\u202F]'), '');
    if (value.isEmpty) throw FormatException('El número está vacío.', input);
    if (value.contains(',') && value.contains('.')) {
      throw FormatException(
        'Usa coma o punto como separador decimal, no ambos.',
        input,
      );
    }
    value = value.replaceAll(',', '.');
    final match = RegExp(r'^([+-]?)(\d+)(?:\.(\d+))?$').firstMatch(value);
    if (match == null) throw FormatException('Número decimal no válido.', input);
    final sign = match.group(1) == '-' ? -1 : 1;
    final integerPart = match.group(2)!;
    final fractionalPart = match.group(3) ?? '';
    final digits = '$integerPart$fractionalPart';
    final parsed = BigInt.parse(digits) * BigInt.from(sign);
    return ExactDecimal._(parsed, fractionalPart.length);
  }

  ExactDecimal _align(ExactDecimal other, int targetScale) {
    final factor = BigInt.from(10).pow(targetScale - scale);
    return ExactDecimal._(coefficient * factor, targetScale);
  }

  ExactDecimal operator +(ExactDecimal other) {
    final targetScale = scale > other.scale ? scale : other.scale;
    final left = _align(this, targetScale);
    final right = other._align(other, targetScale);
    return ExactDecimal._(left.coefficient + right.coefficient, targetScale);
  }

  ExactDecimal operator -(ExactDecimal other) {
    final targetScale = scale > other.scale ? scale : other.scale;
    final left = _align(this, targetScale);
    final right = other._align(other, targetScale);
    return ExactDecimal._(left.coefficient - right.coefficient, targetScale);
  }

  ExactDecimal operator *(ExactDecimal other) => ExactDecimal._(
        coefficient * other.coefficient,
        scale + other.scale,
      );

  ExactDecimal timesInt(int value) =>
      ExactDecimal._(coefficient * BigInt.from(value), scale);

  /// Porcentaje exacto. El 5 % de 100,00 queda como 5,0000: no se pierde escala.
  ExactDecimal percent(int percentage) =>
      ExactDecimal._(coefficient * BigInt.from(percentage), scale + 2);

  bool get isNegative => coefficient.isNegative;
  bool get isZero => coefficient == BigInt.zero;

  @override
  int compareTo(ExactDecimal other) {
    final targetScale = scale > other.scale ? scale : other.scale;
    return _align(this, targetScale).coefficient.compareTo(
          other._align(other, targetScale).coefficient,
        );
  }

  String toLocalizedString({bool groupThousands = false}) {
    final negative = coefficient.isNegative;
    var digits = coefficient.abs().toString();
    if (scale > 0) {
      digits = digits.padLeft(scale + 1, '0');
      final split = digits.length - scale;
      var integerPart = digits.substring(0, split);
      final decimalPart = digits.substring(split);
      if (groupThousands) integerPart = _groupThousands(integerPart);
      return '${negative ? '-' : ''}$integerPart,$decimalPart';
    }
    if (groupThousands) digits = _groupThousands(digits);
    return '${negative ? '-' : ''}$digits';
  }

  static String _groupThousands(String digits) {
    final output = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) output.write(' ');
      output.write(digits[i]);
    }
    return output.toString();
  }

  String get databaseCoefficient => coefficient.toString();

  @override
  String toString() => toLocalizedString();
}

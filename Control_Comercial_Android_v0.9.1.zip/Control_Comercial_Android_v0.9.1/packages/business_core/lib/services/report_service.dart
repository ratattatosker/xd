import '../domain/exact_decimal.dart';
import '../domain/models.dart';
import 'calculation_service.dart';

class ReportService {
  ReportService(this.calculator);

  final CalculationService calculator;

  String buildFullCycleReport(CycleData cycle, CycleCalculation calculation) {
    if (cycle.kind != CycleKind.full) {
      throw StateError('Los ciclos exclusivamente de inventario no generan informe financiero.');
    }
    final names = cycle.reportNames.isEmpty ? 'Cierre' : cycle.reportNames.join(' e ');
    final buffer = StringBuffer()
      ..writeln('Cierre de $names ${_date(cycle.startDate)}-${_date(cycle.endDate)}');

    final turns = [...cycle.turns]..sort((a, b) => a.index.compareTo(b.index));
    for (var day = 0; day < 3; day++) {
      final morning = turns[day * 2];
      final night = turns[day * 2 + 1];
      final totals = calculation.dailyTotals[day];
      final date = cycle.startDate.add(Duration(days: day));
      buffer
        ..writeln(_date(date))
        ..writeln('Dinero Matutino: ${_money(morning.cashCollected)}')
        ..writeln('Dinero de Venta Matutino: ${_money(morning.moneyOfSale)}')
        ..writeln()
        ..writeln('Dinero Nocturno: ${_money(night.cashCollected)}')
        ..writeln('Dinero de Venta Nocturno: ${_money(night.moneyOfSale)}')
        ..writeln()
        ..writeln('Dinero Recogido: ${_money(totals.cashCollected)}')
        ..writeln('Dinero de Venta Total: ${_money(totals.moneyOfSale)}')
        ..writeln();
    }

    for (var day = 0; day < 3; day++) {
      final date = cycle.startDate.add(Duration(days: day));
      final entries = <InventoryMovement>[];
      for (final turn in turns.where((t) => t.index ~/ 2 == day)) {
        entries.addAll(turn.movements.where((m) => m.kind == MovementKind.entry));
        // Las cantidades de reinversiones aparecen en Entradas exactamente una vez.
        for (final reinvestment in turn.reinvestments) {
          entries.add(InventoryMovement(
            productId: reinvestment.productId,
            productNameSnapshot: reinvestment.productNameSnapshot,
            quantity: reinvestment.quantity,
            kind: MovementKind.entry,
            turnIndex: turn.index,
          ));
        }
      }
      if (entries.isNotEmpty) {
        buffer.writeln('Entradas ${_date(date)}');
        for (final entry in entries) {
          buffer.writeln('${entry.quantity.toLocalizedString()} ${entry.productNameSnapshot}');
        }
        buffer.writeln();
      }
    }

    buffer.writeln('Gastos');
    for (final expense in calculation.expensesByConcept) {
      buffer.writeln('${_money(expense.amount)} ${expense.firstWrittenConcept}');
    }
    buffer.writeln();

    final losses = turns
        .expand((turn) => turn.movements)
        .where((movement) => movement.kind == MovementKind.loss)
        .toList();
    buffer.writeln('Bajas');
    for (final loss in losses) {
      buffer.writeln('${loss.quantity.toLocalizedString()} ${loss.productNameSnapshot}');
    }
    buffer.writeln();

    buffer.writeln('Reinversiones');
    for (var day = 0; day < 3; day++) {
      buffer.writeln('Dia ${day + 1}');
      for (final turn in turns.where((t) => t.index ~/ 2 == day)) {
        for (final reinvestment in turn.reinvestments) {
          buffer.writeln(
            '${_money(reinvestment.amount)} en ${reinvestment.quantity.toLocalizedString()} ${reinvestment.productNameSnapshot}',
          );
        }
      }
      buffer.writeln();
    }

    buffer.writeln('Cambio de Precio');
    if (cycle.priceChanges.isEmpty) {
      buffer.writeln('No hubo Cambios de Precio');
    } else {
      final sorted = [...cycle.priceChanges]..sort((a, b) => a.turnIndex.compareTo(b.turnIndex));
      for (final change in sorted) {
        buffer.writeln(
          '${change.productNameSnapshot}: ${_money(change.oldPrice)} a ${_money(change.newPrice)}; '
          '${change.balanceAtTurnStart.toLocalizedString()} unidades; ${CalculationService.turnLabel(change.turnIndex)}',
        );
      }
    }
    buffer.writeln();

    buffer.writeln('Finales');
    for (final productId in cycle.productsInOrder) {
      final quantity = cycle.finalInventory[productId] ?? ExactDecimal.zero();
      final renames = cycle.nameChanges.where((change) => change.productId == productId).toList()
        ..sort((a, b) => a.turnIndex.compareTo(b.turnIndex));
      final name = renames.isEmpty ? (cycle.productNames[productId] ?? productId) : renames.last.newName;
      buffer.writeln('$name - ${quantity.toLocalizedString()}');
    }
    return buffer.toString().trimRight();
  }

  String _money(ExactDecimal value) => r'$' + value.toLocalizedString(groupThousands: true);

  String _date(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${(date.year % 100).toString().padLeft(2, '0')}';
}
